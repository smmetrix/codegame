@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title ZERO DAY - установка и запуск
color 0C

echo ============================================================
echo                 ZERO DAY - БЫСТРЫЙ ЗАПУСК
echo ============================================================
echo.
echo [1/3] Проверяю Python...

set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py -3"
if defined PYTHON_CMD goto python_found

where python >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=python"
if defined PYTHON_CMD goto python_found

echo.
echo ОШИБКА: Python не найден.
echo Скачай Python 3.10+ с https://www.python.org/downloads/
echo При установке обязательно включи "Add Python to PATH".
echo После установки снова запусти START_GAME.bat.
echo.
pause
exit /b 1

:python_found
%PYTHON_CMD% -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if not errorlevel 1 goto python_ok

echo.
echo ОШИБКА: нужна версия Python 3.10 или новее.
echo Установи новую версию с https://www.python.org/downloads/
echo.
pause
exit /b 1

:python_ok
echo Python найден.
echo [2/3] Проверяю Pygame...

%PYTHON_CMD% -c "import pygame, pygame_gui" >nul 2>nul
if not errorlevel 1 goto launch

echo Pygame не найден. Сейчас он установится автоматически.
echo Это делается только при первом запуске и может занять 1-3 минуты.
echo.
%PYTHON_CMD% -m ensurepip --upgrade
%PYTHON_CMD% -m pip install --user --upgrade pygame-ce pygame_gui
if not errorlevel 1 goto launch

echo.
echo ОШИБКА: не удалось установить Pygame.
echo Проверь интернет и запусти START_GAME.bat ещё раз.
echo Окно останется открытым, чтобы ошибка была видна.
echo.
pause
exit /b 1

:launch
echo.
echo [3/3] Запускаю ZERO DAY...
echo Не закрывай это окно, пока игра работает.
echo.
%PYTHON_CMD% zero_day.py
set "GAME_EXIT=%ERRORLEVEL%"

if "%GAME_EXIT%"=="0" goto normal_exit
echo.
echo ============================================================
echo ИГРА ЗАВЕРШИЛАСЬ С ОШИБКОЙ %GAME_EXIT%.
echo Скопируй текст ошибки выше и отправь его разработчику.
echo Это окно не закроется, пока ты не нажмёшь клавишу.
echo ============================================================
echo.
pause
exit /b %GAME_EXIT%

:normal_exit
echo.
echo Игра закрыта нормально. Можно закрыть это окно.
timeout /t 3 >nul
exit /b 0
