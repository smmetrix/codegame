"""ZERO DAY — автономный стартовый экран на Pygame + pygame_gui.

Установка зависимостей и запуск:
    python -m pip install numpy pygame-ce pygame_gui
    python zero_day.py

Файл не использует внешние игровые ресурсы: фон, панели и анимации строятся
примитивами Pygame, а музыка и эффекты синтезируются NumPy в памяти.
"""

from __future__ import annotations

import json
import math
import os
import random
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import ClassVar, Final

try:
    import numpy as np
    import pygame
    import pygame_gui
    from pygame_gui.elements import UIButton
except ImportError as exc:
    raise SystemExit(
        "Не найдены совместимые numpy/Pygame/pygame_gui. Выполните: "
        "python -m pip uninstall -y pygame pygame-ce pygame_gui && "
        "python -m pip install --no-cache-dir numpy pygame-ce pygame_gui"
    ) from exc


# =============================================================================
# НАСТРАИВАЕМЫЕ ПАРАМЕТРЫ: палитра, размеры, координаты и длительности
# Все координаты ниже заданы для базового холста 1280 x 720 и автоматически
# масштабируются под выбранное разрешение.
# =============================================================================

# Точная цветовая палитра из задания.
COLOR_BACKGROUND_HEX: Final[str] = "#1a1a2e"
COLOR_PANEL_HEX: Final[str] = "#16213e"
COLOR_ACCENT_HEX: Final[str] = "#0f3460"
COLOR_HOT_ACCENT_HEX: Final[str] = "#e94560"
COLOR_TEXT_HEX: Final[str] = "#e0e0e0"
COLOR_SUCCESS_HEX: Final[str] = "#00ff88"
COLOR_ERROR_HEX: Final[str] = "#ff4444"
COLOR_TASKBAR_HEX: Final[str] = "#0d1117"
COLOR_MESSAGE_INCOMING_HEX: Final[str] = "#0f3460"
COLOR_MESSAGE_OUTGOING_HEX: Final[str] = "#123b2f"
COLOR_GOLD_HEX: Final[str] = "#ffcc33"
COLOR_GOLD_DARK_HEX: Final[str] = "#5b4300"
COLOR_MUTED_HEX: Final[str] = "#8b9199"

COLOR_BACKGROUND: Final[pygame.Color] = pygame.Color(COLOR_BACKGROUND_HEX)
COLOR_PANEL: Final[pygame.Color] = pygame.Color(COLOR_PANEL_HEX)
COLOR_ACCENT: Final[pygame.Color] = pygame.Color(COLOR_ACCENT_HEX)
COLOR_HOT_ACCENT: Final[pygame.Color] = pygame.Color(COLOR_HOT_ACCENT_HEX)
COLOR_TEXT: Final[pygame.Color] = pygame.Color(COLOR_TEXT_HEX)
COLOR_SUCCESS: Final[pygame.Color] = pygame.Color(COLOR_SUCCESS_HEX)
COLOR_ERROR: Final[pygame.Color] = pygame.Color(COLOR_ERROR_HEX)
COLOR_TASKBAR: Final[pygame.Color] = pygame.Color(COLOR_TASKBAR_HEX)
COLOR_MESSAGE_INCOMING: Final[pygame.Color] = pygame.Color(COLOR_MESSAGE_INCOMING_HEX)
COLOR_MESSAGE_OUTGOING: Final[pygame.Color] = pygame.Color(COLOR_MESSAGE_OUTGOING_HEX)
COLOR_GOLD: Final[pygame.Color] = pygame.Color(COLOR_GOLD_HEX)
COLOR_GOLD_DARK: Final[pygame.Color] = pygame.Color(COLOR_GOLD_DARK_HEX)
COLOR_MUTED: Final[pygame.Color] = pygame.Color(COLOR_MUTED_HEX)

APP_TITLE: Final[str] = "ZERO DAY // ACCESS TERMINAL"
FPS: Final[int] = 60
DESIGN_WIDTH: Final[int] = 1280
DESIGN_HEIGHT: Final[int] = 720

# Музыкальный синтезатор: 44.1 kHz, стерео, PCM int16, без внешних файлов.
AUDIO_SAMPLE_RATE: Final[int] = 44_100
AUDIO_CHANNELS: Final[int] = 2
AUDIO_BUFFER_SIZE: Final[int] = 1024
AUDIO_MIXER_CHANNEL_COUNT: Final[int] = 16
AUDIO_RESERVED_MUSIC_CHANNELS: Final[int] = 1
AUDIO_EXACT_ALLOWED_CHANGES: Final[int] = 0
AUDIO_COMPATIBLE_ALLOWED_CHANGES: Final[int] = (
    pygame.AUDIO_ALLOW_FREQUENCY_CHANGE | pygame.AUDIO_ALLOW_CHANNELS_CHANGE
)
AUDIO_FALLBACK_CHANNELS: Final[int] = 1
AUDIO_FALLBACK_SAMPLE_RATE: Final[int] = 48_000
AUDIO_INT16_PEAK: Final[float] = 32_767.0
AUDIO_NORMALIZE_HEADROOM: Final[float] = 0.80
AUDIO_COMPONENT_HEADROOM: Final[float] = 0.80
MUSIC_DEFAULT_VOLUME: Final[float] = 0.30
SFX_DEFAULT_VOLUME: Final[float] = 0.60
MUSIC_FADE_OUT_SECONDS: Final[float] = 0.40
MUSIC_FADE_IN_SECONDS: Final[float] = 0.40
MUSIC_FADE_OUT_MS: Final[int] = 400
MUSIC_FADE_IN_MS: Final[int] = 400
MUSIC_VISUALIZER_BAR_COUNT: Final[int] = 16
MUSIC_VISUALIZER_UPDATE_SECONDS: Final[float] = 0.10
MUSIC_VISUALIZER_MIN_LEVEL: Final[float] = 0.06
MUSIC_VISUALIZER_RANDOM_LEVEL: Final[float] = 0.08
MUSIC_VISUALIZER_SEED: Final[int] = 0xA710
MUSIC_TRACKS: Final[tuple[dict[str, object], ...]] = (
    {
        "id": "track_menu",
        "name": "Deep Cyber Ambient",
        "duration": 12.0,
        "bpm": 60.0,
        "visualizer": 0.25,
    },
    {
        "id": "track_desktop",
        "name": "Lo-Fi Hacker Chill",
        "duration": 16.0,
        "bpm": 75.0,
        "visualizer": 0.42,
    },
    {
        "id": "track_hack",
        "name": "Synthwave Focus / Cyber Run",
        "duration": 24.0 * 60.0 / 115.0,
        "bpm": 115.0,
        "visualizer": 0.62,
    },
    {
        "id": "track_attack",
        "name": "System Breach / Red Alert",
        "duration": 8.0,
        "bpm": 135.0,
        "visualizer": 0.78,
    },
)
MUSIC_TRACK_IDS: Final[tuple[str, ...]] = tuple(
    str(track["id"]) for track in MUSIC_TRACKS
)
MUSIC_TRACK_NAMES: Final[dict[str, str]] = {
    str(track["id"]): str(track["name"]) for track in MUSIC_TRACKS
}
MUSIC_TRACK_DURATIONS: Final[dict[str, float]] = {
    str(track["id"]): float(track["duration"]) for track in MUSIC_TRACKS
}
MUSIC_TRACK_BPMS: Final[dict[str, float]] = {
    str(track["id"]): float(track["bpm"]) for track in MUSIC_TRACKS
}
MUSIC_TRACK_VISUALIZER_BASE: Final[dict[str, float]] = {
    str(track["id"]): float(track["visualizer"]) for track in MUSIC_TRACKS
}

NOTE_FREQUENCIES: Final[dict[str, float]] = {
    "C2": 65.41,
    "D2": 73.42,
    "E2": 82.41,
    "F2": 87.31,
    "G2": 98.00,
    "A2": 110.00,
    "B2": 123.47,
    "C3": 130.81,
    "D3": 146.83,
    "E3": 164.81,
    "F3": 174.61,
    "G3": 196.00,
    "A3": 220.00,
    "B3": 246.94,
    "C4": 261.63,
    "D4": 293.66,
    "E4": 329.63,
    "F4": 349.23,
    "G4": 392.00,
    "A4": 440.00,
    "B4": 493.88,
    "C5": 523.25,
    "D5": 587.33,
    "E5": 659.25,
    "F5": 698.46,
    "G5": 783.99,
    "A5": 880.00,
    "B5": 987.77,
    "C6": 1046.50,
}

MENU_CHORDS: Final[tuple[tuple[str, ...], ...]] = (
    ("A2", "E3", "A3", "C4", "E4"),
    ("F2", "C3", "F3", "A3", "C4"),
    ("E2", "B2", "E3", "G3", "B3"),
)
DESKTOP_CHORDS: Final[tuple[tuple[str, ...], ...]] = (
    ("A2", "E3", "G3", "C4", "E4"),
    ("F2", "C3", "E3", "A3", "C4"),
    ("C3", "G3", "B3", "E4"),
    ("G2", "D3", "E3", "B3"),
    ("A2", "E3", "G3", "C4", "E4"),
)
HACK_ARPEGGIO: Final[tuple[str, ...]] = (
    "A3",
    "C4",
    "E4",
    "G4",
    "A4",
    "G4",
    "E4",
    "C4",
)
ATTACK_BASS_LINE: Final[tuple[str, ...]] = (
    "A2",
    "A2",
    "F2",
    "G2",
    "E2",
    "G2",
)

SFX_CLICK_DURATION: Final[float] = 0.030
SFX_NOTIFY_DURATION: Final[float] = 0.48
SFX_SUCCESS_DURATION: Final[float] = 0.72
SFX_FAIL_DURATION: Final[float] = 0.62
SFX_TYPING_DURATION: Final[float] = 0.34
SFX_ALARM_DURATION: Final[float] = 1.60
SFX_INSTALL_DURATION: Final[float] = 1.00
SFX_COIN_DURATION: Final[float] = 0.30
SFX_GLITCH_DURATION: Final[float] = 0.14
SFX_RANDOM_SEED: Final[int] = 0x5F0
SFX_LEGACY_ALIASES: Final[dict[str, str]] = {
    "click": "sfx_click",
    "notification": "sfx_notify",
    "success": "sfx_success",
    "failure": "sfx_fail",
    "typing": "sfx_typing",
    "alarm": "sfx_alarm",
    "install": "sfx_install",
    "coin": "sfx_coin",
    "glitch": "sfx_glitch",
}


def get_note_freq(note_name: str) -> float:
    """Возвращает точную частоту ноты равномерно темперированного строя."""
    normalized = note_name.strip().upper().replace("♯", "#").replace("♭", "B")
    if normalized in NOTE_FREQUENCIES:
        return NOTE_FREQUENCIES[normalized]
    if len(normalized) < 2 or not normalized[-1].isdigit():
        raise ValueError(f"Неизвестная нота: {note_name}")
    octave = int(normalized[-1])
    pitch = normalized[:-1]
    semitones = {
        "C": 0,
        "C#": 1,
        "DB": 1,
        "D": 2,
        "D#": 3,
        "EB": 3,
        "E": 4,
        "F": 5,
        "F#": 6,
        "GB": 6,
        "G": 7,
        "G#": 8,
        "AB": 8,
        "A": 9,
        "A#": 10,
        "BB": 10,
        "B": 11,
    }
    if pitch not in semitones:
        raise ValueError(f"Неизвестная нота: {note_name}")
    midi_note = (octave + 1) * 12 + semitones[pitch]
    return 440.0 * 2.0 ** ((midi_note - 69) / 12.0)


def apply_adsr(
    signal: np.ndarray,
    attack_time: float,
    decay_time: float,
    sustain_level: float,
    release_time: float,
    sample_rate: int,
) -> np.ndarray:
    """Применяет raised-cosine ADSR без разрывов на границах сегментов."""
    samples = np.asarray(signal, dtype=np.float64)
    if samples.size == 0:
        return samples.copy()
    frame_count = samples.shape[0]
    if frame_count < 4:
        envelope = np.sin(np.linspace(0.0, np.pi, frame_count, endpoint=True))
        if samples.ndim == 1:
            return samples * envelope
        return samples * envelope[:, np.newaxis]
    segment_counts = [
        max(1, round(max(0.0, attack_time) * sample_rate)),
        max(1, round(max(0.0, decay_time) * sample_rate)),
        max(1, round(max(0.0, release_time) * sample_rate)),
    ]
    if sum(segment_counts) >= frame_count:
        scale = frame_count / sum(segment_counts)
        segment_counts = [max(1, round(count * scale)) for count in segment_counts]
        while sum(segment_counts) > frame_count:
            largest = max(range(3), key=segment_counts.__getitem__)
            if segment_counts[largest] <= 1:
                break
            segment_counts[largest] -= 1
    attack, decay, release = segment_counts
    sustain_count = max(0, frame_count - attack - decay - release)
    release += frame_count - (attack + decay + sustain_count + release)
    sustain = min(1.0, max(0.0, float(sustain_level)))
    envelope = np.empty(frame_count, dtype=np.float64)
    cursor = 0

    attack_phase = np.linspace(0.0, 1.0, attack, endpoint=False)
    envelope[cursor : cursor + attack] = 0.5 - 0.5 * np.cos(np.pi * attack_phase)
    cursor += attack
    decay_phase = np.linspace(0.0, 1.0, decay, endpoint=False)
    envelope[cursor : cursor + decay] = sustain + (1.0 - sustain) * (
        0.5 + 0.5 * np.cos(np.pi * decay_phase)
    )
    cursor += decay
    envelope[cursor : cursor + sustain_count] = sustain
    cursor += sustain_count
    release_count = frame_count - cursor
    release_phase = np.linspace(0.0, 1.0, release_count, endpoint=True)
    envelope[cursor:] = sustain * (0.5 + 0.5 * np.cos(np.pi * release_phase))
    if samples.ndim == 1:
        return samples * envelope
    return samples * envelope[:, np.newaxis]


def _component_limit(signal: np.ndarray) -> np.ndarray:
    clean = np.nan_to_num(signal, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    peak = float(np.max(np.abs(clean))) if clean.size else 0.0
    if peak > AUDIO_COMPONENT_HEADROOM:
        clean = clean * (AUDIO_COMPONENT_HEADROOM / peak)
    return clean


def _phase_from_frequency(frequency: np.ndarray, sample_rate: int) -> np.ndarray:
    return np.cumsum(frequency, dtype=np.float64) * (math.tau / sample_rate)


def synth_pad(freq: float, duration: float, sample_rate: int) -> np.ndarray:
    """Мягкий пэд: синус, band-limited triangle и вибрато 4.6 Hz."""
    frame_count = max(1, round(duration * sample_rate))
    time_axis = np.arange(frame_count, dtype=np.float64) / sample_rate
    vibrato = 1.0 + 0.0025 * np.sin(math.tau * 4.6 * time_axis)
    phase = _phase_from_frequency(freq * vibrato, sample_rate)
    triangle = (8.0 / math.pi**2) * (
        np.sin(phase) - np.sin(phase * 3.0) / 9.0 + np.sin(phase * 5.0) / 25.0
    )
    slow_bloom = 0.94 + 0.06 * np.sin(math.tau * 0.23 * time_axis + 0.4)
    signal = (
        0.70 * np.sin(phase)
        + 0.22 * triangle
        + 0.08 * np.sin(phase * 2.0 + 0.18)
    ) * slow_bloom
    signal = apply_adsr(
        signal,
        min(0.48, duration * 0.20),
        min(0.42, duration * 0.16),
        0.76,
        min(0.70, duration * 0.28),
        sample_rate,
    )
    return _component_limit(signal)


def synth_pluck(freq: float, duration: float, sample_rate: int) -> np.ndarray:
    """Чистый неоновый pluck с синусоидальными обертонами и мягким спадом."""
    frame_count = max(1, round(duration * sample_rate))
    time_axis = np.arange(frame_count, dtype=np.float64) / sample_rate
    phase = math.tau * freq * time_axis
    signal = (
        0.82 * np.sin(phase)
        + 0.14 * np.sin(phase * 2.0 + 0.12)
        + 0.04 * np.sin(phase * 3.0 + 0.24)
    )
    signal *= np.exp(-3.4 * time_axis / max(duration, 1e-6))
    signal = apply_adsr(
        signal,
        min(0.012, duration * 0.12),
        min(0.10, duration * 0.24),
        0.34,
        min(0.20, duration * 0.36),
        sample_rate,
    )
    return _component_limit(signal)


def synth_bass(freq: float, duration: float, sample_rate: int) -> np.ndarray:
    """Тёплый синусоидальный бас с суб-октавой и очень мягкой сатурацией."""
    frame_count = max(1, round(duration * sample_rate))
    time_axis = np.arange(frame_count, dtype=np.float64) / sample_rate
    phase = math.tau * freq * time_axis
    signal = (
        0.72 * np.sin(phase)
        + 0.24 * np.sin(phase * 0.5 + 0.08)
        + 0.08 * np.sin(phase * 2.0 + 0.16)
    )
    signal = np.tanh(signal * 1.18) / np.tanh(1.18)
    signal = apply_adsr(
        signal,
        min(0.025, duration * 0.10),
        min(0.12, duration * 0.25),
        0.72,
        min(0.18, duration * 0.30),
        sample_rate,
    )
    return _component_limit(signal)


def drum_kick() -> np.ndarray:
    """Мягкий lo-fi kick с падением 130 -> 40 Hz примерно за 0.15 секунды."""
    sample_rate = AUDIO_SAMPLE_RATE
    duration = 0.28
    frame_count = round(duration * sample_rate)
    time_axis = np.arange(frame_count, dtype=np.float64) / sample_rate
    frequency = 40.0 + 90.0 * np.exp(-time_axis / 0.045)
    phase = _phase_from_frequency(frequency, sample_rate)
    body = 0.92 * np.sin(phase) + 0.08 * np.sin(phase * 2.0)
    body *= np.exp(-8.5 * time_axis)
    body = np.tanh(body * 1.12) / np.tanh(1.12)
    body = apply_adsr(body, 0.004, 0.07, 0.32, 0.16, sample_rate)
    return _component_limit(body)


def drum_hat() -> np.ndarray:
    """Очень тихий 30 ms hat: детерминированный шум после high/low-pass фильтров."""
    sample_rate = AUDIO_SAMPLE_RATE
    duration = 0.030
    frame_count = max(1, round(duration * sample_rate))
    rng = np.random.default_rng(SFX_RANDOM_SEED)
    noise = rng.normal(0.0, 1.0, frame_count + 64)
    low_band = np.convolve(noise, np.ones(33) / 33.0, mode="same")
    high_passed = noise - low_band
    filtered = np.convolve(high_passed, np.ones(5) / 5.0, mode="same")[32:-32]
    time_axis = np.arange(frame_count, dtype=np.float64) / sample_rate
    metallic = np.sin(math.tau * 6200.0 * time_axis) * 0.12
    signal = filtered[:frame_count] * 0.16 + metallic
    signal = apply_adsr(signal, 0.0015, 0.006, 0.16, 0.018, sample_rate)
    return _component_limit(signal) * 0.42


def _pan_mono(signal: np.ndarray, pan: float) -> np.ndarray:
    position = min(1.0, max(-1.0, pan))
    angle = (position + 1.0) * math.pi / 4.0
    return np.column_stack((signal * math.cos(angle), signal * math.sin(angle)))


def _empty_stereo(duration: float, sample_rate: int = AUDIO_SAMPLE_RATE) -> np.ndarray:
    return np.zeros((max(1, round(duration * sample_rate)), AUDIO_CHANNELS), dtype=np.float64)


def _mix_loop(
    destination: np.ndarray,
    signal: np.ndarray,
    start_seconds: float,
    gain: float,
    pan: float = 0.0,
    sample_rate: int = AUDIO_SAMPLE_RATE,
) -> None:
    stereo = _pan_mono(signal, pan) if signal.ndim == 1 else signal
    total_frames = destination.shape[0]
    start = round(start_seconds * sample_rate) % total_frames
    source_cursor = 0
    while source_cursor < stereo.shape[0]:
        writable = min(total_frames - start, stereo.shape[0] - source_cursor)
        destination[start : start + writable] += (
            stereo[source_cursor : source_cursor + writable] * gain
        )
        source_cursor += writable
        start = 0


def _mix_once(
    destination: np.ndarray,
    signal: np.ndarray,
    start_seconds: float,
    gain: float,
    pan: float = 0.0,
    sample_rate: int = AUDIO_SAMPLE_RATE,
) -> None:
    stereo = _pan_mono(signal, pan) if signal.ndim == 1 else signal
    start = max(0, round(start_seconds * sample_rate))
    end = min(destination.shape[0], start + stereo.shape[0])
    if end > start:
        destination[start:end] += stereo[: end - start] * gain


def _close_loop_seam(
    signal: np.ndarray,
    sample_rate: int = AUDIO_SAMPLE_RATE,
) -> np.ndarray:
    """Незаметно совмещает первый и последний кадры готового loop."""
    closed = np.asarray(signal, dtype=np.float64).copy()
    blend_frames = min(closed.shape[0], max(2, round(0.012 * sample_rate)))
    mismatch = closed[-1] - closed[0]
    phase = np.linspace(0.0, 1.0, blend_frames, endpoint=True)
    smoothstep = phase * phase * (3.0 - 2.0 * phase)
    closed[-blend_frames:] -= smoothstep[:, np.newaxis] * mismatch
    return closed


def _stereo_to_pcm(
    signal: np.ndarray,
    peak_level: float = AUDIO_NORMALIZE_HEADROOM,
) -> np.ndarray:
    stereo = np.asarray(signal, dtype=np.float64)
    if stereo.ndim == 1:
        stereo = _pan_mono(stereo, 0.0)
    if stereo.ndim != 2 or stereo.shape[1] != AUDIO_CHANNELS:
        raise ValueError("Ожидался стереосигнал формы (samples, 2)")
    clean = np.nan_to_num(stereo, copy=True, nan=0.0, posinf=0.0, neginf=0.0)
    target_peak = min(AUDIO_NORMALIZE_HEADROOM, max(0.0, peak_level))
    peak = float(np.max(np.abs(clean))) if clean.size else 0.0
    if peak > 0.0:
        clean *= target_peak / peak
    clean = np.clip(clean, -AUDIO_NORMALIZE_HEADROOM, AUDIO_NORMALIZE_HEADROOM)
    return np.ascontiguousarray(clean * AUDIO_INT16_PEAK, dtype=np.int16)


def track_menu() -> np.ndarray:
    """Deep Cyber Ambient: Am -> F -> Em, 60 BPM, бесшовный 12 s loop."""
    duration = MUSIC_TRACK_DURATIONS["track_menu"]
    mix = _empty_stereo(duration)
    chord_seconds = 4.0
    pad_duration = 4.65
    pans = (-0.62, -0.28, 0.0, 0.30, 0.62)
    for chord_index, chord in enumerate(MENU_CHORDS):
        chord_start = chord_index * chord_seconds
        for voice, note in enumerate(chord):
            _mix_loop(
                mix,
                synth_pad(get_note_freq(note), pad_duration, AUDIO_SAMPLE_RATE),
                chord_start,
                0.105 if voice < 2 else 0.085,
                pans[voice],
            )
    plucks = (
        (1.50, "E5", -0.48),
        (3.00, "A5", 0.42),
        (5.50, "C5", -0.32),
        (7.25, "E5", 0.52),
        (9.50, "B4", -0.44),
        (11.00, "E5", 0.36),
    )
    for start, note, pan in plucks:
        _mix_loop(
            mix,
            synth_pluck(get_note_freq(note), 0.72, AUDIO_SAMPLE_RATE),
            start,
            0.115,
            pan,
        )
    return _stereo_to_pcm(_close_loop_seam(mix))


def track_desktop() -> np.ndarray:
    """Lo-Fi Hacker Chill: 75 BPM, тёплые seventh chords, bass и мягкий beat."""
    duration = MUSIC_TRACK_DURATIONS["track_desktop"]
    bpm = MUSIC_TRACK_BPMS["track_desktop"]
    beat = 60.0 / bpm
    bar = beat * 4.0
    mix = _empty_stereo(duration)
    pans = (-0.55, -0.25, 0.0, 0.26, 0.55)
    for chord_index, chord in enumerate(DESKTOP_CHORDS):
        start = chord_index * bar
        for voice, note in enumerate(chord):
            _mix_loop(
                mix,
                synth_pad(get_note_freq(note), bar + 0.38, AUDIO_SAMPLE_RATE),
                start,
                0.075 if voice < 2 else 0.060,
                pans[min(voice, len(pans) - 1)],
            )

    kick = drum_kick()
    hat = drum_hat()
    roots = ("A2", "F2", "C3", "G2", "A2")
    fifths = ("E3", "C3", "G3", "D3", "E3")
    for bar_index in range(5):
        bar_start = bar_index * bar
        for beat_index in range(4):
            beat_start = bar_start + beat_index * beat
            if beat_index in (0, 2):
                _mix_loop(mix, kick, beat_start, 0.24, -0.04 if beat_index == 0 else 0.04)
            bass_note = roots[bar_index] if beat_index in (0, 2) else fifths[bar_index]
            _mix_loop(
                mix,
                synth_bass(get_note_freq(bass_note), beat * 0.82, AUDIO_SAMPLE_RATE),
                beat_start,
                0.20,
                -0.10,
            )
        for eighth in range(8):
            _mix_loop(mix, hat, bar_start + eighth * beat / 2.0, 0.065, 0.34)

    melody = ("A4", "C5", "E5", "G5", "E5", "D5", "C5", "A4", "G4", "E4")
    for index, note in enumerate(melody):
        start = beat * (0.5 + index * 2.0)
        _mix_loop(
            mix,
            synth_pluck(get_note_freq(note), beat * 0.72, AUDIO_SAMPLE_RATE),
            start,
            0.095,
            -0.38 if index % 2 == 0 else 0.38,
        )
    return _stereo_to_pcm(_close_loop_seam(mix))


def track_hack() -> np.ndarray:
    """Synthwave Focus / Cyber Run: Am pentatonic arp at 115 BPM."""
    duration = MUSIC_TRACK_DURATIONS["track_hack"]
    bpm = MUSIC_TRACK_BPMS["track_hack"]
    beat = 60.0 / bpm
    bar = beat * 4.0
    sixteenth = beat / 4.0
    mix = _empty_stereo(duration)
    chord_cycle = (
        ("A2", "E3", "A3", "C4"),
        ("F2", "C3", "F3", "A3"),
        ("G2", "D3", "G3", "B3"),
        ("E2", "B2", "E3", "G3"),
    )
    kick = drum_kick()
    for bar_index in range(6):
        bar_start = bar_index * bar
        chord = chord_cycle[bar_index % len(chord_cycle)]
        for voice, note in enumerate(chord):
            _mix_loop(
                mix,
                synth_pad(get_note_freq(note), bar + 0.30, AUDIO_SAMPLE_RATE),
                bar_start,
                0.050,
                (-0.46, -0.15, 0.17, 0.46)[voice],
            )
        bass_pattern = (chord[0], chord[0], chord[1], chord[0])
        for beat_index, bass_note in enumerate(bass_pattern):
            beat_start = bar_start + beat_index * beat
            _mix_loop(mix, kick, beat_start, 0.22, 0.0)
            _mix_loop(
                mix,
                synth_bass(get_note_freq(bass_note), beat * 0.76, AUDIO_SAMPLE_RATE),
                beat_start,
                0.24,
                -0.08,
            )
    step_count = round(duration / sixteenth)
    for step in range(step_count):
        note = HACK_ARPEGGIO[step % len(HACK_ARPEGGIO)]
        _mix_loop(
            mix,
            synth_pluck(get_note_freq(note), sixteenth * 1.42, AUDIO_SAMPLE_RATE),
            step * sixteenth,
            0.090 if step % 4 else 0.115,
            -0.46 + (step % 8) / 7.0 * 0.92,
        )
    return _stereo_to_pcm(_close_loop_seam(mix))


def track_attack() -> np.ndarray:
    """System Breach / Red Alert: 135 BPM, сдержанное музыкальное напряжение."""
    duration = MUSIC_TRACK_DURATIONS["track_attack"]
    bpm = MUSIC_TRACK_BPMS["track_attack"]
    beat = 60.0 / bpm
    mix = _empty_stereo(duration)
    kick = drum_kick()
    hat = drum_hat()
    beat_count = round(duration / beat)
    suspense_chords = (
        ("D2", "A2", "D3", "F3"),
        ("A2", "E3", "A3", "C4"),
        ("F2", "C3", "F3", "A3"),
        ("E2", "B2", "E3", "G3"),
    )
    chord_span = beat * 2.0
    for chord_index in range(math.ceil(duration / chord_span)):
        chord = suspense_chords[chord_index % len(suspense_chords)]
        for voice, note in enumerate(chord):
            _mix_loop(
                mix,
                synth_pad(get_note_freq(note), chord_span + 0.24, AUDIO_SAMPLE_RATE),
                chord_index * chord_span,
                0.052,
                (-0.42, -0.13, 0.15, 0.42)[voice],
            )
    for beat_index in range(beat_count):
        start = beat_index * beat
        accent = 0.29 if beat_index % 4 == 0 else 0.22
        _mix_loop(mix, kick, start, accent, 0.0)
        bass_note = ATTACK_BASS_LINE[beat_index % len(ATTACK_BASS_LINE)]
        _mix_loop(
            mix,
            synth_bass(get_note_freq(bass_note), beat * 0.70, AUDIO_SAMPLE_RATE),
            start,
            0.27,
            -0.08,
        )
        _mix_loop(mix, hat, start + beat / 2.0, 0.055, 0.40)
        pulse_note = ("A3", "C4", "E4", "G4")[beat_index % 4]
        _mix_loop(
            mix,
            synth_pluck(get_note_freq(pulse_note), beat * 0.48, AUDIO_SAMPLE_RATE),
            start + beat * 0.48,
            0.080,
            0.34 if beat_index % 2 else -0.34,
        )
    return _stereo_to_pcm(_close_loop_seam(mix))


def sfx_click() -> np.ndarray:
    mix = _empty_stereo(SFX_CLICK_DURATION)
    tone = synth_pluck(220.0, SFX_CLICK_DURATION, AUDIO_SAMPLE_RATE)
    _mix_once(mix, tone, 0.0, 0.72, 0.0)
    return _stereo_to_pcm(mix, 0.32)


def sfx_notify() -> np.ndarray:
    mix = _empty_stereo(SFX_NOTIFY_DURATION)
    _mix_once(
        mix,
        synth_pluck(get_note_freq("E5"), 0.28, AUDIO_SAMPLE_RATE),
        0.00,
        0.58,
        -0.22,
    )
    _mix_once(
        mix,
        synth_pluck(get_note_freq("A5"), 0.30, AUDIO_SAMPLE_RATE),
        0.17,
        0.68,
        0.24,
    )
    return _stereo_to_pcm(mix, 0.52)


def sfx_success() -> np.ndarray:
    mix = _empty_stereo(SFX_SUCCESS_DURATION)
    for index, note in enumerate(("C5", "E5", "G5", "C6")):
        _mix_once(
            mix,
            synth_pluck(get_note_freq(note), 0.38, AUDIO_SAMPLE_RATE),
            index * 0.105,
            0.48,
            -0.42 + index * 0.28,
        )
    return _stereo_to_pcm(mix, 0.60)


def sfx_fail() -> np.ndarray:
    mix = _empty_stereo(SFX_FAIL_DURATION)
    for index, note in enumerate(("E3", "C3", "A2")):
        _mix_once(
            mix,
            synth_pad(get_note_freq(note), SFX_FAIL_DURATION, AUDIO_SAMPLE_RATE),
            0.0,
            0.20,
            (-0.30, 0.0, 0.30)[index],
        )
    _mix_once(
        mix,
        synth_pluck(get_note_freq("E3"), 0.46, AUDIO_SAMPLE_RATE),
        0.08,
        0.18,
        0.0,
    )
    return _stereo_to_pcm(mix, 0.40)


def sfx_typing() -> np.ndarray:
    mix = _empty_stereo(SFX_TYPING_DURATION)
    notes = ("A3", "C4", "A3", "E4", "C4")
    for index, note in enumerate(notes):
        _mix_once(
            mix,
            synth_pluck(get_note_freq(note), 0.045, AUDIO_SAMPLE_RATE),
            index * 0.067,
            0.24,
            -0.25 + index * 0.125,
        )
    return _stereo_to_pcm(mix, 0.28)


def sfx_alarm() -> np.ndarray:
    mix = _empty_stereo(SFX_ALARM_DURATION)
    for index, start in enumerate((0.0, 0.40, 0.80, 1.20)):
        note = "A3" if index % 2 == 0 else "E4"
        _mix_once(
            mix,
            synth_pluck(get_note_freq(note), 0.34, AUDIO_SAMPLE_RATE),
            start,
            0.42,
            -0.18 if index % 2 == 0 else 0.18,
        )
    return _stereo_to_pcm(mix, 0.46)


def sfx_install() -> np.ndarray:
    mix = _empty_stereo(SFX_INSTALL_DURATION)
    for voice, note in enumerate(("A2", "E3", "A3")):
        _mix_once(
            mix,
            synth_pad(get_note_freq(note), SFX_INSTALL_DURATION, AUDIO_SAMPLE_RATE),
            0.0,
            0.14,
            (-0.36, 0.0, 0.36)[voice],
        )
    for index, note in enumerate(("A3", "C4", "E4", "A4", "E4")):
        _mix_once(
            mix,
            synth_pluck(get_note_freq(note), 0.26, AUDIO_SAMPLE_RATE),
            0.10 + index * 0.16,
            0.24,
            -0.42 + index * 0.21,
        )
    return _stereo_to_pcm(mix, 0.50)


def sfx_coin() -> np.ndarray:
    frame_count = round(SFX_COIN_DURATION * AUDIO_SAMPLE_RATE)
    time_axis = np.arange(frame_count, dtype=np.float64) / AUDIO_SAMPLE_RATE
    signal = (
        np.sin(math.tau * 1800.0 * time_axis)
        + 0.34 * np.sin(math.tau * 3600.0 * time_axis + 0.15)
    ) * np.exp(-12.0 * time_axis)
    signal = apply_adsr(signal, 0.002, 0.025, 0.42, 0.15, AUDIO_SAMPLE_RATE)
    return _stereo_to_pcm(_pan_mono(_component_limit(signal), 0.12), 0.45)


def sfx_glitch() -> np.ndarray:
    mix = _empty_stereo(SFX_GLITCH_DURATION)
    _mix_once(
        mix,
        synth_pluck(get_note_freq("E4"), 0.09, AUDIO_SAMPLE_RATE),
        0.0,
        0.42,
        -0.22,
    )
    _mix_once(
        mix,
        synth_pluck(get_note_freq("C4"), 0.09, AUDIO_SAMPLE_RATE),
        0.05,
        0.36,
        0.22,
    )
    return _stereo_to_pcm(mix, 0.30)


class AudioManager:
    """Предрассчитывает, кэширует и воспроизводит весь процедурный звук игры."""

    TRACK_GENERATORS: ClassVar[dict[str, Callable[[], np.ndarray]]] = {
        "track_menu": track_menu,
        "track_desktop": track_desktop,
        "track_hack": track_hack,
        "track_attack": track_attack,
    }
    SFX_GENERATORS: ClassVar[dict[str, Callable[[], np.ndarray]]] = {
        "sfx_click": sfx_click,
        "sfx_notify": sfx_notify,
        "sfx_success": sfx_success,
        "sfx_fail": sfx_fail,
        "sfx_typing": sfx_typing,
        "sfx_alarm": sfx_alarm,
        "sfx_install": sfx_install,
        "sfx_coin": sfx_coin,
        "sfx_glitch": sfx_glitch,
    }

    def __init__(
        self,
        music_volume: float = MUSIC_DEFAULT_VOLUME,
        sfx_volume: float = SFX_DEFAULT_VOLUME,
    ) -> None:
        self.music_enabled = True
        self.effects_enabled = True
        self.music_volume = min(1.0, max(0.0, music_volume))
        self.sfx_volume = min(1.0, max(0.0, sfx_volume))
        self.music_duck_multiplier = 1.0
        self.music_auto_mode = True
        self.music_paused = False
        self.manual_music_track = "track_menu"
        self.current_music_track: str | None = None
        self.pending_music_track: str | None = None
        self.music_fade_remaining = 0.0
        self.music_track_elapsed = 0.0
        self.available = False
        self.mixer_config: tuple[int, int, int] | None = None
        self.compatibility_mode = False
        self.error = ""
        self.generation_progress = 0.0
        self.generation_label = ""
        self.generation_complete = False
        self.music_arrays: dict[str, np.ndarray] = {}
        self.sfx_arrays: dict[str, np.ndarray] = {}
        self.music_tracks: dict[str, pygame.mixer.Sound] = {}
        self.sound_bank: dict[str, pygame.mixer.Sound] = {}
        self.music_channel: pygame.mixer.Channel | None = None
        self.visualizer_values = [
            MUSIC_VISUALIZER_MIN_LEVEL for _ in range(MUSIC_VISUALIZER_BAR_COUNT)
        ]
        self.visualizer_elapsed = 0.0
        self.visualizer_random = random.Random(MUSIC_VISUALIZER_SEED)

    def _precompute_audio_cache(self) -> None:
        if self.generation_complete:
            return
        generators = tuple(self.TRACK_GENERATORS.items()) + tuple(
            self.SFX_GENERATORS.items()
        )
        for index, (audio_id, generator) in enumerate(generators, start=1):
            self.generation_label = audio_id
            samples = generator()
            if (
                samples.dtype != np.int16
                or samples.ndim != 2
                or samples.shape[1] != AUDIO_CHANNELS
            ):
                raise ValueError(f"Некорректный PCM-кэш: {audio_id} {samples.shape}")
            if audio_id.startswith("track_"):
                self.music_arrays[audio_id] = samples
            else:
                self.sfx_arrays[audio_id] = samples
            self.generation_progress = index / len(generators)
        self.generation_label = "ready"
        self.generation_complete = True

    @staticmethod
    def preconfigure_mixer() -> None:
        pygame.mixer.pre_init(
            AUDIO_SAMPLE_RATE,
            -16,
            AUDIO_CHANNELS,
            AUDIO_BUFFER_SIZE,
            allowedchanges=AUDIO_EXACT_ALLOWED_CHANGES,
        )

    @staticmethod
    def _open_mixer() -> tuple[int, int, int]:
        expected = (AUDIO_SAMPLE_RATE, -16, AUDIO_CHANNELS)
        current = pygame.mixer.get_init()
        if current == expected:
            return current
        if current is not None:
            pygame.mixer.quit()
        attempts = (
            (AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, AUDIO_EXACT_ALLOWED_CHANGES),
            (AUDIO_FALLBACK_SAMPLE_RATE, AUDIO_CHANNELS, AUDIO_EXACT_ALLOWED_CHANGES),
            (AUDIO_SAMPLE_RATE, AUDIO_FALLBACK_CHANNELS, AUDIO_EXACT_ALLOWED_CHANGES),
            (AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, AUDIO_COMPATIBLE_ALLOWED_CHANGES),
        )
        errors: list[str] = []
        for frequency, channels, allowed_changes in attempts:
            try:
                pygame.mixer.init(
                    frequency=frequency,
                    size=-16,
                    channels=channels,
                    buffer=AUDIO_BUFFER_SIZE,
                    allowedchanges=allowed_changes,
                )
                config = pygame.mixer.get_init()
                if config is not None and config[1] == -16 and config[2] in (1, 2):
                    return config
                errors.append(f"unsupported format {config}")
            except pygame.error as exc:
                errors.append(str(exc))
            if pygame.mixer.get_init() is not None:
                pygame.mixer.quit()
        raise pygame.error("; ".join(errors) or "audio mixer did not initialize")

    def _sound_from_array(self, samples: np.ndarray) -> pygame.mixer.Sound:
        config = self.mixer_config or pygame.mixer.get_init()
        if config is None:
            raise pygame.error("audio mixer is not initialized")
        mixer_frequency, mixer_format, mixer_channels = config
        if mixer_format != -16:
            raise pygame.error(f"unsupported mixer format: {mixer_format}")
        prepared = np.asarray(samples, dtype=np.int16)
        if mixer_frequency != AUDIO_SAMPLE_RATE:
            output_size = max(
                1,
                round(prepared.shape[0] * mixer_frequency / AUDIO_SAMPLE_RATE),
            )
            source_positions = (
                np.arange(output_size, dtype=np.float64)
                * AUDIO_SAMPLE_RATE
                / mixer_frequency
            )
            source_axis = np.arange(prepared.shape[0], dtype=np.float64)
            prepared = np.column_stack(
                tuple(
                    np.interp(source_positions, source_axis, prepared[:, channel])
                    for channel in range(AUDIO_CHANNELS)
                )
            ).astype(np.int16)
        if mixer_channels == 1:
            prepared = np.rint(np.mean(prepared.astype(np.float64), axis=1)).astype(
                np.int16
            )
        return pygame.sndarray.make_sound(np.ascontiguousarray(prepared))

    def initialize(self) -> None:
        self.available = False
        self.error = ""
        self.music_tracks = {}
        self.sound_bank = {}
        self.music_channel = None
        try:
            self._precompute_audio_cache()
            self.mixer_config = self._open_mixer()
            self.compatibility_mode = self.mixer_config != (
                AUDIO_SAMPLE_RATE,
                -16,
                AUDIO_CHANNELS,
            )
            pygame.mixer.set_num_channels(AUDIO_MIXER_CHANNEL_COUNT)
            pygame.mixer.set_reserved(AUDIO_RESERVED_MUSIC_CHANNELS)
            self.music_channel = pygame.mixer.Channel(0)
            self.music_tracks = {
                audio_id: self._sound_from_array(samples)
                for audio_id, samples in self.music_arrays.items()
            }
            self.sound_bank = {
                audio_id: self._sound_from_array(samples)
                for audio_id, samples in self.sfx_arrays.items()
            }
            self.available = True
            self.set_sfx_volume(self.sfx_volume)
            self.set_music_volume(self.music_volume)
        except (pygame.error, TypeError, ValueError) as exc:
            self.error = f"{type(exc).__name__}: {exc}"
            print(f"Предупреждение: звук отключён ({self.error})", file=sys.stderr)
            if pygame.mixer.get_init() is not None:
                pygame.mixer.quit()
            self.available = False
            self.mixer_config = None
            self.compatibility_mode = False
            self.music_tracks = {}
            self.sound_bank = {}
            self.music_channel = None

    def _apply_music_channel_volume(self) -> None:
        if self.music_channel is not None:
            self.music_channel.set_volume(
                self.music_volume * self.music_duck_multiplier
            )

    def set_music_volume(self, value: float) -> None:
        self.music_volume = min(1.0, max(0.0, float(value)))
        self._apply_music_channel_volume()

    def set_music_duck(self, multiplier: float) -> None:
        self.music_duck_multiplier = min(1.0, max(0.0, float(multiplier)))
        self._apply_music_channel_volume()

    def set_sfx_volume(self, value: float) -> None:
        self.sfx_volume = min(1.0, max(0.0, float(value)))
        for sound in self.sound_bank.values():
            sound.set_volume(self.sfx_volume)

    def play_sfx(self, sound_id: str) -> None:
        if not self.available or not self.effects_enabled:
            return
        resolved_id = SFX_LEGACY_ALIASES.get(sound_id, sound_id)
        sound = self.sound_bank.get(resolved_id)
        if sound is not None:
            sound.play()

    def stop_sfx(self, sound_id: str) -> None:
        resolved_id = SFX_LEGACY_ALIASES.get(sound_id, sound_id)
        sound = self.sound_bank.get(resolved_id)
        if sound is not None:
            sound.stop()

    def start_track(self, track_id: str, *, fade_in: bool = True) -> None:
        if (
            not self.available
            or not self.music_enabled
            or self.music_paused
            or self.music_channel is None
        ):
            self.pending_music_track = track_id
            return
        sound = self.music_tracks.get(track_id)
        if sound is None:
            return
        self._apply_music_channel_volume()
        self.music_channel.play(
            sound,
            loops=-1,
            fade_ms=MUSIC_FADE_IN_MS if fade_in else 0,
        )
        self.current_music_track = track_id
        self.pending_music_track = None
        self.music_fade_remaining = 0.0
        self.music_track_elapsed = 0.0

    def request_track(self, track_id: str, *, immediate: bool = False) -> None:
        if track_id not in MUSIC_TRACK_IDS:
            return
        if not self.available or not self.music_enabled or self.music_paused:
            self.pending_music_track = track_id
            return
        channel_busy = self.music_channel is not None and self.music_channel.get_busy()
        if self.current_music_track == track_id and channel_busy:
            self.pending_music_track = None
            return
        if self.pending_music_track == track_id and self.music_fade_remaining > 0.0:
            return
        if immediate or self.current_music_track is None or not channel_busy:
            self.start_track(track_id, fade_in=not immediate)
            return
        self.pending_music_track = track_id
        self.music_fade_remaining = MUSIC_FADE_OUT_SECONDS
        if self.music_channel is not None:
            self.music_channel.fadeout(MUSIC_FADE_OUT_MS)

    def _update_visualizer(self) -> None:
        track_id = self.current_music_track or self.manual_music_track
        base = MUSIC_TRACK_VISUALIZER_BASE.get(track_id, 0.30)
        bpm = MUSIC_TRACK_BPMS.get(track_id, 60.0)
        beat_phase = (self.music_track_elapsed * bpm / 60.0) % 1.0
        beat_pulse = (1.0 - beat_phase) ** 2.4
        self.visualizer_values = [
            min(
                1.0,
                MUSIC_VISUALIZER_MIN_LEVEL
                + base * (0.32 + beat_pulse * 0.56)
                + self.visualizer_random.random() * MUSIC_VISUALIZER_RANDOM_LEVEL
                + 0.04 * math.sin(index * 0.9 + self.music_track_elapsed * 4.0),
            )
            for index in range(MUSIC_VISUALIZER_BAR_COUNT)
        ]

    def update(self, delta_seconds: float, target_track: str) -> None:
        if not self.available:
            return
        if self.music_enabled and not self.music_paused:
            if target_track != self.current_music_track and target_track != self.pending_music_track:
                self.request_track(target_track)
            if self.music_fade_remaining > 0.0:
                self.music_fade_remaining = max(
                    0.0,
                    self.music_fade_remaining - delta_seconds,
                )
                if self.music_fade_remaining <= 0.0 and self.pending_music_track:
                    self.start_track(self.pending_music_track)
            elif (
                self.current_music_track is not None
                and self.music_channel is not None
                and not self.music_channel.get_busy()
            ):
                self.start_track(self.current_music_track, fade_in=False)
            if self.current_music_track is not None:
                duration = MUSIC_TRACK_DURATIONS[self.current_music_track]
                self.music_track_elapsed = (
                    self.music_track_elapsed + delta_seconds
                ) % duration
            self.visualizer_elapsed += delta_seconds
            if self.visualizer_elapsed >= MUSIC_VISUALIZER_UPDATE_SECONDS:
                self.visualizer_elapsed %= MUSIC_VISUALIZER_UPDATE_SECONDS
                self._update_visualizer()
        else:
            self.visualizer_values = [
                MUSIC_VISUALIZER_MIN_LEVEL for _ in range(MUSIC_VISUALIZER_BAR_COUNT)
            ]

    def toggle_pause(self, target_track: str) -> None:
        if not self.available:
            self.initialize()
            if not self.available:
                return
            self.music_paused = False
            self.request_track(target_track, immediate=True)
            return
        if not self.music_enabled:
            self.music_enabled = True
            self.music_paused = False
            self.request_track(target_track)
            return
        if self.music_paused:
            self.music_paused = False
            resume_track = self.pending_music_track or target_track
            if self.music_channel is not None and self.music_channel.get_busy():
                self.music_channel.unpause()
                if resume_track != self.current_music_track:
                    self.pending_music_track = None
                    self.request_track(resume_track)
            else:
                self.start_track(resume_track)
        else:
            self.music_paused = True
            if self.music_channel is not None:
                self.music_channel.pause()


# Плавное затемнение при переходах между экранами.
SCREEN_TRANSITION_SECONDS: Final[float] = 0.24
SCREEN_TRANSITION_MAX_ALPHA: Final[int] = 225

# Игровые часы: пять реальных минут равны одному игровому часу.
GAME_SECONDS_PER_HOUR: Final[float] = 300.0
GAME_START_HOUR: Final[float] = 20.0
GAME_NIGHT_START_HOUR: Final[int] = 22
GAME_NIGHT_END_HOUR: Final[int] = 6
GAME_NIGHT_DIFFICULTY_REDUCTION: Final[int] = 1
GAME_NIGHT_ATTACK_FREQUENCY_MULTIPLIER: Final[float] = 1.20
GAME_NIGHT_OVERLAY_ALPHA: Final[int] = 48
GAME_CLOCK_CENTER_POS: Final[tuple[int, int]] = (640, 10)
GAME_CLOCK_ICON_RADIUS: Final[int] = 6
GAME_CLOCK_ICON_POS: Final[tuple[int, int]] = (559, 18)
GAME_CLOCK_RAY_INSET: Final[int] = 3
GAME_CLOCK_RAY_LENGTH: Final[int] = 3
GAME_CLOCK_RAY_STEP_DEGREES: Final[int] = 45
GAME_CLOCK_CRESCENT_OFFSET: Final[tuple[int, int]] = (3, -2)

# JSON-сохранения. Нулевой слот — save.json, далее save1.json, save2.json и т.д.
SAVE_VERSION: Final[int] = 4
SAVE_DEFAULT_FILENAME: Final[str] = "save.json"
SAVE_SLOT_PREFIX: Final[str] = "save"
SAVE_SLOT_SUFFIX: Final[str] = ".json"
SAVE_MANAGER_PANEL_RECT: Final[tuple[int, int, int, int]] = (175, 74, 930, 574)
SAVE_MANAGER_TITLE_POS: Final[tuple[int, int]] = (220, 106)
SAVE_MANAGER_LIST_RECT: Final[tuple[int, int, int, int]] = (220, 164, 840, 342)
SAVE_MANAGER_ROW_HEIGHT: Final[int] = 58
SAVE_MANAGER_ROW_GAP: Final[int] = 7
SAVE_MANAGER_VISIBLE_ROWS: Final[int] = 5
SAVE_MANAGER_ROW_PADDING: Final[int] = 13
SAVE_MANAGER_BUTTON_WIDTH: Final[int] = 190
SAVE_MANAGER_BUTTON_HEIGHT: Final[int] = 50
SAVE_MANAGER_BUTTON_GAP: Final[int] = 16
SAVE_MANAGER_BUTTON_Y: Final[int] = 548
SAVE_MANAGER_SCROLLBAR_WIDTH: Final[int] = 7
SAVE_MANAGER_SCROLLBAR_MARGIN: Final[int] = 5
SAVE_MANAGER_SCROLLBAR_MIN_THUMB: Final[int] = 34
SAVE_MANAGER_SUBTITLE_Y_OFFSET: Final[int] = 36
SAVE_MANAGER_STATUS_Y: Final[int] = 522
SAVE_MANAGER_ROW_TITLE_Y_OFFSET: Final[int] = 9
SAVE_MANAGER_ROW_DETAILS_Y_OFFSET: Final[int] = 33
SAVE_MANAGER_FONT_SIZE: Final[int] = 13
SAVE_MANAGER_SMALL_FONT_SIZE: Final[int] = 11
DEFAULT_RESOLUTION_KEY: Final[str] = "1280x720"
FULLSCREEN_KEY: Final[str] = "fullscreen"
RESOLUTION_OPTIONS: Final[tuple[tuple[str, str, tuple[int, int] | None], ...]] = (
    ("1280x720", "1280 × 720", (1280, 720)),
    ("1920x1080", "1920 × 1080", (1920, 1080)),
    (FULLSCREEN_KEY, "Полный экран", None),
)
WINDOW_FLAGS: Final[int] = 0
FULLSCREEN_FLAGS: Final[int] = pygame.FULLSCREEN

# Состояния приложения.
STATE_CRT: Final[str] = "intro_crt"
STATE_BOOT: Final[str] = "intro_boot"
STATE_LOGO: Final[str] = "intro_logo"
STATE_MENU: Final[str] = "menu"
STATE_SETTINGS: Final[str] = "settings"
STATE_GUIDES: Final[str] = "guides"
STATE_SAVES: Final[str] = "saves"
STATE_DESKTOP: Final[str] = "desktop"
STATE_MINIGAME_LOCK: Final[str] = "minigame_lock"
STATE_MINIGAME_FIREWALL: Final[str] = "minigame_firewall"
STATE_MINIGAME_SNIFFER: Final[str] = "minigame_sniffer"
STATE_MINIGAME_NETWORK: Final[str] = "minigame_network"
STATE_MINIGAME_DDOS: Final[str] = "minigame_ddos"
STATE_MINIGAME_SOCIAL: Final[str] = "minigame_social"
STATE_INTRUSION_DEFENSE: Final[str] = "intrusion_defense"
STATE_POST_HACK: Final[str] = "post_hack"
STATE_HACK_PREP: Final[str] = "hack_prep"
STATE_ARREST: Final[str] = "arrest_game_over"
STATE_STORY_FINALE: Final[str] = "story_finale"
INTRO_STATES: Final[tuple[str, ...]] = (STATE_CRT, STATE_BOOT, STATE_LOGO)
MINIGAME_STATES: Final[tuple[str, ...]] = (
    STATE_MINIGAME_LOCK,
    STATE_MINIGAME_FIREWALL,
    STATE_MINIGAME_SNIFFER,
    STATE_MINIGAME_NETWORK,
    STATE_MINIGAME_DDOS,
    STATE_MINIGAME_SOCIAL,
    STATE_INTRUSION_DEFENSE,
)

# Общие размеры отрисовки.
THIN_LINE_WIDTH: Final[int] = 1
BORDER_WIDTH: Final[int] = 2
PANEL_CORNER_RADIUS: Final[int] = 14
BUTTON_CORNER_RADIUS: Final[int] = 12
SCREEN_EDGE_MARGIN: Final[int] = 34
TOP_STATUS_BAR_HEIGHT: Final[int] = 42
BOTTOM_STATUS_BAR_HEIGHT: Final[int] = 34
TOP_STATUS_LEFT_POS: Final[tuple[int, int]] = (SCREEN_EDGE_MARGIN, 13)
TOP_STATUS_RIGHT_POS: Final[tuple[int, int]] = (
    DESIGN_WIDTH - SCREEN_EDGE_MARGIN,
    13,
)
SCANLINE_GAP: Final[int] = 7
GRID_CELL_SIZE: Final[int] = 80
GRID_LINE_THICKNESS: Final[int] = 1
DECOR_CIRCLE_RADIUS: Final[int] = 4
DECOR_BLOCK_SIZE: Final[tuple[int, int]] = (42, 5)

# Шрифты (используются системные шрифты, изображения не загружаются).
FONT_CANDIDATES: Final[tuple[str, ...]] = (
    "dejavusansmono",
    "consolas",
    "couriernew",
    "arial",
)
FONT_SIZE_TINY: Final[int] = 12
FONT_SIZE_SMALL: Final[int] = 15
FONT_SIZE_BODY: Final[int] = 19
FONT_SIZE_BUTTON: Final[int] = 22
FONT_SIZE_HEADING: Final[int] = 34
FONT_SIZE_TITLE: Final[int] = 58
FONT_SIZE_LOGO: Final[int] = 92

# Вступление: CRT (1.5 сек), загрузка ОС (3 сек), затем логотип.
CRT_DURATION_SECONDS: Final[float] = 1.5
CRT_LINE_PHASE_RATIO: Final[float] = 0.34
CRT_LINE_MAX_WIDTH: Final[int] = 980
CRT_LINE_HEIGHT: Final[int] = 4
CRT_REVEAL_SIDE_MARGIN: Final[int] = 54
CRT_GLOW_HEIGHT: Final[int] = 12
BOOT_DURATION_SECONDS: Final[float] = 3.0
LOGO_DURATION_SECONDS: Final[float] = 2.2
GLITCH_HOLD_SECONDS: Final[float] = 0.1
GLITCH_CYCLE_SECONDS: Final[float] = 0.48
GLITCH_OFFSET_MIN: Final[int] = 2
GLITCH_OFFSET_MAX: Final[int] = 3
LOGO_CENTER_Y: Final[int] = 304
LOGO_SUBTITLE_Y: Final[int] = 395
LOGO_SKIP_TEXT_Y: Final[int] = 668
LOGO_TRACKING: Final[int] = 5

# Окно загрузки ОС.
BOOT_PANEL_RECT: Final[tuple[int, int, int, int]] = (150, 82, 980, 556)
BOOT_HEADER_RECT: Final[tuple[int, int, int, int]] = (150, 82, 980, 52)
BOOT_TITLE_POS: Final[tuple[int, int]] = (184, 96)
BOOT_LINES_X: Final[int] = 206
BOOT_LINES_START_Y: Final[int] = 184
BOOT_LINES_GAP: Final[int] = 46
BOOT_PROGRESS_RECT: Final[tuple[int, int, int, int]] = (206, 532, 868, 25)
BOOT_PROGRESS_INSET: Final[int] = 4
BOOT_PERCENT_Y: Final[int] = 574
BOOT_HINT_Y: Final[int] = 611
BOOT_LINES: Final[tuple[str, ...]] = (
    "mounting /dev/sda1... OK",
    "starting network... OK",
    "loading crypto modules... OK",
    "precomputing stereo audio cache... OK",
    "initializing zero-day interface... OK",
    "locking external telemetry... OK",
)

# Главное меню.
MENU_TITLE_Y: Final[int] = 104
MENU_SUBTITLE_Y: Final[int] = 171
MENU_BUTTON_WIDTH: Final[int] = 420
MENU_BUTTON_HEIGHT: Final[int] = 58
MENU_BUTTON_START_Y: Final[int] = 215
MENU_BUTTON_GAP: Final[int] = 9
MENU_FOOTER_Y: Final[int] = 682
MENU_STATUS_Y: Final[int] = 644
MENU_BUTTONS: Final[tuple[tuple[str, str], ...]] = (
    ("new_game", "Новая игра"),
    ("continue", "Продолжить"),
    ("saves", "Сохранения"),
    ("settings", "Настройки"),
    ("guides", "Гайды"),
    ("exit", "Выход"),
)

# Настройки разрешения, музыки и эффектов.
SETTINGS_PANEL_RECT: Final[tuple[int, int, int, int]] = (275, 44, 730, 632)
SETTINGS_TITLE_Y: Final[int] = 72
SETTINGS_SUBTITLE_Y: Final[int] = 114
SETTINGS_CHOICE_WIDTH: Final[int] = 430
SETTINGS_CHOICE_HEIGHT: Final[int] = 44
SETTINGS_CHOICE_START_Y: Final[int] = 140
SETTINGS_CHOICE_GAP: Final[int] = 54
SETTINGS_AUDIO_TITLE_Y: Final[int] = 320
SETTINGS_SLIDER_WIDTH: Final[int] = 430
SETTINGS_SLIDER_HEIGHT: Final[int] = 8
SETTINGS_SLIDER_KNOB_RADIUS: Final[int] = 10
SETTINGS_SLIDER_HIT_PADDING: Final[int] = 12
SETTINGS_MUSIC_SLIDER_RECT: Final[tuple[int, int, int, int]] = (425, 365, 430, 8)
SETTINGS_SFX_SLIDER_RECT: Final[tuple[int, int, int, int]] = (425, 422, 430, 8)
SETTINGS_MUSIC_LABEL_Y: Final[int] = 340
SETTINGS_SFX_LABEL_Y: Final[int] = 397
SETTINGS_SLIDER_LABEL_X: Final[int] = 425
SETTINGS_SLIDER_VALUE_X: Final[int] = 855
SETTINGS_ACTION_WIDTH: Final[int] = 220
SETTINGS_ACTION_HEIGHT: Final[int] = 50
SETTINGS_ACTION_Y: Final[int] = 530
SETTINGS_ACTION_GAP: Final[int] = 24
SETTINGS_AUDIO_BUTTON_SIZE: Final[tuple[int, int]] = (220, 42)
SETTINGS_AUDIO_BUTTON_Y: Final[int] = 460
SETTINGS_AUDIO_BUTTON_GAP: Final[int] = 24
SETTINGS_HELP_Y: Final[int] = 623

# Гайды: шесть прокручиваемых страниц.
GUIDES_PANEL_RECT: Final[tuple[int, int, int, int]] = (110, 65, 1060, 590)
GUIDES_TITLE_POS: Final[tuple[int, int]] = (145, 92)
GUIDES_NAV_RECT: Final[tuple[int, int, int, int]] = (135, 140, 230, 420)
GUIDES_CONTENT_RECT: Final[tuple[int, int, int, int]] = (390, 140, 740, 420)
GUIDES_SECTION_ROW_HEIGHT: Final[int] = 54
GUIDES_SECTION_ROW_GAP: Final[int] = 8
GUIDES_SECTION_PADDING: Final[int] = 14
GUIDES_CONTENT_PADDING: Final[int] = 20
GUIDES_TEXT_LINE_GAP: Final[int] = 29
GUIDES_PARAGRAPH_GAP: Final[int] = 19
GUIDES_SCROLL_STEP: Final[int] = 58
GUIDES_SCROLL_INTERPOLATION_RATE: Final[float] = 13.0
GUIDES_SCROLLBAR_WIDTH: Final[int] = 7
GUIDES_HEADER_META_OFFSET: Final[tuple[int, int]] = (390, 8)
GUIDES_PAGE_TITLE_HEIGHT: Final[int] = 52
GUIDES_MARKER_TEXT_OFFSET: Final[int] = 18
GUIDES_MARKER_Y_OFFSET: Final[int] = 7
GUIDES_MARKER_RADIUS: Final[int] = 3
GUIDES_SCROLLBAR_MIN_THUMB: Final[int] = 34
GUIDES_SECTION_FONT_SIZE: Final[int] = 13
GUIDES_BODY_FONT_SIZE: Final[int] = 15
GUIDES_PAGE_TITLE_FONT_SIZE: Final[int] = 23
GUIDES_BACK_RECT: Final[tuple[int, int, int, int]] = (920, 585, 210, 48)
GUIDE_SECTIONS: Final[tuple[dict[str, object], ...]] = (
    {
        "title": "01 // ИНТЕРФЕЙС",
        "paragraphs": (
            "Рабочий стол содержит семь приложений. Один клик открывает окно или поднимает его поверх остальных.",
            "Окна перетаскиваются за строку заголовка. Кнопки справа сворачивают, разворачивают и закрывают окно.",
            "Меню в верхнем левом углу открывает приложения, шесть мини-игр и настройку сложности.",
            "Верхняя панель показывает игровое время, подозрение, таймер атаки, BTC, VPN и реальные часы.",
            "F11 переключает полноэкранный режим. ESC сохраняет игру и возвращает на предыдущий экран.",
            "Наведите курсор на интерактивный элемент: рамка и цвет покажут, что его можно нажать.",
            "Колесо мыши прокручивает длинные страницы гайдов и список сохранений.",
        ),
    },
    {
        "title": "02 // ЗАКАЗЫ",
        "paragraphs": (
            "Messenger хранит заказы пяти постоянных клиентов. Первый заказ Ph4ntom является обучением.",
            "Примите заказ, завершите связанный взлом и выберите «Инфо для заказа», чтобы получить BTC и 1 SP.",
            "Отказ, провал, пропущенный дедлайн или закрытие доступа без доставки уменьшают репутацию.",
            "Репутация лежит в диапазоне -100…+100. Высокая репутация повышает выплаты и увеличивает дедлайны.",
            "Низкая репутация ускоряет атаки. После трёх обычных отказов один клиент организует ответный удар.",
            "Каждые пять успешно выполненных заказов открывается новая глава войны группировок.",
            "Красная точка у чата обозначает сюжетный заказ. Подписи двух кнопок являются настоящим выбором стороны.",
        ),
    },
    {
        "title": "03 // ВЗЛОМ",
        "paragraphs": (
            "Цели ищутся в Browser по типу: Обычный ПК, Телефон, Камеры, Сайт, Корпорация или Гос.система.",
            "Каждый тип маршрутизируется в подходящую мини-игру со сложностью от 1 до 5.",
            "Ночью целевые взломы получают -1 к сложности. Intrusion Defense не считается целевым взломом.",
            "Перед стартом можно применить совместимый одноразовый эксплойт, ботнет или поддельные документы.",
            "После успешного взлома доступно только одно действие: майнер, шантаж, данные, ransomware, заказ или proxy.",
            "Ransomware приносит крупную выплату, но всегда добавляет ровно 15% подозрения.",
            "Кража данных остаётся в диапазоне 0.020–0.100 BTC; улучшения меняют только нижнюю границу.",
            "ESC прерывает активную операцию, фиксирует результат заказа и создаёт ручное сохранение.",
        ),
    },
    {
        "title": "04 // ЗАЩИТА",
        "paragraphs": (
            "VPN хранит до пяти зарядов. Положительный заряд блокирует атаку и расходуется автоматически.",
            "За десять секунд до атаки щит мигает, а система показывает предупреждение INCOMING ATTACK.",
            "Без VPN запускается Intrusion Defense: нажимайте W, A, S или D, пока стрелка находится в зелёном кольце.",
            "Пять пропущенных стрелок означают взлом, потерю 0.05 BTC и рост подозрения на 10%.",
            "Подозрение ограничено 0–100%. При 100% происходит арест и появляется экран Game Over с мигалками.",
            "Ночью атаки происходят на 20% чаще. Репутация и ветка «Защита» меняют будущие интервалы.",
            "VPN покупается в DarkNet или пополняется действием Proxy после успешного взлома.",
        ),
    },
    {
        "title": "05 // НАВЫКИ",
        "paragraphs": (
            "Terminal открывает дерево из трёх веток: Взлом, Защита и Социальная инженерия.",
            "Навыки внутри ветки открываются сверху вниз. Стоимость указана на карточке и списывается навсегда.",
            "Взлом уменьшает сложность, добавляет время и повышает минимальный доход от кражи данных.",
            "Защита замедляет стрелки вторжения, отдаляет атаки и очищает подозрение после заказов.",
            "Социальная инженерия даёт стартовое доверие, повышает выплаты, репутацию и дедлайны.",
            "Каждый доставленный заказ даёт 1 SP. Курс кибербезопасности в DarkNet также немедленно даёт 1 SP.",
            "Майнеры создают ровно 0.001 BTC в минуту каждый; доход сначала накапливается в MinerManager.",
            "Перевод в CryptoWallet происходит только после нажатия «Снять доход».",
        ),
    },
    {
        "title": "06 // СИСТЕМА",
        "paragraphs": (
            "Пять реальных минут равны одному игровому часу. Ночь длится с 22:00 до 06:00.",
            "Реальные часы остаются справа, а игровые часы и индикатор DAY/NIGHT расположены в центре панели.",
            "Автосохранение выполняется после завершения или закрытия заказа. ESC выполняет ручное сохранение.",
            "Основной слот называется save.json. Новые слоты получают имена save1.json, save2.json и далее без лимита.",
            "Раздел «Сохранения» позволяет выбрать слот, загрузить его, перезаписать или начать новую историю.",
            "Четыре музыкальных лупа и девять эффектов генерируются NumPy и pygame.sndarray прямо в памяти.",
            "В настройках музыка и эффекты имеют отдельные ползунки и переключатели; MusicPlayer поддерживает авто и ручной режим.",
            "Входящие вызовы приходят раз в 5–10 минут на рабочем столе: информатор даёт бонус, мошенник проверяет осторожность, а угрозу нужно погасить новым VPN.",
            "Горячий заказ появляется раз в 15–20 минут: за 2 минуты он даёт награду x3 и +10 REP, но просрочка штрафует репутацию.",
            "Финал зависит от решений в четырёх сюжетных главах; после титра текущую сессию можно продолжить.",
        ),
    },
)

# Арест (Game Over) и экран сюжетного финала.
ARREST_LIGHT_BAR_HEIGHT: Final[int] = 112
ARREST_LIGHT_STRIPE_WIDTH: Final[int] = 128
ARREST_LIGHT_FLASH_SECONDS: Final[float] = 0.34
ARREST_SCANLINE_GAP: Final[int] = 9
ARREST_SCANLINE_ALPHA: Final[int] = 42
ARREST_PANEL_RECT: Final[tuple[int, int, int, int]] = (260, 154, 760, 414)
ARREST_TITLE_CENTER: Final[tuple[int, int]] = (640, 236)
ARREST_SUBTITLE_CENTER: Final[tuple[int, int]] = (640, 292)
ARREST_REASON_CENTER: Final[tuple[int, int]] = (640, 350)
ARREST_STATS_CENTER: Final[tuple[int, int]] = (640, 402)
ARREST_ATTEMPT_CENTER: Final[tuple[int, int]] = (640, 442)
ARREST_BUTTON_SIZE: Final[tuple[int, int]] = (250, 54)
ARREST_BUTTON_Y: Final[int] = 486
ARREST_BUTTON_GAP: Final[int] = 24
ARREST_TITLE_FONT_SIZE: Final[int] = 54
ARREST_SUBTITLE_FONT_SIZE: Final[int] = 20
ARREST_BODY_FONT_SIZE: Final[int] = 15
FINALE_PANEL_RECT: Final[tuple[int, int, int, int]] = (190, 92, 900, 544)
FINALE_TITLE_CENTER: Final[tuple[int, int]] = (640, 170)
FINALE_ENDING_CENTER: Final[tuple[int, int]] = (640, 232)
FINALE_DESCRIPTION_CENTER_Y: Final[int] = 292
FINALE_DESCRIPTION_MAX_WIDTH: Final[int] = 720
FINALE_DESCRIPTION_LINE_GAP: Final[int] = 25
FINALE_SCORES_CENTER: Final[tuple[int, int]] = (640, 408)
FINALE_STATS_CENTER: Final[tuple[int, int]] = (640, 446)
FINALE_BUTTON_SIZE: Final[tuple[int, int]] = (250, 54)
FINALE_BUTTON_Y: Final[int] = 520
FINALE_BUTTON_GAP: Final[int] = 24
FINALE_TITLE_FONT_SIZE: Final[int] = 24
FINALE_ENDING_FONT_SIZE: Final[int] = 36
FINALE_BODY_FONT_SIZE: Final[int] = 16

# Рабочий стол в стиле Kali Linux.
DESKTOP_TASKBAR_HEIGHT: Final[int] = 36
DESKTOP_TASKBAR_SEPARATOR_HEIGHT: Final[int] = 1
DESKTOP_PATTERN_CELL_SIZE: Final[int] = 56
DESKTOP_PATTERN_LINE_WIDTH: Final[int] = 1
DESKTOP_MENU_BUTTON_RECT: Final[tuple[int, int, int, int]] = (6, 4, 92, 28)
DESKTOP_MENU_TEXT_CENTER: Final[tuple[int, int]] = (52, 18)
DESKTOP_TASKBAR_CENTER_POS: Final[tuple[int, int]] = (335, 10)
DESKTOP_CLOCK_RIGHT_POS: Final[tuple[int, int]] = (1268, 9)
DESKTOP_BTC_RIGHT_POS: Final[tuple[int, int]] = (1027, 9)
DESKTOP_BTC_TEMPLATE: Final[str] = "₿ {balance:.3f}"
DESKTOP_BTC_TEXT_GAP: Final[int] = 4
DESKTOP_BTC_STROKE_WIDTH: Final[int] = 1
DESKTOP_BTC_STROKE_OFFSETS: Final[tuple[int, int]] = (2, 5)
DESKTOP_VPN_RECT: Final[tuple[int, int, int, int]] = (1038, 4, 116, 28)
DESKTOP_VPN_TEXT_POS: Final[tuple[int, int]] = (1087, 9)
DESKTOP_VPN_STATUS_CENTER: Final[tuple[int, int]] = (1076, 18)
DESKTOP_VPN_STATUS_RADIUS: Final[int] = 5
VPN_MAX_CHARGES: Final[int] = 5
DESKTOP_ATTACK_TIMER_RIGHT_POS: Final[tuple[int, int]] = (982, 9)
HACKER_ATTACK_INTERVAL_MIN_SECONDS: Final[float] = 120.0
HACKER_ATTACK_INTERVAL_MAX_SECONDS: Final[float] = 300.0
HACKER_ATTACK_INTERVAL_FLOOR_SECONDS: Final[float] = 60.0
HACKER_ATTACK_PROGRESS_REDUCTION: Final[float] = 0.035
HACKER_ATTACK_MIN_MULTIPLIER: Final[float] = 0.35
HACKER_ATTACK_REPUTATION_INFLUENCE: Final[float] = 0.25
HACKER_ATTACK_DEFENSE_SKILL_MULTIPLIER: Final[float] = 1.20
HACKER_ATTACK_WARNING_SECONDS: Final[float] = 10.0
HACKER_ATTACK_SHIELD_BLINK_SECONDS: Final[float] = 0.3
DESKTOP_SUSPICION_BAR_RECT: Final[tuple[int, int, int, int]] = (760, 28, 140, 4)
DESKTOP_SUSPICION_BAR_INSET: Final[int] = 1
DESKTOP_VPN_SHIELD_ORIGIN: Final[tuple[int, int]] = (1048, 9)
DESKTOP_VPN_SHIELD_PARTS: Final[tuple[tuple[int, int, int, int], ...]] = (
    (2, 0, 16, 3),
    (0, 3, 20, 7),
    (2, 10, 16, 3),
    (5, 13, 10, 3),
    (8, 16, 4, 2),
)
DESKTOP_INITIAL_BTC: Final[float] = 0.0
DESKTOP_ICON_SIZE: Final[int] = 64
DESKTOP_ICON_HIT_WIDTH: Final[int] = 112
DESKTOP_ICON_HIT_HEIGHT: Final[int] = 108
DESKTOP_ICON_START_X: Final[int] = 42
DESKTOP_ICON_START_Y: Final[int] = 76
DESKTOP_ICON_COLUMN_STEP: Final[int] = 130
DESKTOP_ICON_ROW_STEP: Final[int] = 132
DESKTOP_ICON_COLUMNS: Final[int] = 4
DESKTOP_ICON_LABEL_OFFSET_Y: Final[int] = 73
DESKTOP_ICON_LABEL_FONT_SIZE: Final[int] = 12
DESKTOP_ICON_SYMBOL_FONT_SIZE: Final[int] = 25
DESKTOP_ICON_OPEN_MARKER_WIDTH: Final[int] = 24
DESKTOP_ICON_OPEN_MARKER_HEIGHT: Final[int] = 3
DESKTOP_ICON_OPEN_MARKER_BOTTOM_MARGIN: Final[int] = 4
DESKTOP_ICON_CORNER_RADIUS: Final[int] = 9
DESKTOP_ICON_HOVER_EXPANSION: Final[int] = 7
DESKTOP_ICON_HOVER_BORDER_WIDTH: Final[int] = 3
DESKTOP_TASKBAR_FONT_SIZE: Final[int] = 13
DESKTOP_APPS: Final[tuple[tuple[str, str, str], ...]] = (
    ("messenger", "Messenger", "M"),
    ("browser", "Browser", "WWW"),
    ("darknet", "DarkNet", "DN"),
    ("terminal", "Terminal", ">_"),
    ("crypto_wallet", "CryptoWallet", "CW"),
    ("miner_manager", "MinerManager", "MM"),
    ("music_player", "MusicPlayer", "MP"),
)

# Выпадающее меню рабочего стола.
DESKTOP_LAUNCHER_RECT: Final[tuple[int, int, int, int]] = (6, 36, 262, 620)
DESKTOP_LAUNCHER_HEADER_POS: Final[tuple[int, int]] = (20, 51)
DESKTOP_LAUNCHER_ITEM_START_Y: Final[int] = 82
DESKTOP_LAUNCHER_ITEM_X: Final[int] = 14
DESKTOP_LAUNCHER_ITEM_WIDTH: Final[int] = 246
DESKTOP_LAUNCHER_ITEM_HEIGHT: Final[int] = 34
DESKTOP_LAUNCHER_SYMBOL_X: Final[int] = 25
DESKTOP_LAUNCHER_TEXT_X: Final[int] = 60
DESKTOP_LAUNCHER_ITEM_TEXT_OFFSET_Y: Final[int] = 8
DESKTOP_LAUNCHER_MINIGAME_HEADER_POS: Final[tuple[int, int]] = (20, 330)
DESKTOP_LAUNCHER_MINIGAME_START_Y: Final[int] = 352
DESKTOP_LAUNCHER_DIFFICULTY_RECT: Final[tuple[int, int, int, int]] = (
    14,
    566,
    246,
    34,
)
DESKTOP_LAUNCHER_HOME_RECT: Final[tuple[int, int, int, int]] = (14, 610, 246, 34)
DESKTOP_LAUNCHER_BORDER_RADIUS: Final[int] = 7
DESKTOP_LAUNCHER_FONT_SIZE: Final[int] = 13

# Полноэкранные мини-игры и общие элементы.
MINIGAME_DIFFICULTY_MIN: Final[int] = 1
MINIGAME_DIFFICULTY_MAX: Final[int] = 5
MINIGAME_DEFAULT_DIFFICULTY: Final[int] = 3
MINIGAME_ENTRIES: Final[tuple[tuple[str, str, str], ...]] = (
    ("bruteforce_lock", "Взлом замка", "BF"),
    ("firewall_maze", "Обход фаерволла", "FW"),
    ("packet_sniffer", "Перехват данных", "PS"),
    ("network_nodes", "Взлом сети", "NN"),
    ("ddos_clicker", "DDoS-атака", "DD"),
    ("social_engineering", "Социальная инженерия", "SE"),
)
MINIGAME_HEADER_HEIGHT: Final[int] = 76
MINIGAME_BACK_RECT: Final[tuple[int, int, int, int]] = (22, 17, 132, 42)
MINIGAME_BACK_FONT_SIZE: Final[int] = 16
MINIGAME_TITLE_CENTER: Final[tuple[int, int]] = (640, 28)
MINIGAME_TIMER_CENTER: Final[tuple[int, int]] = (640, 55)
MINIGAME_DIFFICULTY_RIGHT_POS: Final[tuple[int, int]] = (1252, 27)
MINIGAME_INFO_FONT_SIZE: Final[int] = 15
MINIGAME_RESULT_PANEL_RECT: Final[tuple[int, int, int, int]] = (390, 205, 500, 310)
MINIGAME_RESULT_TITLE_CENTER: Final[tuple[int, int]] = (640, 302)
MINIGAME_RESULT_TEXT_CENTER: Final[tuple[int, int]] = (640, 365)
MINIGAME_RESULT_OK_RECT: Final[tuple[int, int, int, int]] = (530, 420, 220, 54)
MINIGAME_RESULT_TITLE_FONT_SIZE: Final[int] = 48
MINIGAME_RESULT_TEXT_FONT_SIZE: Final[int] = 16
MINIGAME_RESULT_CORNER_RADIUS: Final[int] = 14

# BruteForceLock.
LOCK_CENTER: Final[tuple[int, int]] = (640, 397)
LOCK_RING_RADII: Final[tuple[int, ...]] = (86, 124, 162, 200, 238)
LOCK_RING_COUNT_BASE: Final[int] = 3
LOCK_RING_COUNT_DIFFICULTY_STEP: Final[int] = 2
LOCK_RING_WIDTH: Final[int] = 12
LOCK_RING_SELECTED_EXTRA_WIDTH: Final[int] = 3
LOCK_RING_CLICK_TOLERANCE: Final[int] = 18
LOCK_CORRECT_ZONE_DEGREES: Final[float] = 15.0
LOCK_TARGET_ARC_WIDTH: Final[int] = 4
LOCK_CURRENT_ARC_DEGREES: Final[float] = 18.0
LOCK_KEY_ROTATION_SPEED: Final[float] = 95.0
LOCK_WHEEL_ROTATION_DEGREES: Final[float] = 7.0
LOCK_TIME_BASE_SECONDS: Final[float] = 45.0
LOCK_TIME_DIFFICULTY_PENALTY: Final[float] = 5.0
LOCK_INSTRUCTION_CENTER: Final[tuple[int, int]] = (640, 683)
LOCK_INSTRUCTION_FONT_SIZE: Final[int] = 13
LOCK_CENTER_SQUARE_SIZE: Final[int] = 34

# FirewallMaze.
FIREWALL_MAZE_RECT: Final[tuple[int, int, int, int]] = (94, 94, 1092, 566)
FIREWALL_GRID_COLUMNS_BASE: Final[int] = 8
FIREWALL_GRID_COLUMNS_STEP: Final[int] = 2
FIREWALL_GRID_ROWS_BASE: Final[int] = 5
FIREWALL_WALL_THICKNESS: Final[int] = 5
FIREWALL_PLAYER_SIZE: Final[int] = 16
FIREWALL_PLAYER_SPEED: Final[float] = 205.0
FIREWALL_EXIT_SIZE: Final[int] = 26
FIREWALL_SCANNER_COUNT_BASE: Final[int] = 1
FIREWALL_SCANNER_RADIUS: Final[int] = 11
FIREWALL_SCANNER_SPEED_BASE: Final[float] = 1.0
FIREWALL_SCANNER_SPEED_STEP: Final[float] = 0.13
FIREWALL_SCANNER_MARGIN: Final[int] = 24
FIREWALL_RESET_INVULNERABILITY: Final[float] = 0.75
FIREWALL_TIME_BASE_SECONDS: Final[float] = 90.0
FIREWALL_TIME_DIFFICULTY_PENALTY: Final[float] = 8.0
FIREWALL_HIT_TEXT_POS: Final[tuple[int, int]] = (110, 674)

# PacketSniffer.
SNIFFER_FIELD_RECT: Final[tuple[int, int, int, int]] = (78, 92, 1124, 558)
SNIFFER_PACKET_SIZE: Final[tuple[int, int]] = (20, 30)
SNIFFER_BAR_SIZE: Final[tuple[int, int]] = (80, 20)
SNIFFER_BAR_Y: Final[int] = 616
SNIFFER_TIME_SECONDS: Final[float] = 30.0
SNIFFER_TARGET_BASE: Final[int] = 6
SNIFFER_TARGET_DIFFICULTY_STEP: Final[int] = 2
SNIFFER_SPAWN_BASE_SECONDS: Final[float] = 0.9
SNIFFER_SPAWN_DIFFICULTY_STEP: Final[float] = 0.1
SNIFFER_SPAWN_MIN_SECONDS: Final[float] = 0.3
SNIFFER_SPEED_BASE: Final[float] = 145.0
SNIFFER_SPEED_DIFFICULTY_STEP: Final[float] = 26.0
SNIFFER_SPEED_VARIATION: Final[float] = 45.0
SNIFFER_TARGET_CHANCE_BASE: Final[float] = 0.62
SNIFFER_TARGET_CHANCE_DIFFICULTY_STEP: Final[float] = 0.045
SNIFFER_TRASH_PENALTY: Final[int] = 1
SNIFFER_PACKET_FONT_SIZE: Final[int] = 11
SNIFFER_INSTRUCTION_CENTER: Final[tuple[int, int]] = (640, 681)
SNIFFER_FLASH_SECONDS: Final[float] = 0.22

# NetworkNodes.
NETWORK_PLAY_RECT: Final[tuple[int, int, int, int]] = (90, 102, 1100, 535)
NETWORK_NODE_COUNT_MIN: Final[int] = 6
NETWORK_NODE_COUNT_MAX: Final[int] = 12
NETWORK_NODE_COUNT_DIFFICULTY_STEP: Final[float] = 1.5
NETWORK_NODE_RADIUS: Final[int] = 18
NETWORK_NODE_DRAG_RADIUS: Final[int] = 26
NETWORK_LINE_WIDTH: Final[int] = 3
NETWORK_PLANAR_LAYOUT_RADIUS: Final[int] = 225
NETWORK_LAYOUT_CENTER: Final[tuple[int, int]] = (640, 370)
NETWORK_RANDOM_MARGIN: Final[int] = 42
NETWORK_INITIAL_SHUFFLES: Final[int] = 20
NETWORK_TIME_BASE_SECONDS: Final[float] = 100.0
NETWORK_TIME_DIFFICULTY_PENALTY: Final[float] = 10.0
NETWORK_STATUS_CENTER: Final[tuple[int, int]] = (640, 676)
NETWORK_NODE_FONT_SIZE: Final[int] = 12

# DDoSClicker.
DDOS_HP_BAR_RECT: Final[tuple[int, int, int, int]] = (320, 112, 640, 32)
DDOS_HP_BAR_INSET: Final[int] = 4
DDOS_SERVER_RECT: Final[tuple[int, int, int, int]] = (390, 184, 500, 276)
DDOS_SERVER_LIGHT_SIZE: Final[int] = 12
DDOS_SERVER_LIGHT_GAP: Final[int] = 26
DDOS_SERVER_LIGHT_START: Final[tuple[int, int]] = (430, 218)
DDOS_SERVER_SLOT_RECT: Final[tuple[int, int, int, int]] = (455, 300, 370, 62)
DDOS_COOLDOWN_BAR_RECT: Final[tuple[int, int, int, int]] = (430, 535, 420, 20)
DDOS_REQUEST_BUTTON_RECT: Final[tuple[int, int, int, int]] = (430, 574, 420, 62)
DDOS_SERVER_HP_BASE: Final[int] = 20
DDOS_SERVER_HP_DIFFICULTY_STEP: Final[int] = 20
DDOS_MAX_REQUESTS_PER_SECOND: Final[int] = 5
DDOS_RATE_WINDOW_SECONDS: Final[float] = 1.0
DDOS_OVERHEAT_SECONDS: Final[float] = 2.0
DDOS_TIME_SECONDS: Final[float] = 55.0
DDOS_BUTTON_FONT_SIZE: Final[int] = 20
DDOS_STATUS_CENTER: Final[tuple[int, int]] = (640, 674)

# SocialEngineering.
SOCIAL_TRUST_BAR_RECT: Final[tuple[int, int, int, int]] = (300, 94, 680, 26)
SOCIAL_TRUST_BAR_INSET: Final[int] = 4
SOCIAL_NPC_RECT: Final[tuple[int, int, int, int]] = (170, 145, 940, 188)
SOCIAL_NPC_TEXT_POS: Final[tuple[int, int]] = (198, 182)
SOCIAL_NPC_TEXT_MAX_WIDTH: Final[int] = 884
SOCIAL_NPC_LINE_HEIGHT: Final[int] = 24
SOCIAL_OPTION_START_Y: Final[int] = 372
SOCIAL_OPTION_X: Final[int] = 190
SOCIAL_OPTION_WIDTH: Final[int] = 900
SOCIAL_OPTION_HEIGHT: Final[int] = 56
SOCIAL_OPTION_GAP: Final[int] = 12
SOCIAL_OPTION_TEXT_PADDING: Final[int] = 16
SOCIAL_ROUND_COUNT_BASE: Final[int] = 4
SOCIAL_ROUND_COUNT_DIFFICULTY_STEP: Final[int] = 2
SOCIAL_CORRECT_MIN_DELTA: Final[int] = 20
SOCIAL_CORRECT_MAX_DELTA: Final[int] = 30
SOCIAL_WRONG_DELTA: Final[int] = -15
SOCIAL_TIME_SECONDS: Final[float] = 120.0
SOCIAL_FEEDBACK_CENTER: Final[tuple[int, int]] = (640, 350)

# Intrusion Defense — защита центрального сервера клавишами WASD.
INTRUSION_DURATION_MIN_SECONDS: Final[float] = 30.0
INTRUSION_DURATION_MAX_SECONDS: Final[float] = 45.0
INTRUSION_MAX_MISSES: Final[int] = 5
INTRUSION_BTC_LOSS: Final[float] = 0.05
INTRUSION_SUSPICION_PENALTY: Final[float] = 10.0
INTRUSION_CENTER: Final[tuple[int, int]] = (640, 386)
INTRUSION_SERVER_RADIUS: Final[int] = 42
INTRUSION_SERVER_INNER_RADIUS: Final[int] = 26
INTRUSION_HIT_ZONE_INNER_RADIUS: Final[int] = 112
INTRUSION_HIT_ZONE_OUTER_RADIUS: Final[int] = 172
INTRUSION_HIT_ZONE_WIDTH: Final[int] = 3
INTRUSION_SPAWN_MARGIN: Final[int] = 72
INTRUSION_ARROW_SIZE: Final[int] = 14
INTRUSION_ARROW_TRAIL_LENGTH: Final[int] = 30
INTRUSION_ARROW_LINE_WIDTH: Final[int] = 3
INTRUSION_ARROW_WING_SCALE: Final[float] = 0.65
INTRUSION_PROGRESS_PER_DIFFICULTY: Final[int] = 4
INTRUSION_SPEED_BASE: Final[float] = 138.0
INTRUSION_SPEED_DIFFICULTY_STEP: Final[float] = 16.0
INTRUSION_SPEED_VARIATION: Final[float] = 24.0
INTRUSION_SPAWN_INTERVAL_BASE: Final[float] = 1.6
INTRUSION_SPAWN_INTERVAL_DIFFICULTY_STEP: Final[float] = 0.12
INTRUSION_SPAWN_INTERVAL_MIN: Final[float] = 0.72
INTRUSION_INITIAL_SPAWN_DELAY: Final[float] = 0.8
INTRUSION_DAMAGE_FLASH_SECONDS: Final[float] = 0.28
INTRUSION_SUCCESS_FLASH_SECONDS: Final[float] = 0.12
INTRUSION_WRONG_KEY_FLASH_SECONDS: Final[float] = 0.16
INTRUSION_FLASH_ALPHA_MAX: Final[int] = 95
INTRUSION_ZONE_FILL_ALPHA: Final[int] = 20
INTRUSION_ZONE_LINE_WIDTH: Final[int] = 2
INTRUSION_PULSE_PERIOD_SECONDS: Final[float] = 1.0
INTRUSION_PULSE_RADIUS_RANGE: Final[int] = 18
INTRUSION_SCANLINE_GAP: Final[int] = 12
INTRUSION_SCANLINE_ALPHA: Final[int] = 24
INTRUSION_KEY_FONT_SIZE: Final[int] = 42
INTRUSION_LABEL_FONT_SIZE: Final[int] = 14
INTRUSION_ZONE_LABEL_POSITIONS: Final[dict[str, tuple[int, int]]] = {
    "w": (640, 154),
    "a": (105, 386),
    "s": (640, 565),
    "d": (1175, 386),
}
INTRUSION_INSTRUCTION_CENTER: Final[tuple[int, int]] = (640, 650)
INTRUSION_STATUS_CENTER: Final[tuple[int, int]] = (640, 682)
INTRUSION_ALERT_TEXT_CENTER: Final[tuple[int, int]] = (640, 98)
INTRUSION_ALERT_BAR_HEIGHT: Final[int] = 5
INTRUSION_VIGNETTE_WIDTH: Final[int] = 14

SOCIAL_DIALOGUES: Final[list[dict[str, object]]] = [
    {
        "npc": "Служба безопасности. Назовите причину запроса временного доступа.",
        "options": [
            {
                "text": "Плановая проверка по заявке INC-2048.",
                "delta": 25,
                "correct": True,
            },
            {
                "text": "Мне срочно нужен пароль администратора.",
                "delta": -15,
                "correct": False,
            },
            {
                "text": "Просто откройте доступ, объясню потом.",
                "delta": -15,
                "correct": False,
            },
        ],
    },
    {
        "npc": "Я не вижу вашу заявку. Кто подтвердил проведение проверки?",
        "options": [
            {
                "text": "Никто. Давайте обойдём процедуру.",
                "delta": -15,
                "correct": False,
            },
            {
                "text": "Дежурный менеджер; могу повторно отправить номер заявки.",
                "delta": 30,
                "correct": True,
            },
            {
                "text": "Это секретная операция, вопросы запрещены.",
                "delta": -15,
                "correct": False,
            },
            {"text": "Если не поможете, вас уволят.", "delta": -15, "correct": False},
        ],
    },
    {
        "npc": "Какие данные вам нужны для диагностики?",
        "options": [
            {
                "text": "Ваш постоянный пароль и резервные коды.",
                "delta": -15,
                "correct": False,
            },
            {"text": "Полная копия базы клиентов.", "delta": -15, "correct": False},
            {
                "text": "Только одноразовый код тестового контура.",
                "delta": 25,
                "correct": True,
            },
        ],
    },
    {
        "npc": "Почему запрос поступил вне обычного рабочего времени?",
        "options": [
            {
                "text": "Окно обслуживания указано в заявке; могу подождать подтверждение.",
                "delta": 25,
                "correct": True,
            },
            {"text": "Так меньше свидетелей.", "delta": -15, "correct": False},
            {"text": "Не задавайте лишних вопросов.", "delta": -15, "correct": False},
            {"text": "Я забыл выполнить задачу днём.", "delta": -15, "correct": False},
        ],
    },
    {
        "npc": "Как я смогу проверить, что сессия завершена безопасно?",
        "options": [
            {"text": "Никак, следы будут удалены.", "delta": -15, "correct": False},
            {
                "text": "Получите отчёт и уведомление об отзыве временного токена.",
                "delta": 30,
                "correct": True,
            },
            {
                "text": "Токен останется активным навсегда.",
                "delta": -15,
                "correct": False,
            },
        ],
    },
    {
        "npc": "Последняя проверка: что делать при сомнении в личности оператора?",
        "options": [
            {
                "text": "Передать доступ и сообщить позже.",
                "delta": -15,
                "correct": False,
            },
            {
                "text": "Позвонить на номер из сообщения.",
                "delta": -15,
                "correct": False,
            },
            {
                "text": "Остановить запрос и связаться через официальный канал.",
                "delta": 30,
                "correct": True,
            },
            {"text": "Отправить пароль в общий чат.", "delta": -15, "correct": False},
        ],
    },
]

TARGET_MINIGAME_MAP: Final[dict[str, tuple[str, ...]]] = {
    "cameras": ("packet_sniffer",),
    "website": ("firewall_maze",),
    "network": ("network_nodes", "firewall_maze"),
    "server": ("ddos_clicker", "network_nodes"),
    "encrypted": ("bruteforce_lock",),
    "human": ("social_engineering",),
    "data": ("packet_sniffer", "bruteforce_lock"),
}
TARGET_CATEGORY_KEYWORDS: Final[dict[str, tuple[str, ...]]] = {
    "cameras": ("камер", "video", "видео"),
    "website": ("сайт", "web", "веб"),
    "network": ("сеть", "узел", "ретранслятор"),
    "server": ("сервер", "кластер", "server"),
    "encrypted": ("архив", "замок", "ключ", "шифр"),
    "human": ("оператор", "профиль", "социальн"),
    "data": ("данн", "контейнер", "пакет"),
}

# Типы и каталог доступных целей Browser.
TARGET_TYPES: Final[dict[str, dict[str, object]]] = {
    "Обычный ПК": {
        "difficulty": 1,
        "protection": "Низкий",
        "category": "data",
        "description": "Домашняя рабочая станция с базовой защитой.",
        "minigames": ("bruteforce_lock",),
    },
    "Телефон": {
        "difficulty": 2,
        "protection": "Умеренный",
        "category": "human",
        "description": "Мобильное устройство с PIN и социальной защитой.",
        "minigames": ("social_engineering",),
    },
    "Камеры": {
        "difficulty": 3,
        "protection": "Средний",
        "category": "cameras",
        "description": "Изолированная система видеонаблюдения.",
        "minigames": ("packet_sniffer",),
    },
    "Сайт": {
        "difficulty": 3,
        "protection": "Средний",
        "category": "website",
        "description": "Веб-узел с фильтрацией запросов и firewall.",
        "minigames": ("firewall_maze",),
    },
    "Корпорация": {
        "difficulty": 4,
        "protection": "Высокий",
        "category": "network",
        "description": "Корпоративная сеть с сегментацией и IDS.",
        "minigames": ("network_nodes",),
    },
    "Гос.система": {
        "difficulty": 5,
        "protection": "Критический",
        "category": "server",
        "description": "Защищённый государственный учебный контур.",
        "minigames": ("ddos_clicker",),
    },
}
TARGET_CATALOG: Final[list[dict[str, str]]] = [
    {"name": "PC-NOVA-17", "type": "Обычный ПК", "location": "домашняя подсеть"},
    {"name": "WORKSTATION-404", "type": "Обычный ПК", "location": "коворкинг"},
    {"name": "NEON-PHONE", "type": "Телефон", "location": "мобильный оператор"},
    {"name": "GHOST-HANDSET", "type": "Телефон", "location": "тестовая SIM-сеть"},
    {"name": "CAM-GRID-12", "type": "Камеры", "location": "склад Red Harbor"},
    {"name": "EYE-NET", "type": "Камеры", "location": "парковочный комплекс"},
    {"name": "ORION-WEB", "type": "Сайт", "location": "публичный DMZ"},
    {"name": "NEON-MARKET", "type": "Сайт", "location": "тестовый магазин"},
    {"name": "HELIX-CORP", "type": "Корпорация", "location": "офисный кластер"},
    {"name": "AXIOM-HQ", "type": "Корпорация", "location": "корпоративный VPN"},
    {"name": "GOV-NODE-7", "type": "Гос.система", "location": "учебный полигон"},
    {"name": "STATE-ARCHIVE", "type": "Гос.система", "location": "закрытый контур"},
]

# Каталог DarkNet: категории, товары и одноразовый инвентарь.
DARKNET_APP_ID: Final[str] = "darknet"
CRYPTO_WALLET_APP_ID: Final[str] = "crypto_wallet"
DARKNET_CATEGORIES: Final[tuple[tuple[str, str], ...]] = (
    ("vpn", "VPN"),
    ("exploits", "Эксплойты"),
    ("botnets", "Ботнеты"),
    ("malware", "Малварь"),
    ("documents", "Документы"),
    ("courses", "Курсы"),
)
DARKNET_PRODUCTS: Final[tuple[dict[str, object], ...]] = (
    {
        "id": "vpn_basic",
        "category": "vpn",
        "name": "VPN: Basic",
        "description": "+1 заряд VPN",
        "price": 0.01,
        "vpn_charges": 1,
    },
    {
        "id": "vpn_pro",
        "category": "vpn",
        "name": "VPN: Pro",
        "description": "+3 заряда VPN",
        "price": 0.03,
        "vpn_charges": 3,
    },
    {
        "id": "vpn_military",
        "category": "vpn",
        "name": "VPN: Military",
        "description": "+5 зарядов VPN",
        "price": 0.08,
        "vpn_charges": 5,
    },
    {
        "id": "lock_override",
        "category": "exploits",
        "name": "Lock Override",
        "description": "−1 кольцо; шире зона фиксации",
        "price": 0.02,
        "game_id": "bruteforce_lock",
    },
    {
        "id": "firewall_bypass",
        "category": "exploits",
        "name": "Firewall Bypass",
        "description": "Сканеры медленнее на 25%",
        "price": 0.02,
        "game_id": "firewall_maze",
    },
    {
        "id": "packet_filter",
        "category": "exploits",
        "name": "Packet Filter",
        "description": "Вредных пакетов меньше на 30%",
        "price": 0.02,
        "game_id": "packet_sniffer",
    },
    {
        "id": "topology_solver",
        "category": "exploits",
        "name": "Topology Solver",
        "description": "Удаляет два узла сети",
        "price": 0.02,
        "game_id": "network_nodes",
    },
    {
        "id": "traffic_amplifier",
        "category": "exploits",
        "name": "Traffic Amplifier",
        "description": "−25% HP; перегрев медленнее",
        "price": 0.02,
        "game_id": "ddos_clicker",
    },
    {
        "id": "osint_dossier",
        "category": "exploits",
        "name": "OSINT Dossier",
        "description": "−1 неверный ответ в раунде",
        "price": 0.02,
        "game_id": "social_engineering",
    },
    {
        "id": "botnet_pc",
        "category": "botnets",
        "name": "PC Botnet",
        "description": "Авто-взлом обычного ПК",
        "price": 0.05,
    },
    {
        "id": "malware_miner",
        "category": "malware",
        "name": "Майнер",
        "description": "+0.001 BTC к добыче при установке",
        "price": 0.005,
    },
    {
        "id": "malware_keylogger",
        "category": "malware",
        "name": "Кейлоггер",
        "description": "+15% к шансу шантажа",
        "price": 0.01,
    },
    {
        "id": "malware_ransomware",
        "category": "malware",
        "name": "Шифровальщик",
        "description": "+25% к сумме выкупа",
        "price": 0.02,
    },
    {
        "id": "malware_spy",
        "category": "malware",
        "name": "Шпион",
        "description": "Кража данных приносит от 0.060 BTC",
        "price": 0.015,
    },
    {
        "id": "fake_documents",
        "category": "documents",
        "name": "Поддельные документы",
        "description": "+20% доверия в соц. инженерии",
        "price": 0.01,
    },
    {
        "id": "skill_course",
        "category": "courses",
        "name": "Курс по кибербезопасности",
        "description": "+1 очко навыков",
        "price": 0.02,
    },
)
DARKNET_INVENTORY_IDS: Final[tuple[str, ...]] = tuple(
    str(product["id"])
    for product in DARKNET_PRODUCTS
    if product.get("vpn_charges") is None and product["id"] != "skill_course"
)
EXPLOIT_FOR_MINIGAME: Final[dict[str, str]] = {
    str(product["game_id"]): str(product["id"])
    for product in DARKNET_PRODUCTS
    if product.get("category") == "exploits"
}

# Числовые эффекты покупаемых инструментов.
EXPLOIT_LOCK_RING_REDUCTION: Final[int] = 1
EXPLOIT_LOCK_ZONE_MULTIPLIER: Final[float] = 1.4
EXPLOIT_FIREWALL_SPEED_MULTIPLIER: Final[float] = 0.75
EXPLOIT_PACKET_HARMFUL_MULTIPLIER: Final[float] = 0.70
EXPLOIT_TOPOLOGY_NODE_REDUCTION: Final[int] = 2
EXPLOIT_TRAFFIC_HP_MULTIPLIER: Final[float] = 0.75
EXPLOIT_TRAFFIC_REQUEST_LIMIT_MULTIPLIER: Final[float] = 1.4
FAKE_DOCUMENTS_TRUST_BONUS: Final[int] = 20
MALWARE_KEYLOGGER_CHANCE_BONUS: Final[float] = 0.15
MALWARE_RANSOM_REWARD_MULTIPLIER: Final[float] = 1.25
MALWARE_SPY_DATA_REWARD_MIN: Final[float] = 0.06
MALWARE_MINER_BOOTSTRAP_BTC: Final[float] = 0.001
TRANSACTION_HISTORY_LIMIT: Final[int] = 50

# Геометрия окон рабочего стола.
DESKTOP_WINDOW_DEFAULT_SIZE: Final[tuple[int, int]] = (620, 390)
DESKTOP_WINDOW_START_POS: Final[tuple[int, int]] = (360, 112)
DESKTOP_WINDOW_CASCADE_OFFSET: Final[int] = 27
DESKTOP_WINDOW_CASCADE_SLOTS: Final[int] = 7
DESKTOP_WINDOW_TITLE_HEIGHT: Final[int] = 38
DESKTOP_WINDOW_TITLE_TEXT_OFFSET: Final[tuple[int, int]] = (15, 9)
DESKTOP_WINDOW_BORDER_WIDTH: Final[int] = 2
DESKTOP_WINDOW_CORNER_RADIUS: Final[int] = 7
DESKTOP_WINDOW_CONTROL_SIZE: Final[tuple[int, int]] = (30, 26)
DESKTOP_WINDOW_CONTROL_GAP: Final[int] = 4
DESKTOP_WINDOW_CONTROL_MARGIN: Final[int] = 6
DESKTOP_WINDOW_CONTROL_SYMBOLS: Final[tuple[tuple[str, str], ...]] = (
    ("minimize", "—"),
    ("maximize", "□"),
    ("close", "✕"),
)
DESKTOP_WINDOW_TITLE_FONT_SIZE: Final[int] = 15
DESKTOP_WINDOW_CONTROL_MINUS_WIDTH: Final[int] = 12
DESKTOP_WINDOW_CONTROL_MINUS_HEIGHT: Final[int] = 2
DESKTOP_WINDOW_CONTROL_SQUARE_SIZE: Final[int] = 11
DESKTOP_WINDOW_CONTROL_GLYPH_STROKE: Final[int] = 1
DESKTOP_WINDOW_CONTROL_CLOSE_SIZE: Final[int] = 12
DESKTOP_WINDOW_CONTROL_CLOSE_PIXEL: Final[int] = 2
DESKTOP_WINDOW_PLACEHOLDER_FONT_SIZE: Final[int] = 30
DESKTOP_WINDOW_APP_LABEL_FONT_SIZE: Final[int] = 13
DESKTOP_WINDOW_MAXIMIZED_RECT: Final[tuple[int, int, int, int]] = (8, 44, 1264, 668)
DESKTOP_WINDOW_CONTENT_INSET: Final[int] = 22
DESKTOP_WINDOW_CONTENT_BAR_HEIGHT: Final[int] = 4
DESKTOP_WINDOW_PLACEHOLDER_OFFSET_Y: Final[int] = -12
DESKTOP_WINDOW_APP_LABEL_OFFSET_Y: Final[int] = 34
DESKTOP_WINDOW_DRAG_BOTTOM_MARGIN: Final[int] = 8
DESKTOP_HINT_RIGHT_POS: Final[tuple[int, int]] = (1266, 696)
DESKTOP_SUSPICION_RIGHT_POS: Final[tuple[int, int]] = (900, 9)

# MusicPlayer: четыре трека, управление, прогресс, громкость и визуализатор.
MUSIC_PLAYER_APP_ID: Final[str] = "music_player"
MUSIC_PLAYER_PADDING: Final[int] = 14
MUSIC_PLAYER_TITLE_Y_OFFSET: Final[int] = 10
MUSIC_PLAYER_VISUALIZER_Y_OFFSET: Final[int] = 38
MUSIC_PLAYER_VISUALIZER_HEIGHT: Final[int] = 50
MUSIC_PLAYER_VISUALIZER_GAP: Final[int] = 5
MUSIC_PLAYER_VISUALIZER_MIN_HEIGHT: Final[int] = 3
MUSIC_PLAYER_PROGRESS_Y_OFFSET: Final[int] = 96
MUSIC_PLAYER_PROGRESS_HEIGHT: Final[int] = 5
MUSIC_PLAYER_TRACK_START_Y_OFFSET: Final[int] = 110
MUSIC_PLAYER_TRACK_ROW_HEIGHT: Final[int] = 31
MUSIC_PLAYER_TRACK_ROW_GAP: Final[int] = 4
MUSIC_PLAYER_TRACK_TEXT_X_OFFSET: Final[int] = 12
MUSIC_PLAYER_CONTROLS_Y_OFFSET: Final[int] = 258
MUSIC_PLAYER_CONTROL_SIZE: Final[int] = 38
MUSIC_PLAYER_CONTROL_GAP: Final[int] = 12
MUSIC_PLAYER_CONTROL_ICON_SIZE: Final[int] = 11
MUSIC_PLAYER_MODE_BUTTON_SIZE: Final[tuple[int, int]] = (106, 38)
MUSIC_PLAYER_VOLUME_BOTTOM_OFFSET: Final[int] = 22
MUSIC_PLAYER_VOLUME_LABEL_WIDTH: Final[int] = 104
MUSIC_PLAYER_VOLUME_TRACK_HEIGHT: Final[int] = 7
MUSIC_PLAYER_VOLUME_KNOB_RADIUS: Final[int] = 8
MUSIC_PLAYER_VOLUME_HIT_PADDING: Final[int] = 11
MUSIC_PLAYER_FONT_SIZE: Final[int] = 11
MUSIC_PLAYER_SMALL_FONT_SIZE: Final[int] = 9

# Terminal: интерактивное дерево навыков из трёх веток.
TERMINAL_APP_ID: Final[str] = "terminal"
SKILL_TREE_CONTENT_MARGIN: Final[int] = 12
SKILL_TREE_HEADER_HEIGHT: Final[int] = 46
SKILL_TREE_BRANCH_GAP: Final[int] = 9
SKILL_TREE_BRANCH_TITLE_HEIGHT: Final[int] = 24
SKILL_TREE_NODE_HEIGHT: Final[int] = 70
SKILL_TREE_NODE_GAP: Final[int] = 8
SKILL_TREE_NODE_PADDING: Final[int] = 8
SKILL_TREE_NODE_CORNER_RADIUS: Final[int] = 8
SKILL_TREE_CONNECTOR_WIDTH: Final[int] = 3
SKILL_TREE_TITLE_FONT_SIZE: Final[int] = 13
SKILL_TREE_NODE_FONT_SIZE: Final[int] = 11
SKILL_TREE_DESCRIPTION_FONT_SIZE: Final[int] = 9
SKILL_TREE_STATUS_FONT_SIZE: Final[int] = 10
SKILL_POINTS_PER_COMPLETED_ORDER: Final[int] = 1
SKILL_HACK_DIFFICULTY_REDUCTION: Final[int] = 1
SKILL_HACK_TIME_MULTIPLIER: Final[float] = 1.15
SKILL_INTRUSION_SPEED_MULTIPLIER: Final[float] = 0.85
SKILL_SOCIAL_TRUST_BONUS: Final[int] = 10
SKILL_ORDER_REWARD_MULTIPLIER: Final[float] = 1.15
SKILL_REPUTATION_GAIN_BONUS: Final[int] = 4
SKILL_DEADLINE_MULTIPLIER: Final[float] = 1.20
SKILL_ORDER_SUSPICION_REDUCTION: Final[float] = 3.0
SKILL_DATA_REWARD_MIN_BONUS: Final[float] = 0.02
SKILL_TREE_BRANCHES: Final[tuple[dict[str, object], ...]] = (
    {
        "id": "hacking",
        "name": "ВЗЛОМ",
        "nodes": (
            {
                "id": "hack_tuning",
                "name": "ТЮНИНГ ЭКСПЛОИТОВ",
                "description": "Сложность заказных взломов -1",
                "cost": 1,
                "requires": None,
            },
            {
                "id": "rapid_exploit",
                "name": "БЫСТРЫЙ ЭКСПЛОИТ",
                "description": "+15% времени во взломах",
                "cost": 1,
                "requires": "hack_tuning",
            },
            {
                "id": "data_siphon",
                "name": "СИФОН ДАННЫХ",
                "description": "+0.020 BTC к минимуму кражи",
                "cost": 2,
                "requires": "rapid_exploit",
            },
        ),
    },
    {
        "id": "defense",
        "name": "ЗАЩИТА",
        "nodes": (
            {
                "id": "packet_armor",
                "name": "БРОНЯ ПАКЕТОВ",
                "description": "Стрелки вторжения медленнее на 15%",
                "cost": 1,
                "requires": None,
            },
            {
                "id": "threat_forecast",
                "name": "ПРОГНОЗ УГРОЗ",
                "description": "Интервалы атак длиннее на 20%",
                "cost": 1,
                "requires": "packet_armor",
            },
            {
                "id": "trace_cleaner",
                "name": "ЧИСТИЛЬЩИК СЛЕДОВ",
                "description": "Заказ снижает подозрение на 3%",
                "cost": 2,
                "requires": "threat_forecast",
            },
        ),
    },
    {
        "id": "social",
        "name": "СОЦ. ИНЖЕНЕРИЯ",
        "nodes": (
            {
                "id": "rapport",
                "name": "БЫСТРЫЙ КОНТАКТ",
                "description": "+10% стартового доверия",
                "cost": 1,
                "requires": None,
            },
            {
                "id": "negotiator",
                "name": "ПЕРЕГОВОРЩИК",
                "description": "+15% к наградам заказов",
                "cost": 1,
                "requires": "rapport",
            },
            {
                "id": "fixer_network",
                "name": "СЕТЬ ФИКСЕРОВ",
                "description": "Больше репутации и времени заказов",
                "cost": 2,
                "requires": "negotiator",
            },
        ),
    },
)

# Browser: адресная строка, поиск и список целей.
BROWSER_APP_ID: Final[str] = "browser"
BROWSER_ADDRESS_HEIGHT: Final[int] = 38
BROWSER_CONTENT_MARGIN: Final[int] = 14
BROWSER_ADDRESS_TEXT_PADDING: Final[int] = 12
BROWSER_RESULTS_START_OFFSET: Final[int] = 64
BROWSER_RESULT_HEIGHT: Final[int] = 48
BROWSER_RESULT_GAP: Final[int] = 5
BROWSER_RESULT_MAX_VISIBLE: Final[int] = 4
BROWSER_RESULT_TEXT_X_OFFSET: Final[int] = 12
BROWSER_RESULT_TEXT_Y_OFFSET: Final[int] = 7
BROWSER_HACK_BUTTON_SIZE: Final[tuple[int, int]] = (188, 40)
BROWSER_HACK_BUTTON_MARGIN: Final[int] = 14
BROWSER_INPUT_MAX_LENGTH: Final[int] = 32
BROWSER_CURSOR_BLINK_SECONDS: Final[float] = 0.5
BROWSER_CURSOR_GAP: Final[int] = 2
BROWSER_CURSOR_WIDTH: Final[int] = 2
BROWSER_ADDRESS_TEXT_Y_ADJUST: Final[int] = -1
BROWSER_EMPTY_TEXT_Y_OFFSET: Final[int] = 8
BROWSER_RESULT_DETAIL_Y_OFFSET: Final[int] = 21
BROWSER_RESULT_NAME_MIN_WIDTH: Final[int] = 80
BROWSER_RESULT_NAME_GAP: Final[int] = 8
BROWSER_FONT_SIZE: Final[int] = 12
BROWSER_HEADER_FONT_SIZE: Final[int] = 14

# DarkNet: боковые категории, четыре карточки на странице и навигация.
DARKNET_SIDEBAR_WIDTH: Final[int] = 126
DARKNET_HEADER_HEIGHT: Final[int] = 42
DARKNET_CATEGORY_MARGIN: Final[int] = 7
DARKNET_CATEGORY_ROW_HEIGHT: Final[int] = 38
DARKNET_CATEGORY_GAP: Final[int] = 3
DARKNET_CATEGORY_TEXT_X_OFFSET: Final[int] = 10
DARKNET_CATEGORY_TEXT_Y_OFFSET: Final[int] = 11
DARKNET_CARD_COLUMNS: Final[int] = 2
DARKNET_CARDS_PER_PAGE: Final[int] = 4
DARKNET_CARD_MARGIN: Final[int] = 10
DARKNET_CARD_GAP: Final[int] = 8
DARKNET_CARD_START_Y_OFFSET: Final[int] = 50
DARKNET_CARD_HEIGHT: Final[int] = 126
DARKNET_CARD_CORNER_RADIUS: Final[int] = 8
DARKNET_CARD_TITLE_OFFSET: Final[tuple[int, int]] = (10, 8)
DARKNET_CARD_DESCRIPTION_Y_OFFSET: Final[int] = 33
DARKNET_CARD_DESCRIPTION_LINE_HEIGHT: Final[int] = 15
DARKNET_CARD_DESCRIPTION_MAX_LINES: Final[int] = 2
DARKNET_CARD_PRICE_OFFSET: Final[tuple[int, int]] = (10, 90)
DARKNET_CARD_STOCK_Y_OFFSET: Final[int] = 106
DARKNET_BUY_BUTTON_SIZE: Final[tuple[int, int]] = (82, 29)
DARKNET_BUY_BUTTON_MARGIN: Final[int] = 9
DARKNET_PAGE_BUTTON_SIZE: Final[tuple[int, int]] = (50, 30)
DARKNET_PAGE_BUTTON_BOTTOM_MARGIN: Final[int] = 8
DARKNET_PAGE_BUTTON_GAP: Final[int] = 6
DARKNET_PAGE_TEXT_BOTTOM_OFFSET: Final[int] = 47
DARKNET_HEADER_TEXT_OFFSET: Final[tuple[int, int]] = (12, 12)
DARKNET_BALANCE_RIGHT_MARGIN: Final[int] = 12
DARKNET_TITLE_FONT_SIZE: Final[int] = 14
DARKNET_TEXT_FONT_SIZE: Final[int] = 11
DARKNET_SMALL_FONT_SIZE: Final[int] = 10

# CryptoWallet: крупный баланс и журнал транзакций.
WALLET_MARGIN: Final[int] = 16
WALLET_BALANCE_PANEL_HEIGHT: Final[int] = 105
WALLET_BALANCE_LABEL_Y_OFFSET: Final[int] = 15
WALLET_BALANCE_Y_OFFSET: Final[int] = 45
WALLET_BALANCE_FONT_SIZE: Final[int] = 34
WALLET_TRANSACTION_HEADER_Y_OFFSET: Final[int] = 121
WALLET_TRANSACTION_START_Y_OFFSET: Final[int] = 146
WALLET_TRANSACTION_ROW_HEIGHT: Final[int] = 38
WALLET_TRANSACTION_ROW_GAP: Final[int] = 4
WALLET_TRANSACTION_MAX_VISIBLE: Final[int] = 5
WALLET_TRANSACTION_TEXT_X_OFFSET: Final[int] = 9
WALLET_TRANSACTION_TEXT_Y_OFFSET: Final[int] = 6
WALLET_TRANSACTION_DATE_Y_OFFSET: Final[int] = 22
WALLET_TRANSACTION_AMOUNT_RIGHT_OFFSET: Final[int] = 9
WALLET_EMPTY_TEXT_Y_OFFSET: Final[int] = 40
WALLET_TRANSACTION_AMOUNT_RESERVED: Final[int] = 150
WALLET_TRANSACTION_AMOUNT_Y_ADJUST: Final[int] = -5
WALLET_FONT_SIZE: Final[int] = 11
WALLET_SMALL_FONT_SIZE: Final[int] = 10
WALLET_HEADER_FONT_SIZE: Final[int] = 13

# MinerManager и пассивная экономика.
MINER_MANAGER_APP_ID: Final[str] = "miner_manager"
MINER_RATE_BTC_PER_MINUTE: Final[float] = 0.001
MINER_MANAGER_MARGIN: Final[int] = 16
MINER_MANAGER_HEADER_HEIGHT: Final[int] = 52
MINER_MANAGER_ROW_HEIGHT: Final[int] = 42
MINER_MANAGER_ROW_GAP: Final[int] = 6
MINER_MANAGER_MAX_VISIBLE: Final[int] = 4
MINER_MANAGER_SUBHEADER_Y_OFFSET: Final[int] = 24
MINER_MANAGER_EMPTY_DETAIL_Y_OFFSET: Final[int] = 30
MINER_MANAGER_ROW_RIGHT_RESERVED: Final[int] = 190
MINER_MANAGER_ROW_TEXT_X_OFFSET: Final[int] = 11
MINER_MANAGER_ROW_TEXT_Y_OFFSET: Final[int] = 12
MINER_MANAGER_HIDDEN_BOTTOM_OFFSET: Final[int] = 15
MINER_MANAGER_WITHDRAW_SIZE: Final[tuple[int, int]] = (154, 34)
MINER_MANAGER_WITHDRAW_MARGIN: Final[int] = 14
MINER_MANAGER_WITHDRAW_FONT_SIZE: Final[int] = 12
MINER_MANAGER_FONT_SIZE: Final[int] = 12

# Подготовка взлома и выбор одноразовых инструментов.
HACK_PREP_TITLE_CENTER: Final[tuple[int, int]] = (640, 104)
HACK_PREP_TARGET_CENTER: Final[tuple[int, int]] = (640, 154)
HACK_PREP_HELP_CENTER: Final[tuple[int, int]] = (640, 198)
HACK_PREP_TOOL_START: Final[tuple[int, int]] = (205, 245)
HACK_PREP_TOOL_SIZE: Final[tuple[int, int]] = (870, 68)
HACK_PREP_TOOL_GAP: Final[int] = 12
HACK_PREP_TOOL_TEXT_OFFSET: Final[tuple[int, int]] = (20, 13)
HACK_PREP_TOOL_DESCRIPTION_Y_OFFSET: Final[int] = 39
HACK_PREP_TOOL_STOCK_RIGHT_OFFSET: Final[int] = 20
HACK_PREP_START_RECT: Final[tuple[int, int, int, int]] = (650, 590, 250, 54)
HACK_PREP_BACK_RECT: Final[tuple[int, int, int, int]] = (380, 590, 250, 54)
HACK_PREP_FONT_SIZE: Final[int] = 14
HACK_PREP_TITLE_FONT_SIZE: Final[int] = 28

# Экран действий после успешного взлома.
POST_HACK_TITLE_CENTER: Final[tuple[int, int]] = (640, 94)
POST_HACK_TARGET_CENTER: Final[tuple[int, int]] = (640, 146)
POST_HACK_STATS_CENTER: Final[tuple[int, int]] = (640, 186)
POST_HACK_BUTTON_START: Final[tuple[int, int]] = (112, 242)
POST_HACK_BUTTON_SIZE: Final[tuple[int, int]] = (334, 112)
POST_HACK_BUTTON_COLUMN_GAP: Final[int] = 27
POST_HACK_BUTTON_ROW_GAP: Final[int] = 28
POST_HACK_BUTTON_COLUMNS: Final[int] = 3
POST_HACK_BUTTON_CORNER_RADIUS: Final[int] = 12
POST_HACK_ACTIONS: Final[tuple[tuple[str, str, str], ...]] = (
    ("miner", "⛏️ Майнер", "0.001 BTC/мин"),
    ("blackmail", "💀 Шантаж", "выбрать тон"),
    ("data_theft", "📂 Кража данных", "0.020–0.100 BTC"),
    ("ransomware", "🔐 Шифровальщик", "награда / +15% подозрения"),
    ("order_info", "📋 Инфо для заказа", "награда заказчика"),
    ("proxy", "🔄 Прокси", "+1 заряд VPN"),
)
POST_HACK_ACTION_FONT_SIZE: Final[int] = 18
POST_HACK_DESCRIPTION_FONT_SIZE: Final[int] = 12
POST_HACK_DATA_REWARD_RANGE: Final[tuple[float, float]] = (0.02, 0.1)
POST_HACK_RANSOM_REWARD_RANGE: Final[tuple[float, float]] = (0.12, 0.2)
POST_HACK_RANSOM_SUSPICION: Final[float] = 15.0
POST_HACK_BLACKMAIL_TITLE_CENTER: Final[tuple[int, int]] = (640, 245)
POST_HACK_BLACKMAIL_BUTTON_START_X: Final[int] = 178
POST_HACK_BLACKMAIL_BUTTON_Y: Final[int] = 320
POST_HACK_BLACKMAIL_BUTTON_SIZE: Final[tuple[int, int]] = (286, 104)
POST_HACK_BLACKMAIL_BUTTON_GAP: Final[int] = 32
POST_HACK_BLACKMAIL_BACK_RECT: Final[tuple[int, int, int, int]] = (530, 474, 220, 48)
POST_HACK_BLACKMAIL_NAME_Y_OFFSET: Final[int] = 27
POST_HACK_BLACKMAIL_REWARD_Y_OFFSET: Final[int] = 58
POST_HACK_BLACKMAIL_SUSPICION_Y_OFFSET: Final[int] = 80
POST_HACK_ACTION_NAME_Y_OFFSET: Final[int] = 37
POST_HACK_ACTION_DESCRIPTION_Y_OFFSET: Final[int] = 75
POST_HACK_ACTION_SYMBOL_OFFSET: Final[tuple[int, int]] = (32, 37)
POST_HACK_ACTION_SYMBOL_RADIUS: Final[int] = 14
POST_HACK_ACTION_SYMBOL_STROKE: Final[int] = 2
POST_HACK_HINT_CENTER: Final[tuple[int, int]] = (640, 660)
POST_HACK_BLACKMAIL_TONES: Final[dict[str, dict[str, object]]] = {
    "soft": {
        "name": "Мягкий",
        "chance": 0.80,
        "reward": (0.015, 0.03),
        "suspicion": 2.0,
    },
    "hard": {
        "name": "Жёсткий",
        "chance": 0.55,
        "reward": (0.03, 0.065),
        "suspicion": 6.0,
    },
    "threat": {
        "name": "Угроза",
        "chance": 0.35,
        "reward": (0.065, 0.12),
        "suspicion": 12.0,
    },
}

# Мессенджер и система заказов.
MESSENGER_APP_ID: Final[str] = "messenger"
MESSENGER_FORUM_ID: Final[str] = "forum"
MESSENGER_SIDEBAR_WIDTH: Final[int] = 200
MESSENGER_SIDEBAR_HEADER_HEIGHT: Final[int] = 40
MESSENGER_CHAT_ROW_HEIGHT: Final[int] = 44
MESSENGER_CHAT_ROW_SIDE_MARGIN: Final[int] = 6
MESSENGER_AVATAR_X_OFFSET: Final[int] = 24
MESSENGER_AVATAR_RADIUS: Final[int] = 14
MESSENGER_CHAT_NAME_X_OFFSET: Final[int] = 47
MESSENGER_CHAT_NAME_Y_OFFSET: Final[int] = 14
MESSENGER_STORY_DOT_RIGHT_MARGIN: Final[int] = 13
MESSENGER_STORY_DOT_RADIUS: Final[int] = 5
MESSENGER_REPUTATION_BOTTOM_OFFSET: Final[int] = 25
MESSENGER_REPUTATION_BAR_BOTTOM_OFFSET: Final[int] = 43
MESSENGER_REPUTATION_BAR_SIDE_MARGIN: Final[int] = 12
MESSENGER_REPUTATION_BAR_HEIGHT: Final[int] = 5
MESSENGER_RIGHT_HEADER_HEIGHT: Final[int] = 44
MESSENGER_RIGHT_HEADER_X_OFFSET: Final[int] = 15
MESSENGER_RIGHT_HEADER_Y_OFFSET: Final[int] = 13
MESSENGER_HEADER_FONT_SIZE: Final[int] = 14
MESSENGER_TEXT_FONT_SIZE: Final[int] = 12
MESSENGER_SMALL_FONT_SIZE: Final[int] = 11
MESSENGER_MESSAGE_MARGIN: Final[int] = 12
MESSENGER_BUBBLE_MAX_WIDTH: Final[int] = 350
MESSENGER_BUBBLE_PADDING: Final[int] = 10
MESSENGER_BUBBLE_LINE_HEIGHT: Final[int] = 16
MESSENGER_BUBBLE_GAP: Final[int] = 8
MESSENGER_BUBBLE_CORNER_RADIUS: Final[int] = 10
MESSENGER_BUBBLE_MIN_HEIGHT: Final[int] = 34
MESSENGER_TIMER_LINE_HEIGHT: Final[int] = 17
MESSENGER_TIMER_WARNING_SECONDS: Final[int] = 60
MESSENGER_ACTION_HEIGHT: Final[int] = 34
MESSENGER_ACTION_GAP: Final[int] = 10
MESSENGER_ACTION_SIDE_MARGIN: Final[int] = 12
MESSENGER_ACTION_BOTTOM_MARGIN: Final[int] = 12
MESSENGER_ACTION_CORNER_RADIUS: Final[int] = 8
MESSENGER_ACTION_FONT_SIZE: Final[int] = 13
MESSENGER_NO_ORDER_BOTTOM_OFFSET: Final[int] = 28
MESSENGER_FORUM_CARD_HEIGHT: Final[int] = 49
MESSENGER_FORUM_CARD_GAP: Final[int] = 6
MESSENGER_FORUM_SIDE_MARGIN: Final[int] = 12
MESSENGER_FORUM_TEXT_X_OFFSET: Final[int] = 10
MESSENGER_FORUM_TEXT_Y_OFFSET: Final[int] = 6
MESSENGER_FORUM_REWARD_RIGHT_MARGIN: Final[int] = 10
REPUTATION_MIN: Final[int] = -100
REPUTATION_MAX: Final[int] = 100
MESSENGER_INITIAL_REPUTATION: Final[int] = 0
MESSENGER_REFUSAL_PENALTY: Final[int] = 5
ORDER_COMPLETION_REPUTATION_GAIN: Final[int] = 8
ORDER_FAILURE_REPUTATION_PENALTY: Final[int] = 7
ORDER_ABORT_REPUTATION_PENALTY: Final[int] = 4
ORDER_NO_DELIVERY_REPUTATION_PENALTY: Final[int] = 6
ORDER_EXPIRED_REPUTATION_PENALTY: Final[int] = 8
ORDER_REWARD_REPUTATION_INFLUENCE: Final[float] = 0.25
ORDER_DEADLINE_REPUTATION_INFLUENCE: Final[float] = 0.35
ORDER_DEADLINE_MINUTES_FLOOR: Final[int] = 3
ORDER_DEADLINE_MINUTES_CEILING: Final[int] = 20
MESSENGER_ATTACK_REFUSALS: Final[int] = 3
MESSENGER_STORY_INTERVAL: Final[int] = 5
MESSENGER_FORUM_UNLOCK_ORDER: Final[int] = 10
MESSENGER_FORUM_ORDER_COUNT: Final[int] = 5
MESSENGER_DEADLINE_MINUTES_MIN: Final[int] = 5
MESSENGER_DEADLINE_MINUTES_MAX: Final[int] = 15
MESSENGER_HISTORY_LIMIT: Final[int] = 40
SUSPICION_MIN: Final[float] = 0.0
SUSPICION_MAX: Final[float] = 100.0
SUSPICION_CLEAN_ORDER_REDUCTION: Final[float] = 0.0
MESSENGER_ATTACK_FLASH_SECONDS: Final[float] = 3.0
MESSENGER_ATTACK_BORDER_WIDTH: Final[int] = 6

# Входящие звонки: интервалы заданы в секундах реального времени.
call_types: Final[list[dict[str, object]]] = [
    {
        "type": "informant",
        "weight": 40,
        "name": "Неизвестный информатор",
    },
    {
        "type": "trap",
        "weight": 35,
        "name": "Неизвестный номер",
    },
    {
        "type": "threat",
        "weight": 25,
        "name": "Заблокированный номер",
    },
]
CALL_INTERVAL_MIN_SECONDS: Final[float] = 300.0
CALL_INTERVAL_MAX_SECONDS: Final[float] = 600.0
CALL_REPEAT_MIN_SECONDS: Final[float] = 60.0
CALL_REPEAT_MAX_SECONDS: Final[float] = 120.0
CALL_REPEAT_CHANCE: Final[float] = 0.50
CALL_RING_SECONDS: Final[float] = 10.0
CALL_ALARM_REPEAT_SECONDS: Final[float] = 1.5
CALL_MUSIC_DUCK_MULTIPLIER: Final[float] = 0.20
CALL_SHAKE_UPDATES_PER_SECOND: Final[float] = 3.0
CALL_SHAKE_PIXELS: Final[int] = 2
CALL_MODAL_RECT: Final[tuple[int, int, int, int]] = (440, 235, 400, 250)
CALL_DIALOG_RECT: Final[tuple[int, int, int, int]] = (310, 118, 660, 484)
CALL_MODAL_BORDER_WIDTH: Final[int] = 3
CALL_MODAL_CORNER_RADIUS: Final[int] = 13
CALL_PHONE_CENTER: Final[tuple[int, int]] = (640, 278)
CALL_PHONE_ICON_RADIUS: Final[int] = 24
CALL_PHONE_ICON_STROKE: Final[int] = 4
CALL_TITLE_Y: Final[int] = 317
CALL_CALLER_Y: Final[int] = 350
CALL_COUNTDOWN_Y: Final[int] = 389
CALL_BUTTON_Y: Final[int] = 424
CALL_BUTTON_SIZE: Final[tuple[int, int]] = (168, 42)
CALL_BUTTON_GAP: Final[int] = 20
CALL_TITLE_FONT_SIZE: Final[int] = 19
CALL_CALLER_FONT_SIZE: Final[int] = 15
CALL_COUNTDOWN_FONT_SIZE: Final[int] = 38
CALL_BUTTON_FONT_SIZE: Final[int] = 14
CALL_DIALOG_TITLE_Y: Final[int] = 146
CALL_DIALOG_TEXT_X: Final[int] = 344
CALL_DIALOG_TEXT_START_Y: Final[int] = 194
CALL_DIALOG_TEXT_WIDTH: Final[int] = 592
CALL_DIALOG_LINE_GAP: Final[int] = 29
CALL_DIALOG_FONT_SIZE: Final[int] = 15
CALL_DIALOG_SMALL_FONT_SIZE: Final[int] = 13
CALL_DIALOG_BUTTON_RECT: Final[tuple[int, int, int, int]] = (535, 537, 210, 44)
CALL_MESSAGE_INTERVAL_SECONDS: Final[float] = 1.5
CALL_TYPING_CHARACTERS_PER_SECOND: Final[float] = 72.0
CALL_ANSWER_LABEL: Final[str] = "📞 Ответить"
CALL_DECLINE_LABEL: Final[str] = "❌ Сбросить"
CALL_INFORMANT_DISCOUNT_SECONDS: Final[float] = 300.0
CALL_INFORMANT_DISCOUNT_RATE: Final[float] = 0.30
CALL_INFORMANT_BASE_MESSAGES: Final[tuple[str, ...]] = (
    "Привет. Я знаю что ты работаешь на Phantom.",
    "У меня есть кое-что для тебя.",
    "Канал будет открыт недолго.",
    "{bonus_message}",
    "Не заставляй меня пожалеть об этом.",
)
CALL_INFORMANT_DISCOUNT_MESSAGE: Final[str] = (
    "Скидка 30% в Даркнете на следующие 5 минут."
)
CALL_INFORMANT_HINT_MESSAGE: Final[str] = (
    "Подсказка: цель 'corp_main' имеет уязвимость в фаерволле."
)
CALL_TRAP_ROUNDS: Final[tuple[dict[str, object], ...]] = (
    {
        "question": (
            "Нам нужно подтвердить ваш IP-адрес. Назовите последние 4 цифры."
        ),
        "options": (
            "1234",
            "Я не даю такие данные",
            "Какой ещё провайдер?",
        ),
        "correct": 1,
    },
    {
        "question": "Продиктуйте пароль от личного кабинета для сверки.",
        "options": (
            "hunter2",
            "Я не сообщаю пароли",
            "Сначала назовите номер договора",
        ),
        "correct": 1,
    },
    {
        "question": "Назовите ваше имя и домашний адрес для подтверждения.",
        "options": (
            "Алексей, улица Центральная, 12",
            "Я не раскрываю личные данные",
            "Вы уже должны это знать",
        ),
        "correct": 1,
    },
)
CALL_TRAP_OPTION_START_Y: Final[int] = 350
CALL_TRAP_OPTION_HEIGHT: Final[int] = 45
CALL_TRAP_OPTION_GAP: Final[int] = 12
CALL_TRAP_OPTION_SIDE_MARGIN: Final[int] = 40
CALL_TRAP_SUSPICION_PENALTY: Final[float] = 5.0
CALL_TRAP_REPUTATION_BONUS: Final[int] = 2
CALL_THREAT_SECONDS: Final[float] = 120.0
CALL_THREAT_MESSAGE: Final[str] = (
    "Я знаю твой IP. У тебя 2 минуты чтобы сменить VPN. Иначе..."
)
CALL_THREAT_TIMER_RECT: Final[tuple[int, int, int, int]] = (1010, 48, 250, 48)

# Горячие заказы: отдельный срочный контракт, не вытесняющий обычные заказы.
HOT_DEAL_INTERVAL_MIN_SECONDS: Final[int] = 900
HOT_DEAL_INTERVAL_MAX_SECONDS: Final[int] = 1200
HOT_DEAL_DURATION_SECONDS: Final[float] = 120.0
HOT_DEAL_REWARD_MULTIPLIER: Final[int] = 3
HOT_DEAL_COMPLETION_REPUTATION: Final[int] = 10
HOT_DEAL_FAILURE_REPUTATION: Final[int] = -10
HOT_DEAL_IGNORED_REPUTATION: Final[int] = -3
HOT_DEAL_TIMER_RECT: Final[tuple[int, int, int, int]] = (540, 45, 200, 60)
HOT_DEAL_TIMER_FONT_SIZE: Final[int] = 30
HOT_DEAL_TIMER_LABEL_FONT_SIZE: Final[int] = 10
HOT_DEAL_MESSAGE: Final[str] = (
    "🔥 ГОРЯЧИЙ ЗАКАЗ! Награда x3! Дедлайн: 2 МИНУТЫ! "
    "Бери или потеряешь!"
)

# Первый заказ Ph4ntom и программно нарисованные подсказки обучения.
TUTORIAL_CUSTOMER: Final[str] = "Ph4ntom"
TUTORIAL_TARGET: Final[str] = "учебный узел PH4-01"
TUTORIAL_REWARD: Final[float] = 0.020
TUTORIAL_DEADLINE_MINUTES: Final[int] = 20
TUTORIAL_OVERLAY_ALPHA: Final[int] = 126
TUTORIAL_HIGHLIGHT_PADDING: Final[int] = 8
TUTORIAL_HIGHLIGHT_WIDTH: Final[int] = 4
TUTORIAL_PULSE_SECONDS: Final[float] = 0.75
TUTORIAL_ARROW_SIZE: Final[int] = 16
TUTORIAL_TOOLTIP_RECT: Final[tuple[int, int, int, int]] = (410, 580, 460, 78)
TUTORIAL_MINIGAME_FOCUS_RECT: Final[tuple[int, int, int, int]] = (130, 118, 1020, 452)
TUTORIAL_PULSE_EXPANSION: Final[int] = 5
TUTORIAL_TOOLTIP_TEXT_PADDING: Final[int] = 38
TUTORIAL_TOOLTIP_TEXT_Y_OFFSET: Final[int] = 15
TUTORIAL_TOOLTIP_LINE_GAP: Final[int] = 24
TUTORIAL_TOOLTIP_MAX_LINES: Final[int] = 2
TUTORIAL_TOOLTIP_FONT_SIZE: Final[int] = 14
TUTORIAL_MESSAGES: Final[dict[int, str]] = {
    0: "ШАГ 1/5: откройте Messenger — нажмите подсвеченную иконку.",
    1: "ШАГ 2/5: выберите чат Ph4ntom в левой колонке.",
    2: "ШАГ 3/5: примите учебный заказ подсвеченной кнопкой.",
    3: "ШАГ 4/5: завершите взлом по инструкции; на результате нажмите ОК.",
    4: "ШАГ 5/5: выберите «Инфо для заказа», чтобы получить BTC и SP.",
}
MESSENGER_CUSTOMERS: Final[list[dict[str, str]]] = [
    {"nick": "Ph4ntom", "avatar": "P"},
    {"nick": "NullByte", "avatar": "N"},
    {"nick": "RedOnion", "avatar": "R"},
    {"nick": "Glitch_", "avatar": "G"},
    {"nick": "Specter", "avatar": "S"},
]
ORDER_TEMPLATES: Final[list[dict[str, str | float]]] = [
    {
        "target": "сайт Orion Logistics",
        "type": "аудит веб-периметра",
        "category": "website",
        "target_type": "Сайт",
        "description": "Найти уязвимый тестовый шлюз и подготовить отчёт.",
        "reward_min": 0.008,
        "reward_max": 0.018,
    },
    {
        "target": "архив NeonBank",
        "type": "восстановление доступа",
        "category": "encrypted",
        "target_type": "Гос.система",
        "description": "Вернуть ключ от зашифрованной учебной копии архива.",
        "reward_min": 0.012,
        "reward_max": 0.026,
    },
    {
        "target": "камеры Red Harbor",
        "type": "перехват видеопакетов",
        "category": "cameras",
        "target_type": "Камеры",
        "description": "Отделить служебные пакеты камер от шумового трафика.",
        "reward_min": 0.006,
        "reward_max": 0.016,
    },
    {
        "target": "сервер Axiom-7",
        "type": "поиск цифрового следа",
        "category": "server",
        "target_type": "Корпорация",
        "description": "Проверить изолированный образ и найти маркеры вторжения.",
        "reward_min": 0.010,
        "reward_max": 0.024,
    },
    {
        "target": "контейнер Black Ice",
        "type": "дешифровка данных",
        "category": "data",
        "target_type": "Обычный ПК",
        "description": "Извлечь контрольную фразу из повреждённого контейнера.",
        "reward_min": 0.014,
        "reward_max": 0.030,
    },
    {
        "target": "ретранслятор GhostNet",
        "type": "проверка конфигурации",
        "category": "network",
        "target_type": "Корпорация",
        "description": "Найти ошибку маршрутизации без выхода в реальную сеть.",
        "reward_min": 0.007,
        "reward_max": 0.019,
    },
    {
        "target": "оператор Helix Corp",
        "type": "социальная инженерия",
        "category": "human",
        "target_type": "Телефон",
        "description": "Сопоставить открытые метаданные учебного профиля.",
        "reward_min": 0.005,
        "reward_max": 0.015,
    },
    {
        "target": "кластер Zero Vault",
        "type": "стресс-тест защиты",
        "category": "server",
        "target_type": "Гос.система",
        "description": "Проверить правила виртуального firewall в песочнице.",
        "reward_min": 0.016,
        "reward_max": 0.034,
    },
]

# Сюжетная арка: война NULL COLLECTIVE и RED VEIL.
STORY_FACTION_NULL: Final[str] = "NULL COLLECTIVE"
STORY_FACTION_RED: Final[str] = "RED VEIL"
STORY_CHAPTERS: Final[tuple[dict[str, object], ...]] = (
    {
        "title": "ГЛАВА I // ПЕРВЫЙ СИГНАЛ",
        "faction": STORY_FACTION_NULL,
        "target": "маршрутизатор Meridian",
        "type": "перехват военного канала",
        "category": "network",
        "target_type": "Корпорация",
        "description": (
            "NULL просит перехватить ключи RED VEIL. Отказ означает, что вы "
            "предупредите противника. Война группировок начинается сейчас."
        ),
        "reward_min": 0.025,
        "reward_max": 0.040,
        "accept_label": "Поддержать NULL",
        "reject_label": "Помочь RED",
        "accepted_effect": {
            "null": 2,
            "red": -1,
            "peace": 0,
            "chaos": 1,
            "reputation": 3,
            "suspicion": 3.0,
        },
        "rejected_effect": {
            "null": -1,
            "red": 2,
            "peace": 1,
            "chaos": 0,
            "reputation": 1,
            "suspicion": 0.0,
        },
        "success_message": "Ключи Meridian изменили баланс сил в подполье.",
    },
    {
        "title": "ГЛАВА II // ОТВЕТНЫЙ УДАР",
        "faction": STORY_FACTION_RED,
        "target": "ретранслятор Pale Horse",
        "type": "контрудар по сети NULL",
        "category": "server",
        "target_type": "Гос.система",
        "description": (
            "RED VEIL требует открыть коридор к узлам NULL. Можно выполнить "
            "приказ или тайно сорвать наступление в пользу NULL."
        ),
        "reward_min": 0.032,
        "reward_max": 0.052,
        "accept_label": "Поддержать RED",
        "reject_label": "Спасти NULL",
        "accepted_effect": {
            "null": -1,
            "red": 2,
            "peace": 0,
            "chaos": 1,
            "reputation": 3,
            "suspicion": 4.0,
        },
        "rejected_effect": {
            "null": 2,
            "red": -1,
            "peace": 1,
            "chaos": 0,
            "reputation": 1,
            "suspicion": 0.0,
        },
        "success_message": "Pale Horse погас; RED VEIL перешла в наступление.",
    },
    {
        "title": "ГЛАВА III // ЛОЖНЫЙ ФЛАГ",
        "faction": "НЕЗАВИСИМЫЙ КАНАЛ",
        "target": "архив False Dawn",
        "type": "публикация доказательств",
        "category": "encrypted",
        "target_type": "Гос.система",
        "description": (
            "Архив доказывает, что войну разожгли посредники. Опубликуйте его "
            "ради мира или продайте обеим сторонам и усильте хаос."
        ),
        "reward_min": 0.038,
        "reward_max": 0.060,
        "accept_label": "Разоблачить ложь",
        "reject_label": "Продать архив",
        "accepted_effect": {
            "null": 0,
            "red": 0,
            "peace": 2,
            "chaos": -1,
            "reputation": 6,
            "suspicion": -5.0,
        },
        "rejected_effect": {
            "null": 1,
            "red": 1,
            "peace": -1,
            "chaos": 2,
            "reputation": -4,
            "suspicion": 8.0,
        },
        "success_message": "False Dawn опубликован; лидеры фракций требуют ответа.",
    },
    {
        "title": "ГЛАВА IV // ZERO HOUR",
        "faction": "ОБЕ ГРУППИРОВКИ",
        "target": "протокол ZERO HOUR",
        "type": "финальный выбор войны",
        "category": "data",
        "target_type": "Корпорация",
        "description": (
            "В ваших руках сетевое оружие обеих группировок. Отключите его и "
            "остановите войну либо активируйте протокол ради победителя."
        ),
        "reward_min": 0.050,
        "reward_max": 0.080,
        "accept_label": "Отключить оружие",
        "reject_label": "Запустить ZERO",
        "accepted_effect": {
            "null": 0,
            "red": 0,
            "peace": 3,
            "chaos": -1,
            "reputation": 8,
            "suspicion": -8.0,
        },
        "rejected_effect": {
            "null": 0,
            "red": 0,
            "peace": -2,
            "chaos": 3,
            "reputation": -8,
            "suspicion": 12.0,
        },
        "success_message": "ZERO HOUR отключён. Подполье ждёт вашего вердикта.",
    },
)
STORY_ENDINGS: Final[dict[str, dict[str, str]]] = {
    "truce": {
        "title": "ПЕРЕМИРИЕ // ТИХИЙ КАНАЛ",
        "description": (
            "Вы раскрыли провокацию и отключили сетевое оружие. NULL COLLECTIVE "
            "и RED VEIL подписали хрупкое перемирие, а оператор стал независимым "
            "арбитром цифрового подполья."
        ),
    },
    "null_victory": {
        "title": "ПОБЕДА NULL COLLECTIVE",
        "description": (
            "NULL COLLECTIVE получила контроль над теневой сетью. Ваши решения "
            "сделали её сильнее RED VEIL; теперь каждый новый заказ проходит "
            "через протоколы NULL."
        ),
    },
    "red_victory": {
        "title": "ТРИУМФ RED VEIL",
        "description": (
            "RED VEIL уничтожила инфраструктуру соперника и заняла подпольные "
            "рынки. Вы стали её главным оператором, но цена победы видна в каждом "
            "следе сети."
        ),
    },
    "blackout": {
        "title": "BLACKOUT // НИКТО НЕ ПОБЕДИЛ",
        "description": (
            "ZERO HOUR выжег ключевые узлы обеих группировок. Война закончилась "
            "цифровой тишиной, а ваше имя осталось единственной подписью в логах."
        ),
    },
    "independent": {
        "title": "СВОБОДНЫЙ ОПЕРАТОР",
        "description": (
            "Баланс сил сохранился, но ни одна группировка не получила вас целиком. "
            "Вы исчезли из их каналов и сохранили независимость."
        ),
    },
}

# Всплывающие уведомления рабочего стола.
DESKTOP_NOTIFICATION_RECT: Final[tuple[int, int, int, int]] = (914, 50, 344, 72)
DESKTOP_NOTIFICATION_GAP: Final[int] = 10
DESKTOP_NOTIFICATION_MAX_VISIBLE: Final[int] = 3
DESKTOP_NOTIFICATION_DURATION_SECONDS: Final[float] = 3.0
DESKTOP_NOTIFICATION_STRIPE_WIDTH: Final[int] = 5
DESKTOP_NOTIFICATION_PADDING_X: Final[int] = 15
DESKTOP_NOTIFICATION_TITLE_Y_OFFSET: Final[int] = 11
DESKTOP_NOTIFICATION_TEXT_Y_OFFSET: Final[int] = 36
DESKTOP_NOTIFICATION_CORNER_RADIUS: Final[int] = 9
DESKTOP_NOTIFICATION_TITLE_FONT_SIZE: Final[int] = 13
DESKTOP_NOTIFICATION_TEXT_FONT_SIZE: Final[int] = 11

# Декор фона — позиции блоков и индикаторов на базовом холсте.
DECOR_BLOCK_POSITIONS: Final[tuple[tuple[int, int], ...]] = (
    (52, 68),
    (1186, 68),
    (52, 647),
    (1186, 647),
)
DECOR_CIRCLE_POSITIONS: Final[tuple[tuple[int, int], ...]] = (
    (70, 50),
    (91, 50),
    (112, 50),
    (1168, 670),
    (1189, 670),
    (1210, 670),
)
STATUS_MESSAGE_SECONDS: Final[float] = 2.5


@dataclass(slots=True)
class DesktopWindow:
    """Состояние одного программно нарисованного окна рабочего стола."""

    app_id: str
    title: str
    rect: pygame.Rect
    minimized: bool = False
    maximized: bool = False
    restore_rect: pygame.Rect | None = None


class MiniGameBase:
    """Общая логика таймера и результата полноэкранной мини-игры."""

    title = "MINI-GAME"

    def __init__(self, difficulty: int, duration: float) -> None:
        self.difficulty = min(
            MINIGAME_DIFFICULTY_MAX,
            max(MINIGAME_DIFFICULTY_MIN, difficulty),
        )
        self.time_left = duration
        self.finished = False
        self.success = False

    def finish(self, success: bool) -> None:
        if self.finished:
            return
        self.finished = True
        self.success = success

    def tick_timer(self, delta_seconds: float) -> bool:
        if self.finished:
            return False
        self.time_left = max(0.0, self.time_left - delta_seconds)
        if self.time_left <= 0.0:
            self.finish(False)
            return False
        return True

    def handle_event(self, event: pygame.event.Event, app: ZeroDayApp) -> None:
        del event, app

    def update(self, delta_seconds: float) -> None:
        self.tick_timer(delta_seconds)

    def draw(self, app: ZeroDayApp) -> None:
        raise NotImplementedError


class BruteForceLock(MiniGameBase):
    """Круговой замок с независимо вращаемыми концентрическими кольцами."""

    title = "ВЗЛОМ ЗАМКА // BRUTE FORCE LOCK"

    def __init__(self, difficulty: int) -> None:
        duration = (
            LOCK_TIME_BASE_SECONDS
            - (difficulty - MINIGAME_DIFFICULTY_MIN) * LOCK_TIME_DIFFICULTY_PENALTY
        )
        super().__init__(difficulty, duration)
        self.random = random.Random()
        self.ring_count = min(
            len(LOCK_RING_RADII),
            LOCK_RING_COUNT_BASE
            + (difficulty - MINIGAME_DIFFICULTY_MIN) // LOCK_RING_COUNT_DIFFICULTY_STEP,
        )
        self.correct_zone_degrees = LOCK_CORRECT_ZONE_DEGREES
        self.rings: list[dict[str, float | bool]] = []
        for _index in range(self.ring_count):
            target = self.random.uniform(0.0, 360.0)
            offset = self.random.uniform(
                self.correct_zone_degrees * 2.5,
                360.0 - self.correct_zone_degrees * 2.5,
            )
            self.rings.append(
                {
                    "angle": (target + offset) % 360.0,
                    "target": target,
                    "locked": False,
                }
            )
        self.selected_ring = 0
        self.dragging = False
        self.last_mouse_angle = 0.0

    @staticmethod
    def _difference(angle: float, target: float) -> float:
        return (angle - target + 180.0) % 360.0 - 180.0

    def _select_next_unlocked(self) -> None:
        for offset in range(1, self.ring_count + 1):
            index = (self.selected_ring + offset) % self.ring_count
            if not bool(self.rings[index]["locked"]):
                self.selected_ring = index
                return

    def _rotate_selected(self, delta_degrees: float) -> None:
        if self.finished:
            return
        ring = self.rings[self.selected_ring]
        if bool(ring["locked"]):
            self._select_next_unlocked()
            ring = self.rings[self.selected_ring]
        ring["angle"] = (float(ring["angle"]) + delta_degrees) % 360.0
        if (
            abs(self._difference(float(ring["angle"]), float(ring["target"])))
            <= self.correct_zone_degrees
        ):
            ring["angle"] = float(ring["target"])
            ring["locked"] = True
            self.dragging = False
            if all(bool(item["locked"]) for item in self.rings):
                self.finish(True)
            else:
                self._select_next_unlocked()

    @staticmethod
    def _mouse_angle(point: tuple[float, float]) -> float:
        return math.degrees(
            math.atan2(point[1] - LOCK_CENTER[1], point[0] - LOCK_CENTER[0])
        )

    def handle_event(self, event: pygame.event.Event, app: ZeroDayApp) -> None:
        if self.finished:
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            point = app._desktop_point(event.pos)
            distance = math.hypot(
                point[0] - LOCK_CENTER[0],
                point[1] - LOCK_CENTER[1],
            )
            nearest = min(
                range(self.ring_count),
                key=lambda index: abs(distance - LOCK_RING_RADII[index]),
            )
            if abs(
                distance - LOCK_RING_RADII[nearest]
            ) <= LOCK_RING_CLICK_TOLERANCE and not bool(self.rings[nearest]["locked"]):
                self.selected_ring = nearest
                self.dragging = True
                self.last_mouse_angle = self._mouse_angle(point)
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            point = app._desktop_point(event.pos)
            angle = self._mouse_angle(point)
            delta = self._difference(angle, self.last_mouse_angle)
            self.last_mouse_angle = angle
            self._rotate_selected(delta)
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEWHEEL:
            self._rotate_selected(event.y * LOCK_WHEEL_ROTATION_DEGREES)
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
            self._select_next_unlocked()

    def update(self, delta_seconds: float) -> None:
        if not self.tick_timer(delta_seconds) or self.finished:
            return
        keys = pygame.key.get_pressed()
        direction = float(keys[pygame.K_RIGHT] or keys[pygame.K_d]) - float(
            keys[pygame.K_LEFT] or keys[pygame.K_a]
        )
        if direction:
            self._rotate_selected(direction * LOCK_KEY_ROTATION_SPEED * delta_seconds)

    def draw(self, app: ZeroDayApp) -> None:
        app._draw_minigame_frame(self.title, self.time_left)
        center_x, center_y = LOCK_CENTER
        for index, ring in enumerate(self.rings):
            radius = LOCK_RING_RADII[index]
            arc_rect = app._rect(
                (
                    center_x - radius,
                    center_y - radius,
                    radius * 2,
                    radius * 2,
                )
            )
            locked = bool(ring["locked"])
            selected = index == self.selected_ring and not locked
            base_width = LOCK_RING_WIDTH + (
                LOCK_RING_SELECTED_EXTRA_WIDTH if selected else 0
            )
            pygame.draw.arc(
                app.screen,
                COLOR_SUCCESS if locked else COLOR_ACCENT,
                arc_rect,
                0.0,
                math.tau,
                app._s(base_width),
            )
            if not locked:
                target = math.radians(float(ring["target"]))
                zone = math.radians(self.correct_zone_degrees)
                pygame.draw.arc(
                    app.screen,
                    COLOR_SUCCESS,
                    arc_rect,
                    target - zone,
                    target + zone,
                    app._s(LOCK_TARGET_ARC_WIDTH),
                )
                current = math.radians(float(ring["angle"]))
                marker = math.radians(LOCK_CURRENT_ARC_DEGREES)
                pygame.draw.arc(
                    app.screen,
                    COLOR_HOT_ACCENT if selected else COLOR_TEXT,
                    arc_rect,
                    current - marker / 2,
                    current + marker / 2,
                    app._s(base_width),
                )
        center_size = LOCK_CENTER_SQUARE_SIZE
        pygame.draw.rect(
            app.screen,
            COLOR_SUCCESS
            if all(bool(item["locked"]) for item in self.rings)
            else COLOR_HOT_ACCENT,
            app._rect(
                (
                    center_x - center_size // 2,
                    center_y - center_size // 2,
                    center_size,
                    center_size,
                )
            ),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        app._draw_text(
            (
                f"КОЛЬЦО {self.selected_ring + 1}/{self.ring_count}  //  "
                f"ЗАФИКСИРОВАНО {sum(bool(ring['locked']) for ring in self.rings)}"
            ),
            LOCK_INSTRUCTION_CENTER,
            LOCK_INSTRUCTION_FONT_SIZE,
            COLOR_TEXT,
            center=True,
        )
        if self.finished:
            app._draw_minigame_result(self.success)


class FirewallMaze(MiniGameBase):
    """Процедурный лабиринт с подвижными круговыми сканерами."""

    title = "ОБХОД ФАЕРАВОЛЛА // FIREWALL MAZE"
    NORTH = 0
    EAST = 1
    SOUTH = 2
    WEST = 3

    def __init__(self, difficulty: int) -> None:
        duration = (
            FIREWALL_TIME_BASE_SECONDS
            - (difficulty - MINIGAME_DIFFICULTY_MIN) * FIREWALL_TIME_DIFFICULTY_PENALTY
        )
        super().__init__(difficulty, duration)
        self.random = random.Random()
        self.columns = FIREWALL_GRID_COLUMNS_BASE + (
            difficulty * FIREWALL_GRID_COLUMNS_STEP
        )
        self.rows = FIREWALL_GRID_ROWS_BASE + difficulty
        self.walls = self._generate_maze_walls()
        self.start_position = self._cell_center(0, 0)
        self.player_position = pygame.Vector2(self.start_position)
        self.exit_rect = self._make_exit_rect()
        self.elapsed = 0.0
        self.hits = 0
        self.invulnerability = 0.0
        self.scanners = self._make_scanners()
        self.scanner_positions: list[tuple[float, float]] = []

    def _cell_bounds(self, column: int, row: int) -> pygame.Rect:
        area = pygame.Rect(FIREWALL_MAZE_RECT)
        x0 = area.x + round(column * area.width / self.columns)
        x1 = area.x + round((column + 1) * area.width / self.columns)
        y0 = area.y + round(row * area.height / self.rows)
        y1 = area.y + round((row + 1) * area.height / self.rows)
        return pygame.Rect(x0, y0, x1 - x0, y1 - y0)

    def _cell_center(self, column: int, row: int) -> tuple[float, float]:
        return self._cell_bounds(column, row).center

    def _generate_maze_walls(self) -> list[pygame.Rect]:
        cells = [
            [[True, True, True, True] for _column in range(self.columns)]
            for _row in range(self.rows)
        ]
        visited = {(0, 0)}
        stack = [(0, 0)]
        directions = (
            (0, -1, self.NORTH, self.SOUTH),
            (1, 0, self.EAST, self.WEST),
            (0, 1, self.SOUTH, self.NORTH),
            (-1, 0, self.WEST, self.EAST),
        )
        while stack:
            column, row = stack[-1]
            neighbours = []
            for dx, dy, wall, opposite in directions:
                next_column = column + dx
                next_row = row + dy
                if (
                    0 <= next_column < self.columns
                    and 0 <= next_row < self.rows
                    and (next_column, next_row) not in visited
                ):
                    neighbours.append((next_column, next_row, wall, opposite))
            if not neighbours:
                stack.pop()
                continue
            next_column, next_row, wall, opposite = self.random.choice(neighbours)
            cells[row][column][wall] = False
            cells[next_row][next_column][opposite] = False
            visited.add((next_column, next_row))
            stack.append((next_column, next_row))

        thickness = FIREWALL_WALL_THICKNESS
        wall_rects: list[pygame.Rect] = []
        for row in range(self.rows):
            for column in range(self.columns):
                bounds = self._cell_bounds(column, row)
                north, east, south, west = cells[row][column]
                if north:
                    wall_rects.append(
                        pygame.Rect(bounds.x, bounds.y, bounds.width, thickness)
                    )
                if west:
                    wall_rects.append(
                        pygame.Rect(bounds.x, bounds.y, thickness, bounds.height)
                    )
                if row == self.rows - 1 and south:
                    wall_rects.append(
                        pygame.Rect(
                            bounds.x,
                            bounds.bottom - thickness,
                            bounds.width,
                            thickness,
                        )
                    )
                if column == self.columns - 1 and east:
                    wall_rects.append(
                        pygame.Rect(
                            bounds.right - thickness,
                            bounds.y,
                            thickness,
                            bounds.height,
                        )
                    )
        return wall_rects

    def _make_exit_rect(self) -> pygame.Rect:
        cell = self._cell_bounds(self.columns - 1, self.rows - 1)
        size = min(FIREWALL_EXIT_SIZE, cell.width - 8, cell.height - 8)
        exit_rect = pygame.Rect(0, 0, size, size)
        exit_rect.center = cell.center
        return exit_rect

    def _make_scanners(self) -> list[dict[str, float | bool]]:
        count = FIREWALL_SCANNER_COUNT_BASE + self.difficulty
        scanners: list[dict[str, float | bool]] = []
        for index in range(count):
            scanners.append(
                {
                    "horizontal": index % 2 == 0,
                    "lane": (index + 1) / (count + 1),
                    "phase": self.random.uniform(0.0, math.tau),
                    "speed": FIREWALL_SCANNER_SPEED_BASE
                    + index * FIREWALL_SCANNER_SPEED_STEP
                    + self.difficulty * FIREWALL_SCANNER_SPEED_STEP,
                }
            )
        return scanners

    def _player_rect_at(self, position: pygame.Vector2) -> pygame.Rect:
        rect = pygame.Rect(0, 0, FIREWALL_PLAYER_SIZE, FIREWALL_PLAYER_SIZE)
        rect.center = (round(position.x), round(position.y))
        return rect

    def _collides_wall(self, position: pygame.Vector2) -> bool:
        player = self._player_rect_at(position)
        return any(player.colliderect(wall) for wall in self.walls)

    @staticmethod
    def _circle_hits_rect(
        center: tuple[float, float],
        radius: float,
        rect: pygame.Rect,
    ) -> bool:
        nearest_x = min(max(center[0], rect.left), rect.right)
        nearest_y = min(max(center[1], rect.top), rect.bottom)
        return (center[0] - nearest_x) ** 2 + (center[1] - nearest_y) ** 2 <= radius**2

    def _update_scanners(self) -> None:
        area = pygame.Rect(FIREWALL_MAZE_RECT)
        margin = FIREWALL_SCANNER_MARGIN
        self.scanner_positions = []
        for scanner in self.scanners:
            wave = (
                math.sin(
                    self.elapsed * float(scanner["speed"]) + float(scanner["phase"])
                )
                + 1.0
            ) / 2.0
            if bool(scanner["horizontal"]):
                x = area.left + margin + wave * (area.width - margin * 2)
                y = area.top + float(scanner["lane"]) * area.height
            else:
                x = area.left + float(scanner["lane"]) * area.width
                y = area.top + margin + wave * (area.height - margin * 2)
            self.scanner_positions.append((x, y))

    def update(self, delta_seconds: float) -> None:
        if not self.tick_timer(delta_seconds) or self.finished:
            return
        self.elapsed += delta_seconds
        self.invulnerability = max(0.0, self.invulnerability - delta_seconds)
        keys = pygame.key.get_pressed()
        direction = pygame.Vector2(
            float(keys[pygame.K_d]) - float(keys[pygame.K_a]),
            float(keys[pygame.K_s]) - float(keys[pygame.K_w]),
        )
        if direction.length_squared() > 0.0:
            direction.normalize_ip()
            movement = direction * FIREWALL_PLAYER_SPEED * delta_seconds
            candidate_x = pygame.Vector2(
                self.player_position.x + movement.x,
                self.player_position.y,
            )
            if not self._collides_wall(candidate_x):
                self.player_position.x = candidate_x.x
            candidate_y = pygame.Vector2(
                self.player_position.x,
                self.player_position.y + movement.y,
            )
            if not self._collides_wall(candidate_y):
                self.player_position.y = candidate_y.y

        self._update_scanners()
        player_rect = self._player_rect_at(self.player_position)
        if self.invulnerability <= 0.0 and any(
            self._circle_hits_rect(
                scanner,
                FIREWALL_SCANNER_RADIUS,
                player_rect,
            )
            for scanner in self.scanner_positions
        ):
            self.player_position.update(self.start_position)
            self.hits += 1
            self.invulnerability = FIREWALL_RESET_INVULNERABILITY
            player_rect = self._player_rect_at(self.player_position)
        if player_rect.colliderect(self.exit_rect):
            self.finish(True)

    def draw(self, app: ZeroDayApp) -> None:
        app._draw_minigame_frame(self.title, self.time_left)
        area = pygame.Rect(FIREWALL_MAZE_RECT)
        pygame.draw.rect(app.screen, COLOR_PANEL, app._window_rect(area))
        pygame.draw.rect(
            app.screen,
            COLOR_ACCENT,
            app._window_rect(area),
            width=app._s(BORDER_WIDTH),
        )
        pygame.draw.rect(
            app.screen,
            COLOR_SUCCESS,
            app._window_rect(self.exit_rect),
        )
        for wall in self.walls:
            pygame.draw.rect(app.screen, COLOR_TEXT, app._window_rect(wall))
        for scanner in self.scanner_positions:
            pygame.draw.circle(
                app.screen,
                COLOR_ERROR,
                app._point(scanner),
                app._s(FIREWALL_SCANNER_RADIUS),
            )
        player_rect = self._player_rect_at(self.player_position)
        player_color = (
            COLOR_SUCCESS
            if self.invulnerability > 0.0 and int(self.elapsed * 10) % 2 == 0
            else COLOR_HOT_ACCENT
        )
        pygame.draw.rect(app.screen, player_color, app._window_rect(player_rect))
        app._draw_text(
            f"СБРОСОВ: {self.hits}  //  СЕТКА: {self.columns}×{self.rows}",
            FIREWALL_HIT_TEXT_POS,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_TEXT,
        )
        if self.finished:
            app._draw_minigame_result(self.success)


class PacketSniffer(MiniGameBase):
    """Перехват зелёных пакетов управляемым мышью сниффером."""

    title = "ПЕРЕХВАТ ДАННЫХ // PACKET SNIFFER"

    def __init__(self, difficulty: int) -> None:
        super().__init__(difficulty, SNIFFER_TIME_SECONDS)
        self.random = random.Random()
        self.target_count = SNIFFER_TARGET_BASE + (
            difficulty * SNIFFER_TARGET_DIFFICULTY_STEP
        )
        self.caught = 0
        self.trash_caught = 0
        self.spawn_timer = 0.0
        self.harmful_packet_multiplier = 1.0
        self.packets: list[dict[str, float | bool]] = []
        self.sniffer_x = DESIGN_WIDTH / 2 - SNIFFER_BAR_SIZE[0] / 2
        self.flash_time = 0.0

    def _sniffer_rect(self) -> pygame.Rect:
        return pygame.Rect(
            round(self.sniffer_x),
            SNIFFER_BAR_Y,
            SNIFFER_BAR_SIZE[0],
            SNIFFER_BAR_SIZE[1],
        )

    def _move_sniffer(self, mouse_x: float) -> None:
        field = pygame.Rect(SNIFFER_FIELD_RECT)
        self.sniffer_x = min(
            field.right - SNIFFER_BAR_SIZE[0],
            max(field.left, mouse_x - SNIFFER_BAR_SIZE[0] / 2),
        )

    def _spawn_packet(self) -> None:
        field = pygame.Rect(SNIFFER_FIELD_RECT)
        packet_width, packet_height = SNIFFER_PACKET_SIZE
        base_target_chance = max(
            0.25,
            SNIFFER_TARGET_CHANCE_BASE
            - self.difficulty * SNIFFER_TARGET_CHANCE_DIFFICULTY_STEP,
        )
        harmful_chance = (1.0 - base_target_chance) * self.harmful_packet_multiplier
        target_chance = min(1.0, max(0.0, 1.0 - harmful_chance))
        self.packets.append(
            {
                "x": self.random.uniform(field.left, field.right - packet_width),
                "y": float(field.top - packet_height),
                "target": self.random.random() < target_chance,
                "speed": SNIFFER_SPEED_BASE
                + self.difficulty * SNIFFER_SPEED_DIFFICULTY_STEP
                + self.random.uniform(0.0, SNIFFER_SPEED_VARIATION),
            }
        )

    def handle_event(self, event: pygame.event.Event, app: ZeroDayApp) -> None:
        if event.type == pygame.MOUSEMOTION and not self.finished:
            mouse_x, _mouse_y = app._desktop_point(event.pos)
            self._move_sniffer(mouse_x)

    def update(self, delta_seconds: float) -> None:
        if not self.tick_timer(delta_seconds) or self.finished:
            return
        self.flash_time = max(0.0, self.flash_time - delta_seconds)
        spawn_interval = max(
            SNIFFER_SPAWN_MIN_SECONDS,
            SNIFFER_SPAWN_BASE_SECONDS
            - self.difficulty * SNIFFER_SPAWN_DIFFICULTY_STEP,
        )
        self.spawn_timer -= delta_seconds
        while self.spawn_timer <= 0.0:
            self._spawn_packet()
            self.spawn_timer += spawn_interval

        sniffer = self._sniffer_rect()
        field = pygame.Rect(SNIFFER_FIELD_RECT)
        remaining_packets: list[dict[str, float | bool]] = []
        for packet in self.packets:
            packet["y"] = float(packet["y"]) + float(packet["speed"]) * delta_seconds
            packet_rect = pygame.Rect(
                round(float(packet["x"])),
                round(float(packet["y"])),
                SNIFFER_PACKET_SIZE[0],
                SNIFFER_PACKET_SIZE[1],
            )
            if packet_rect.colliderect(sniffer):
                if bool(packet["target"]):
                    self.caught += 1
                    if self.caught >= self.target_count:
                        self.finish(True)
                        break
                else:
                    self.trash_caught += 1
                    self.caught = max(0, self.caught - SNIFFER_TRASH_PENALTY)
                    self.flash_time = SNIFFER_FLASH_SECONDS
                continue
            if packet_rect.top <= field.bottom:
                remaining_packets.append(packet)
        self.packets = remaining_packets

    def draw(self, app: ZeroDayApp) -> None:
        app._draw_minigame_frame(self.title, self.time_left)
        field = pygame.Rect(SNIFFER_FIELD_RECT)
        pygame.draw.rect(app.screen, COLOR_PANEL, app._window_rect(field))
        pygame.draw.rect(
            app.screen,
            COLOR_ERROR if self.flash_time > 0.0 else COLOR_ACCENT,
            app._window_rect(field),
            width=app._s(BORDER_WIDTH),
        )
        for packet in self.packets:
            packet_rect = pygame.Rect(
                round(float(packet["x"])),
                round(float(packet["y"])),
                SNIFFER_PACKET_SIZE[0],
                SNIFFER_PACKET_SIZE[1],
            )
            target = bool(packet["target"])
            pygame.draw.rect(
                app.screen,
                COLOR_SUCCESS if target else COLOR_ERROR,
                app._window_rect(packet_rect),
                border_radius=app._s(BUTTON_CORNER_RADIUS // 2),
            )
            app._draw_text(
                "D" if target else "X",
                packet_rect.center,
                SNIFFER_PACKET_FONT_SIZE,
                COLOR_BACKGROUND,
                center=True,
                bold=True,
            )
        sniffer = self._sniffer_rect()
        pygame.draw.rect(
            app.screen,
            COLOR_SUCCESS,
            app._window_rect(sniffer),
            border_radius=app._s(BUTTON_CORNER_RADIUS // 2),
        )
        pygame.draw.rect(
            app.screen,
            COLOR_TEXT,
            app._window_rect(sniffer),
            width=app._s(BORDER_WIDTH),
            border_radius=app._s(BUTTON_CORNER_RADIUS // 2),
        )
        app._draw_text(
            f"ПОЙМАНО {self.caught}/{self.target_count}  //  МУСОР {self.trash_caught}",
            SNIFFER_INSTRUCTION_CENTER,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        if self.finished:
            app._draw_minigame_result(self.success)


class NetworkNodes(MiniGameBase):
    """Планарная сеть: линии проверяются через векторное произведение."""

    title = "ВЗЛОМ СЕТИ // NETWORK NODES"

    def __init__(self, difficulty: int) -> None:
        duration = (
            NETWORK_TIME_BASE_SECONDS
            - (difficulty - MINIGAME_DIFFICULTY_MIN) * NETWORK_TIME_DIFFICULTY_PENALTY
        )
        super().__init__(difficulty, duration)
        self.random = random.Random()
        self.node_count = min(
            NETWORK_NODE_COUNT_MAX,
            NETWORK_NODE_COUNT_MIN
            + math.ceil(
                (difficulty - MINIGAME_DIFFICULTY_MIN)
                * NETWORK_NODE_COUNT_DIFFICULTY_STEP
            ),
        )
        self.edges = self._make_planar_edges()
        self.nodes = self._make_scrambled_nodes()
        self.dragged_node: int | None = None
        self.intersecting_edges = self._find_intersecting_edges()

    def _make_planar_edges(self) -> list[tuple[int, int]]:
        edges = [
            (index, (index + 1) % self.node_count) for index in range(self.node_count)
        ]
        edges.extend((0, index) for index in range(2, self.node_count - 1))
        return edges

    def _make_scrambled_nodes(self) -> list[pygame.Vector2]:
        center_x, center_y = NETWORK_LAYOUT_CENTER
        positions = [
            pygame.Vector2(
                center_x
                + math.cos(math.tau * index / self.node_count)
                * NETWORK_PLANAR_LAYOUT_RADIUS,
                center_y
                + math.sin(math.tau * index / self.node_count)
                * NETWORK_PLANAR_LAYOUT_RADIUS,
            )
            for index in range(self.node_count)
        ]
        for _attempt in range(NETWORK_INITIAL_SHUFFLES):
            self.random.shuffle(positions)
            self.nodes = [position.copy() for position in positions]
            if self._find_intersecting_edges():
                return self.nodes
        return [position.copy() for position in positions]

    @staticmethod
    def _cross(
        point_a: pygame.Vector2,
        point_b: pygame.Vector2,
        point_c: pygame.Vector2,
    ) -> float:
        """Cross product (B-A) × (C-A), используемый для пересечений."""
        return (point_b.x - point_a.x) * (point_c.y - point_a.y) - (
            point_b.y - point_a.y
        ) * (point_c.x - point_a.x)

    @staticmethod
    def _on_segment(
        point_a: pygame.Vector2,
        point_b: pygame.Vector2,
        point: pygame.Vector2,
    ) -> bool:
        return min(point_a.x, point_b.x) <= point.x <= max(
            point_a.x, point_b.x
        ) and min(point_a.y, point_b.y) <= point.y <= max(point_a.y, point_b.y)

    @classmethod
    def segments_intersect(
        cls,
        point_a: pygame.Vector2,
        point_b: pygame.Vector2,
        point_c: pygame.Vector2,
        point_d: pygame.Vector2,
    ) -> bool:
        cross_1 = cls._cross(point_a, point_b, point_c)
        cross_2 = cls._cross(point_a, point_b, point_d)
        cross_3 = cls._cross(point_c, point_d, point_a)
        cross_4 = cls._cross(point_c, point_d, point_b)
        epsilon = 1e-7
        if (
            (cross_1 > epsilon and cross_2 < -epsilon)
            or (cross_1 < -epsilon and cross_2 > epsilon)
        ) and (
            (cross_3 > epsilon and cross_4 < -epsilon)
            or (cross_3 < -epsilon and cross_4 > epsilon)
        ):
            return True
        if abs(cross_1) <= epsilon and cls._on_segment(point_a, point_b, point_c):
            return True
        if abs(cross_2) <= epsilon and cls._on_segment(point_a, point_b, point_d):
            return True
        if abs(cross_3) <= epsilon and cls._on_segment(point_c, point_d, point_a):
            return True
        return abs(cross_4) <= epsilon and cls._on_segment(point_c, point_d, point_b)

    def _find_intersecting_edges(self) -> set[int]:
        intersections: set[int] = set()
        for first_index, first_edge in enumerate(self.edges):
            for second_index in range(first_index + 1, len(self.edges)):
                second_edge = self.edges[second_index]
                if set(first_edge) & set(second_edge):
                    continue
                if self.segments_intersect(
                    self.nodes[first_edge[0]],
                    self.nodes[first_edge[1]],
                    self.nodes[second_edge[0]],
                    self.nodes[second_edge[1]],
                ):
                    intersections.update((first_index, second_index))
        return intersections

    def _update_intersections(self) -> None:
        self.intersecting_edges = self._find_intersecting_edges()
        if not self.intersecting_edges:
            self.finish(True)

    def handle_event(self, event: pygame.event.Event, app: ZeroDayApp) -> None:
        if self.finished:
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            point = pygame.Vector2(app._desktop_point(event.pos))
            candidates = [
                (point.distance_to(node), index)
                for index, node in enumerate(self.nodes)
                if point.distance_to(node) <= NETWORK_NODE_DRAG_RADIUS
            ]
            if candidates:
                self.dragged_node = min(candidates)[1]
        elif event.type == pygame.MOUSEMOTION and self.dragged_node is not None:
            point = pygame.Vector2(app._desktop_point(event.pos))
            area = pygame.Rect(NETWORK_PLAY_RECT)
            point.x = min(
                area.right - NETWORK_RANDOM_MARGIN,
                max(area.left + NETWORK_RANDOM_MARGIN, point.x),
            )
            point.y = min(
                area.bottom - NETWORK_RANDOM_MARGIN,
                max(area.top + NETWORK_RANDOM_MARGIN, point.y),
            )
            self.nodes[self.dragged_node].update(point)
            self._update_intersections()
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragged_node = None
            self._update_intersections()

    def update(self, delta_seconds: float) -> None:
        self.tick_timer(delta_seconds)

    def draw(self, app: ZeroDayApp) -> None:
        app._draw_minigame_frame(self.title, self.time_left)
        all_clear = not self.intersecting_edges
        for index, (start, end) in enumerate(self.edges):
            color = (
                COLOR_SUCCESS
                if all_clear
                else COLOR_ERROR
                if index in self.intersecting_edges
                else COLOR_ACCENT
            )
            pygame.draw.line(
                app.screen,
                color,
                app._point(self.nodes[start]),
                app._point(self.nodes[end]),
                app._s(NETWORK_LINE_WIDTH),
            )
        for index, node in enumerate(self.nodes):
            pygame.draw.circle(
                app.screen,
                COLOR_HOT_ACCENT if index == self.dragged_node else COLOR_PANEL,
                app._point(node),
                app._s(NETWORK_NODE_RADIUS),
            )
            pygame.draw.circle(
                app.screen,
                COLOR_SUCCESS if all_clear else COLOR_TEXT,
                app._point(node),
                app._s(NETWORK_NODE_RADIUS),
                width=app._s(BORDER_WIDTH),
            )
            app._draw_text(
                str(index + 1),
                node,
                NETWORK_NODE_FONT_SIZE,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
        app._draw_text(
            (
                f"УЗЛОВ {self.node_count}  //  "
                f"ПЕРЕСЕЧЕНИЙ {len(self.intersecting_edges)}"
            ),
            NETWORK_STATUS_CENTER,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_SUCCESS if all_clear else COLOR_TEXT,
            center=True,
            bold=True,
        )
        if self.finished:
            app._draw_minigame_result(self.success)


class DDoSClicker(MiniGameBase):
    """Кликер с ограничением частоты запросов и двухсекундным перегревом."""

    title = "DDOS-АТАКА // REQUEST FLOOD"

    def __init__(self, difficulty: int) -> None:
        super().__init__(difficulty, DDOS_TIME_SECONDS)
        self.max_hp = DDOS_SERVER_HP_BASE + difficulty * DDOS_SERVER_HP_DIFFICULTY_STEP
        self.hp = self.max_hp
        self.elapsed = 0.0
        self.request_limit = DDOS_MAX_REQUESTS_PER_SECOND
        self.overheat_duration = DDOS_OVERHEAT_SECONDS
        self.request_times: list[float] = []
        self.overheat_remaining = 0.0
        self.total_requests = 0
        self.overheats = 0

    def _purge_request_window(self) -> None:
        cutoff = self.elapsed - DDOS_RATE_WINDOW_SECONDS
        self.request_times = [stamp for stamp in self.request_times if stamp > cutoff]

    def _send_request(self) -> None:
        if self.finished or self.overheat_remaining > 0.0:
            return
        self._purge_request_window()
        if len(self.request_times) >= self.request_limit:
            self.overheat_remaining = self.overheat_duration
            self.request_times.clear()
            self.overheats += 1
            return
        self.request_times.append(self.elapsed)
        self.total_requests += 1
        self.hp = max(0, self.hp - 1)
        if self.hp <= 0:
            self.finish(True)

    def handle_event(self, event: pygame.event.Event, app: ZeroDayApp) -> None:
        if self.finished:
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            point = app._desktop_point(event.pos)
            if pygame.Rect(DDOS_REQUEST_BUTTON_RECT).collidepoint(point):
                self._send_request()
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            self._send_request()

    def update(self, delta_seconds: float) -> None:
        if not self.tick_timer(delta_seconds) or self.finished:
            return
        self.elapsed += delta_seconds
        self.overheat_remaining = max(0.0, self.overheat_remaining - delta_seconds)
        self._purge_request_window()

    def draw(self, app: ZeroDayApp) -> None:
        app._draw_minigame_frame(self.title, self.time_left)
        hp_bar = pygame.Rect(DDOS_HP_BAR_RECT)
        pygame.draw.rect(
            app.screen,
            COLOR_TASKBAR,
            app._window_rect(hp_bar),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        inset = DDOS_HP_BAR_INSET
        hp_fraction = self.hp / self.max_hp
        pygame.draw.rect(
            app.screen,
            COLOR_ERROR if hp_fraction < 0.3 else COLOR_HOT_ACCENT,
            app._rect(
                (
                    hp_bar.x + inset,
                    hp_bar.y + inset,
                    round((hp_bar.width - inset * 2) * hp_fraction),
                    hp_bar.height - inset * 2,
                )
            ),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        pygame.draw.rect(
            app.screen,
            COLOR_TEXT,
            app._window_rect(hp_bar),
            width=app._s(BORDER_WIDTH),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        app._draw_text(
            f"SERVER HP {self.hp}/{self.max_hp}",
            hp_bar.center,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )

        server = pygame.Rect(DDOS_SERVER_RECT)
        pygame.draw.rect(
            app.screen,
            COLOR_PANEL,
            app._window_rect(server),
            border_radius=app._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            app.screen,
            COLOR_ACCENT,
            app._window_rect(server),
            width=app._s(BORDER_WIDTH),
            border_radius=app._s(PANEL_CORNER_RADIUS),
        )
        light_x, light_y = DDOS_SERVER_LIGHT_START
        for index in range(4):
            pygame.draw.circle(
                app.screen,
                COLOR_ERROR if self.overheat_remaining > 0.0 else COLOR_SUCCESS,
                app._point((light_x + index * DDOS_SERVER_LIGHT_GAP, light_y)),
                app._s(DDOS_SERVER_LIGHT_SIZE // 2),
            )
        slot = pygame.Rect(DDOS_SERVER_SLOT_RECT)
        pygame.draw.rect(
            app.screen,
            COLOR_TASKBAR,
            app._window_rect(slot),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        app._draw_text(
            "TARGET SERVER",
            slot.center,
            FONT_SIZE_HEADING,
            COLOR_ERROR,
            center=True,
            bold=True,
        )

        cooldown = pygame.Rect(DDOS_COOLDOWN_BAR_RECT)
        pygame.draw.rect(app.screen, COLOR_TASKBAR, app._window_rect(cooldown))
        if self.overheat_remaining > 0.0:
            cooldown_fraction = self.overheat_remaining / self.overheat_duration
            cooldown_color = COLOR_ERROR
        else:
            cooldown_fraction = min(
                1.0,
                len(self.request_times) / self.request_limit,
            )
            cooldown_color = COLOR_HOT_ACCENT
        pygame.draw.rect(
            app.screen,
            cooldown_color,
            app._rect(
                (
                    cooldown.x,
                    cooldown.y,
                    round(cooldown.width * cooldown_fraction),
                    cooldown.height,
                )
            ),
        )
        pygame.draw.rect(
            app.screen,
            COLOR_TEXT,
            app._window_rect(cooldown),
            width=app._s(THIN_LINE_WIDTH),
        )

        request_button = pygame.Rect(DDOS_REQUEST_BUTTON_RECT)
        mouse = app._desktop_point(pygame.mouse.get_pos())
        blocked = self.overheat_remaining > 0.0
        button_color = (
            COLOR_ERROR
            if blocked
            else COLOR_HOT_ACCENT
            if request_button.collidepoint(mouse)
            else COLOR_ACCENT
        )
        pygame.draw.rect(
            app.screen,
            button_color,
            app._window_rect(request_button),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        pygame.draw.rect(
            app.screen,
            COLOR_ERROR if blocked else COLOR_TEXT,
            app._window_rect(request_button),
            width=app._s(BORDER_WIDTH),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        app._draw_text(
            (f"OVERHEAT {self.overheat_remaining:.1f}s" if blocked else "SEND REQUEST"),
            request_button.center,
            DDOS_BUTTON_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        app._draw_text(
            (
                f"ЗАПРОСОВ {self.total_requests}  //  "
                f"ПЕРЕГРЕВОВ {self.overheats}  //  ЛИМИТ {self.request_limit}/СЕК"
            ),
            DDOS_STATUS_CENTER,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_ERROR if blocked else COLOR_TEXT,
            center=True,
        )
        if self.finished:
            app._draw_minigame_result(self.success)


class SocialEngineering(MiniGameBase):
    """Диалоговая игра со шкалой доверия и вариантами ответа."""

    title = "СОЦИАЛЬНАЯ ИНЖЕНЕРИЯ // TRUST PROTOCOL"

    def __init__(self, difficulty: int) -> None:
        super().__init__(difficulty, SOCIAL_TIME_SECONDS)
        self.random = random.Random()
        self.round_count = min(
            len(SOCIAL_DIALOGUES),
            SOCIAL_ROUND_COUNT_BASE
            + (difficulty - MINIGAME_DIFFICULTY_MIN)
            // SOCIAL_ROUND_COUNT_DIFFICULTY_STEP,
        )
        self.dialogues = self.random.sample(SOCIAL_DIALOGUES, self.round_count)
        self.round_index = 0
        self.trust = 0
        self.feedback = ""
        self.feedback_positive = True

    @staticmethod
    def _option_rect(index: int) -> pygame.Rect:
        return pygame.Rect(
            SOCIAL_OPTION_X,
            SOCIAL_OPTION_START_Y + index * (SOCIAL_OPTION_HEIGHT + SOCIAL_OPTION_GAP),
            SOCIAL_OPTION_WIDTH,
            SOCIAL_OPTION_HEIGHT,
        )

    def _choose_answer(self, option_index: int) -> None:
        if self.finished or self.round_index >= self.round_count:
            return
        options = self.dialogues[self.round_index]["options"]
        if not isinstance(options, list) or not 0 <= option_index < len(options):
            return
        option = options[option_index]
        if not isinstance(option, dict):
            return
        correct = bool(option.get("correct"))
        if correct:
            delta = min(
                SOCIAL_CORRECT_MAX_DELTA,
                max(SOCIAL_CORRECT_MIN_DELTA, int(option.get("delta", 0))),
            )
            self.feedback = f"Убедительно: +{delta}% доверия"
        else:
            delta = SOCIAL_WRONG_DELTA
            self.feedback = f"Подозрительно: {delta}% доверия"
        self.feedback_positive = correct
        self.trust = min(100, max(0, self.trust + delta))
        self.round_index += 1
        if self.trust >= 100:
            self.finish(True)
        elif self.round_index >= self.round_count:
            self.finish(False)

    def handle_event(self, event: pygame.event.Event, app: ZeroDayApp) -> None:
        if self.finished:
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            point = app._desktop_point(event.pos)
            options = self.dialogues[self.round_index]["options"]
            if isinstance(options, list):
                for index in range(len(options)):
                    if self._option_rect(index).collidepoint(point):
                        self._choose_answer(index)
                        return
        elif event.type == pygame.KEYDOWN:
            key_to_option = {
                pygame.K_1: 0,
                pygame.K_2: 1,
                pygame.K_3: 2,
                pygame.K_4: 3,
            }
            if event.key in key_to_option:
                self._choose_answer(key_to_option[event.key])

    def update(self, delta_seconds: float) -> None:
        self.tick_timer(delta_seconds)

    def draw(self, app: ZeroDayApp) -> None:
        app._draw_minigame_frame(self.title, self.time_left)
        trust_bar = pygame.Rect(SOCIAL_TRUST_BAR_RECT)
        pygame.draw.rect(
            app.screen,
            COLOR_TASKBAR,
            app._window_rect(trust_bar),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        trust_width = round(
            (trust_bar.width - SOCIAL_TRUST_BAR_INSET * 2) * self.trust / 100
        )
        if trust_width > 0:
            pygame.draw.rect(
                app.screen,
                COLOR_SUCCESS,
                app._rect(
                    (
                        trust_bar.x + SOCIAL_TRUST_BAR_INSET,
                        trust_bar.y + SOCIAL_TRUST_BAR_INSET,
                        trust_width,
                        trust_bar.height - SOCIAL_TRUST_BAR_INSET * 2,
                    )
                ),
                border_radius=app._s(BUTTON_CORNER_RADIUS),
            )
        pygame.draw.rect(
            app.screen,
            COLOR_TEXT,
            app._window_rect(trust_bar),
            width=app._s(BORDER_WIDTH),
            border_radius=app._s(BUTTON_CORNER_RADIUS),
        )
        app._draw_text(
            f"ДОВЕРИЕ {self.trust}%",
            trust_bar.center,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )

        npc_panel = pygame.Rect(SOCIAL_NPC_RECT)
        pygame.draw.rect(
            app.screen,
            COLOR_PANEL,
            app._window_rect(npc_panel),
            border_radius=app._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            app.screen,
            COLOR_ACCENT,
            app._window_rect(npc_panel),
            width=app._s(BORDER_WIDTH),
            border_radius=app._s(PANEL_CORNER_RADIUS),
        )
        dialogue_index = min(self.round_index, self.round_count - 1)
        dialogue = self.dialogues[dialogue_index]
        app._draw_text(
            f"NPC // РАУНД {min(self.round_index + 1, self.round_count)}/{self.round_count}",
            (SOCIAL_NPC_TEXT_POS[0], SOCIAL_NPC_TEXT_POS[1] - SOCIAL_NPC_LINE_HEIGHT),
            MINIGAME_INFO_FONT_SIZE,
            COLOR_HOT_ACCENT,
            bold=True,
        )
        npc_lines = app._wrap_text(
            str(dialogue["npc"]),
            app._font(FONT_SIZE_BODY),
            app._s(SOCIAL_NPC_TEXT_MAX_WIDTH),
        )
        for line_index, line in enumerate(npc_lines):
            app._draw_text(
                line,
                (
                    SOCIAL_NPC_TEXT_POS[0],
                    SOCIAL_NPC_TEXT_POS[1] + line_index * SOCIAL_NPC_LINE_HEIGHT,
                ),
                FONT_SIZE_BODY,
                COLOR_TEXT,
            )

        if self.feedback:
            app._draw_text(
                self.feedback,
                SOCIAL_FEEDBACK_CENTER,
                MINIGAME_INFO_FONT_SIZE,
                COLOR_SUCCESS if self.feedback_positive else COLOR_ERROR,
                center=True,
                bold=True,
            )

        if not self.finished:
            options = dialogue["options"]
            if isinstance(options, list):
                mouse = app._desktop_point(pygame.mouse.get_pos())
                for index, option in enumerate(options):
                    if not isinstance(option, dict):
                        continue
                    option_rect = self._option_rect(index)
                    hovered = option_rect.collidepoint(mouse)
                    pygame.draw.rect(
                        app.screen,
                        COLOR_ACCENT if hovered else COLOR_TASKBAR,
                        app._window_rect(option_rect),
                        border_radius=app._s(BUTTON_CORNER_RADIUS),
                    )
                    pygame.draw.rect(
                        app.screen,
                        COLOR_HOT_ACCENT if hovered else COLOR_ACCENT,
                        app._window_rect(option_rect),
                        width=app._s(BORDER_WIDTH),
                        border_radius=app._s(BUTTON_CORNER_RADIUS),
                    )
                    text = app._fit_text(
                        f"{index + 1}. {option['text']}",
                        app._font(MINIGAME_INFO_FONT_SIZE),
                        app._s(SOCIAL_OPTION_WIDTH - SOCIAL_OPTION_TEXT_PADDING * 2),
                    )
                    app._draw_text(
                        text,
                        (
                            option_rect.x + SOCIAL_OPTION_TEXT_PADDING,
                            option_rect.centery,
                        ),
                        MINIGAME_INFO_FONT_SIZE,
                        COLOR_TEXT,
                        center=False,
                    )
        if self.finished:
            app._draw_minigame_result(self.success)


class IntrusionDefense(MiniGameBase):
    """Реактивная защита сервера от стрелок, входящих из четырёх зон."""

    title = "INTRUSION DEFENSE // ACTIVE BREACH"
    KEY_BY_DIRECTION: Final[dict[str, int]] = {
        "w": pygame.K_w,
        "a": pygame.K_a,
        "s": pygame.K_s,
        "d": pygame.K_d,
    }

    def __init__(self, difficulty: int, duration: float | None = None) -> None:
        self.random = random.Random()
        if duration is None:
            duration = self.random.uniform(
                INTRUSION_DURATION_MIN_SECONDS,
                INTRUSION_DURATION_MAX_SECONDS,
            )
        super().__init__(difficulty, duration)
        self.duration = duration
        self.elapsed = 0.0
        self.spawn_timer = INTRUSION_INITIAL_SPAWN_DELAY
        self.arrows: list[dict[str, object]] = []
        self.hits = 0
        self.misses = 0
        self.damage_flash_remaining = 0.0
        self.success_flash_remaining = 0.0
        self.wrong_key_flash_remaining = 0.0
        self.outcome_applied = False
        self.speed_multiplier = 1.0
        self.feedback = "СИНХРОНИЗАЦИЯ ЗАЩИТЫ"

    def _spawn_arrow(self) -> None:
        direction = self.random.choice(tuple(self.KEY_BY_DIRECTION))
        if direction == "w":
            position = pygame.Vector2(
                self.random.uniform(
                    INTRUSION_SPAWN_MARGIN,
                    DESIGN_WIDTH - INTRUSION_SPAWN_MARGIN,
                ),
                MINIGAME_HEADER_HEIGHT,
            )
        elif direction == "a":
            position = pygame.Vector2(
                0.0,
                self.random.uniform(
                    MINIGAME_HEADER_HEIGHT + INTRUSION_SPAWN_MARGIN,
                    DESIGN_HEIGHT - INTRUSION_SPAWN_MARGIN,
                ),
            )
        elif direction == "s":
            position = pygame.Vector2(
                self.random.uniform(
                    INTRUSION_SPAWN_MARGIN,
                    DESIGN_WIDTH - INTRUSION_SPAWN_MARGIN,
                ),
                DESIGN_HEIGHT,
            )
        else:
            position = pygame.Vector2(
                DESIGN_WIDTH,
                self.random.uniform(
                    MINIGAME_HEADER_HEIGHT + INTRUSION_SPAWN_MARGIN,
                    DESIGN_HEIGHT - INTRUSION_SPAWN_MARGIN,
                ),
            )
        velocity = pygame.Vector2(INTRUSION_CENTER) - position
        if velocity.length_squared() > 0.0:
            velocity.normalize_ip()
        speed = (
            INTRUSION_SPEED_BASE
            + self.difficulty * INTRUSION_SPEED_DIFFICULTY_STEP
            + self.random.uniform(0.0, INTRUSION_SPEED_VARIATION)
        ) * self.speed_multiplier
        self.arrows.append(
            {
                "direction": direction,
                "position": position,
                "velocity": velocity,
                "speed": speed,
            }
        )

    @staticmethod
    def _distance_to_server(arrow: dict[str, object]) -> float:
        position = arrow["position"]
        if not isinstance(position, pygame.Vector2):
            return math.inf
        return position.distance_to(INTRUSION_CENTER)

    @classmethod
    def _in_hit_zone(cls, arrow: dict[str, object]) -> bool:
        distance = cls._distance_to_server(arrow)
        return (
            INTRUSION_HIT_ZONE_INNER_RADIUS
            <= distance
            <= INTRUSION_HIT_ZONE_OUTER_RADIUS
        )

    def _register_miss(self, feedback: str) -> None:
        self.misses += 1
        self.feedback = feedback
        self.damage_flash_remaining = INTRUSION_DAMAGE_FLASH_SECONDS
        if self.misses >= INTRUSION_MAX_MISSES:
            self.finish(False)

    def _press_direction(self, direction: str) -> None:
        if self.finished:
            return
        matching = [
            arrow
            for arrow in self.arrows
            if arrow["direction"] == direction and self._in_hit_zone(arrow)
        ]
        if matching:
            target = min(matching, key=self._distance_to_server)
            self.arrows.remove(target)
            self.hits += 1
            self.feedback = f"{direction.upper()} // THREAT PURGED"
            self.success_flash_remaining = INTRUSION_SUCCESS_FLASH_SECONDS
            return

        threats_in_zone = [arrow for arrow in self.arrows if self._in_hit_zone(arrow)]
        if threats_in_zone:
            target = min(threats_in_zone, key=self._distance_to_server)
            self.arrows.remove(target)
            self._register_miss(f"WRONG CHANNEL: {direction.upper()}")
        else:
            self.feedback = f"{direction.upper()} // TOO EARLY"
            self.wrong_key_flash_remaining = INTRUSION_WRONG_KEY_FLASH_SECONDS

    def handle_event(self, event: pygame.event.Event, app: ZeroDayApp) -> None:
        del app
        if event.type != pygame.KEYDOWN or self.finished:
            return
        for direction, key in self.KEY_BY_DIRECTION.items():
            if event.key == key:
                self._press_direction(direction)
                return

    def update(self, delta_seconds: float) -> None:
        self.damage_flash_remaining = max(
            0.0,
            self.damage_flash_remaining - delta_seconds,
        )
        self.success_flash_remaining = max(
            0.0,
            self.success_flash_remaining - delta_seconds,
        )
        self.wrong_key_flash_remaining = max(
            0.0,
            self.wrong_key_flash_remaining - delta_seconds,
        )
        if self.finished:
            return
        self.elapsed += delta_seconds
        self.time_left = max(0.0, self.time_left - delta_seconds)
        if self.time_left <= 0.0:
            self.finish(True)
            return

        spawn_interval = max(
            INTRUSION_SPAWN_INTERVAL_MIN,
            INTRUSION_SPAWN_INTERVAL_BASE
            - self.difficulty * INTRUSION_SPAWN_INTERVAL_DIFFICULTY_STEP,
        )
        self.spawn_timer -= delta_seconds
        while self.spawn_timer <= 0.0:
            self._spawn_arrow()
            self.spawn_timer += spawn_interval

        remaining: list[dict[str, object]] = []
        for arrow in self.arrows:
            position = arrow["position"]
            velocity = arrow["velocity"]
            if not isinstance(position, pygame.Vector2) or not isinstance(
                velocity, pygame.Vector2
            ):
                continue
            distance_before_move = position.distance_to(INTRUSION_CENTER)
            travel_distance = float(arrow["speed"]) * delta_seconds
            server_hit_distance = INTRUSION_SERVER_RADIUS + INTRUSION_ARROW_SIZE
            if distance_before_move - travel_distance <= server_hit_distance:
                position.update(INTRUSION_CENTER)
                self._register_miss("SERVER HIT // PACKET LOST")
                if self.finished:
                    break
            else:
                position += velocity * travel_distance
                remaining.append(arrow)
        self.arrows = remaining

    @staticmethod
    def _zone_polygons() -> dict[str, tuple[tuple[int, int], ...]]:
        center = INTRUSION_CENTER
        top_left = (0, MINIGAME_HEADER_HEIGHT)
        top_right = (DESIGN_WIDTH, MINIGAME_HEADER_HEIGHT)
        bottom_left = (0, DESIGN_HEIGHT)
        bottom_right = (DESIGN_WIDTH, DESIGN_HEIGHT)
        return {
            "w": (top_left, top_right, center),
            "a": (top_left, center, bottom_left),
            "s": (bottom_left, center, bottom_right),
            "d": (top_right, bottom_right, center),
        }

    def _draw_arrow(self, app: ZeroDayApp, arrow: dict[str, object]) -> None:
        position = arrow["position"]
        velocity = arrow["velocity"]
        if not isinstance(position, pygame.Vector2) or not isinstance(
            velocity, pygame.Vector2
        ):
            return
        perpendicular = pygame.Vector2(-velocity.y, velocity.x)
        tip = position + velocity * INTRUSION_ARROW_SIZE
        base = position - velocity * INTRUSION_ARROW_SIZE
        left = base + perpendicular * INTRUSION_ARROW_SIZE * INTRUSION_ARROW_WING_SCALE
        right = base - perpendicular * INTRUSION_ARROW_SIZE * INTRUSION_ARROW_WING_SCALE
        trail_start = position - velocity * INTRUSION_ARROW_TRAIL_LENGTH
        pygame.draw.line(
            app.screen,
            COLOR_HOT_ACCENT,
            app._point(trail_start),
            app._point(position),
            app._s(INTRUSION_ARROW_LINE_WIDTH),
        )
        pygame.draw.polygon(
            app.screen,
            COLOR_ERROR,
            (app._point(tip), app._point(left), app._point(right)),
        )

    def draw(self, app: ZeroDayApp) -> None:
        app._draw_minigame_frame(self.title, self.time_left)
        overlay = pygame.Surface(app.screen.get_size(), pygame.SRCALPHA)
        zone_colors = {
            "w": COLOR_ACCENT,
            "a": COLOR_HOT_ACCENT,
            "s": COLOR_ACCENT,
            "d": COLOR_HOT_ACCENT,
        }
        for direction, polygon in self._zone_polygons().items():
            base_color = zone_colors[direction]
            color = (*base_color[:3], INTRUSION_ZONE_FILL_ALPHA)
            screen_polygon = tuple(app._point(point) for point in polygon)
            pygame.draw.polygon(overlay, color, screen_polygon)
            pygame.draw.lines(
                app.screen,
                COLOR_ACCENT,
                True,
                screen_polygon,
                app._s(INTRUSION_ZONE_LINE_WIDTH),
            )
        for y in range(
            MINIGAME_HEADER_HEIGHT,
            DESIGN_HEIGHT,
            INTRUSION_SCANLINE_GAP,
        ):
            start = app._point((0, y))
            end = app._point((DESIGN_WIDTH, y))
            pygame.draw.line(
                overlay,
                (*COLOR_ERROR[:3], INTRUSION_SCANLINE_ALPHA),
                start,
                end,
            )
        app.screen.blit(overlay, (0, 0))
        pygame.draw.rect(
            app.screen,
            COLOR_ERROR,
            app._rect(
                (
                    0,
                    MINIGAME_HEADER_HEIGHT,
                    DESIGN_WIDTH,
                    INTRUSION_ALERT_BAR_HEIGHT,
                )
            ),
        )
        for edge_rect in (
            (
                0,
                MINIGAME_HEADER_HEIGHT,
                INTRUSION_VIGNETTE_WIDTH,
                DESIGN_HEIGHT - MINIGAME_HEADER_HEIGHT,
            ),
            (
                DESIGN_WIDTH - INTRUSION_VIGNETTE_WIDTH,
                MINIGAME_HEADER_HEIGHT,
                INTRUSION_VIGNETTE_WIDTH,
                DESIGN_HEIGHT - MINIGAME_HEADER_HEIGHT,
            ),
        ):
            pygame.draw.rect(app.screen, COLOR_HOT_ACCENT, app._rect(edge_rect))

        pulse_phase = (
            math.sin(self.elapsed * math.tau / INTRUSION_PULSE_PERIOD_SECONDS) + 1.0
        ) / 2.0
        pulse_radius = INTRUSION_HIT_ZONE_OUTER_RADIUS + round(
            pulse_phase * INTRUSION_PULSE_RADIUS_RANGE
        )
        pygame.draw.circle(
            app.screen,
            COLOR_HOT_ACCENT,
            app._point(INTRUSION_CENTER),
            app._s(pulse_radius),
            width=app._s(THIN_LINE_WIDTH),
        )
        for radius in (
            INTRUSION_HIT_ZONE_INNER_RADIUS,
            INTRUSION_HIT_ZONE_OUTER_RADIUS,
        ):
            pygame.draw.circle(
                app.screen,
                COLOR_SUCCESS,
                app._point(INTRUSION_CENTER),
                app._s(radius),
                width=app._s(INTRUSION_HIT_ZONE_WIDTH),
            )

        for direction, position in INTRUSION_ZONE_LABEL_POSITIONS.items():
            app._draw_text(
                direction.upper(),
                position,
                INTRUSION_KEY_FONT_SIZE,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
            app._draw_text(
                f"ZONE {direction.upper()}",
                (position[0], position[1] + INTRUSION_KEY_FONT_SIZE),
                INTRUSION_LABEL_FONT_SIZE,
                COLOR_ACCENT,
                center=True,
                bold=True,
            )

        for arrow in self.arrows:
            self._draw_arrow(app, arrow)

        pygame.draw.circle(
            app.screen,
            COLOR_ERROR,
            app._point(INTRUSION_CENTER),
            app._s(INTRUSION_SERVER_RADIUS),
        )
        pygame.draw.circle(
            app.screen,
            COLOR_TASKBAR,
            app._point(INTRUSION_CENTER),
            app._s(INTRUSION_SERVER_INNER_RADIUS),
        )
        pygame.draw.circle(
            app.screen,
            COLOR_TEXT,
            app._point(INTRUSION_CENTER),
            app._s(INTRUSION_SERVER_RADIUS),
            width=app._s(BORDER_WIDTH),
        )
        app._draw_text(
            "SRV",
            INTRUSION_CENTER,
            INTRUSION_LABEL_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        app._draw_text(
            "ACTIVE INTRUSION — PRESS W / A / S / D IN THE GREEN RING",
            INTRUSION_ALERT_TEXT_CENTER,
            INTRUSION_LABEL_FONT_SIZE,
            COLOR_ERROR,
            center=True,
            bold=True,
        )
        app._draw_text(
            self.feedback,
            INTRUSION_INSTRUCTION_CENTER,
            INTRUSION_LABEL_FONT_SIZE,
            COLOR_SUCCESS
            if self.success_flash_remaining > 0.0
            else COLOR_ERROR
            if self.damage_flash_remaining > 0.0
            else COLOR_TEXT,
            center=True,
            bold=True,
        )
        app._draw_text(
            (
                f"ОТРАЖЕНО {self.hits}  //  ПРОПУЩЕНО "
                f"{self.misses}/{INTRUSION_MAX_MISSES}"
            ),
            INTRUSION_STATUS_CENTER,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_ERROR if self.misses >= INTRUSION_MAX_MISSES - 1 else COLOR_TEXT,
            center=True,
            bold=True,
        )

        if self.damage_flash_remaining > 0.0 or self.wrong_key_flash_remaining > 0.0:
            flash_ratio = max(
                self.damage_flash_remaining / INTRUSION_DAMAGE_FLASH_SECONDS,
                self.wrong_key_flash_remaining / INTRUSION_WRONG_KEY_FLASH_SECONDS,
            )
            flash = pygame.Surface(app.screen.get_size(), pygame.SRCALPHA)
            flash.fill(
                (
                    *COLOR_ERROR[:3],
                    round(INTRUSION_FLASH_ALPHA_MAX * min(1.0, flash_ratio)),
                )
            )
            app.screen.blit(flash, (0, 0))
        if self.finished:
            detail = (
                "SERVER SECURE // атака отражена"
                if self.success
                else (
                    f"ВЗЛОМАН: -{INTRUSION_BTC_LOSS:.2f} BTC, "
                    f"подозрение +{INTRUSION_SUSPICION_PENALTY:.0f}%"
                )
            )
            app._draw_minigame_result(self.success, detail)


class ZeroDayApp:
    """Единое приложение с анимациями, меню, настройками и игровым циклом."""

    def __init__(self) -> None:
        AudioManager.preconfigure_mixer()
        pygame.init()
        pygame.font.init()
        pygame.display.set_caption(APP_TITLE)

        self.running = True
        self.clock = pygame.time.Clock()
        self.current_resolution_key = DEFAULT_RESOLUTION_KEY
        self.pending_resolution_key = DEFAULT_RESOLUTION_KEY
        self.last_windowed_key = DEFAULT_RESOLUTION_KEY
        self.screen = self._create_display(DEFAULT_RESOLUTION_KEY)
        self.window_width, self.window_height = self.screen.get_size()

        self.state = STATE_CRT
        self.state_elapsed = 0.0
        self.total_elapsed = 0.0
        self.transition_remaining = 0.0
        self.guide_section_index = 0
        self.guide_scroll = 0.0
        self.guide_scroll_target = 0.0
        self.status_message = ""
        self.status_color = COLOR_TEXT
        self.status_time_left = 0.0
        self.has_active_session = False
        self.arrested = False
        self.arrest_reason = ""
        self.attempt_number = 1
        self.audio_manager = AudioManager(
            music_volume=MUSIC_DEFAULT_VOLUME,
            sfx_volume=SFX_DEFAULT_VOLUME,
        )
        # Совместимые алиасы для сохранений ранних версий.
        self.sound_enabled = self.audio_manager.effects_enabled
        self.ambient_enabled = self.audio_manager.music_enabled
        self.typing_sfx_cooldown = 0.0
        self.settings_dragging_slider: str | None = None
        self.music_player_dragging_volume = False
        self.save_directory = Path(__file__).resolve().parent
        self.current_save_path = self.save_directory / SAVE_DEFAULT_FILENAME
        self.save_slot_paths: list[Path] = []
        self.save_slot_metadata: dict[Path, dict[str, object]] = {}
        self.selected_save_index = 0
        self.save_scroll_index = 0
        self.total_arrests = 0
        self.desktop_session_elapsed = 0.0
        self.desktop_windows: list[DesktopWindow] = []
        self.dragged_window: DesktopWindow | None = None
        self.drag_offset = pygame.Vector2()
        self.desktop_launcher_open = False
        self.vpn_connected = False
        self.vpn_charges = 0
        self.suspicion = 0.0
        self.btc_balance = DESKTOP_INITIAL_BTC
        self.desktop_notifications: list[dict[str, object]] = []
        self.hacker_attack_time = 0.0
        self.hacker_attack_timer = HACKER_ATTACK_INTERVAL_MAX_SECONDS
        self.hacker_attack_warning_sent = False
        self.hacker_attacks_survived = 0
        self.completed_hacks = 0
        self.completed_orders = 0
        self.game_time_elapsed = 0.0
        self.was_night = self._is_game_night()
        self.tutorial_active = True
        self.tutorial_step = 0
        self.tutorial_completed = False
        self.tutorial_attempts = 0
        self.tutorial_order_id: int | None = None
        self.browser_query = ""
        self.browser_input_focused = False
        self.browser_selected_target: dict[str, object] | None = None
        self.browser_results: list[dict[str, object]] = []
        self.darknet_category = DARKNET_CATEGORIES[0][0]
        self.darknet_page = 0
        self.inventory = {item_id: 0 for item_id in DARKNET_INVENTORY_IDS}
        self.skill_points = 0
        self.skill_points_earned = 0
        self.unlocked_skills: set[str] = set()
        self.story_chapters_issued = 0
        self.story_chapters_completed = 0
        self.story_choices: list[dict[str, object]] = []
        self.story_scores = {"null": 0, "red": 0, "peace": 0, "chaos": 0}
        self.story_finale_reached = False
        self.story_finale_acknowledged = False
        self.story_ending_key = ""
        self.transactions: list[dict[str, object]] = []
        self.miner_targets: list[dict[str, object]] = []
        self.miner_earned_total = 0.0
        self.miner_pending_income = 0.0
        self.difficulty = MINIGAME_DEFAULT_DIFFICULTY
        self.active_minigame: MiniGameBase | None = None
        self.pending_minigame_order: dict[str, object] | None = None
        self.active_hack_context: dict[str, object] | None = None
        self.pending_hack_launch: dict[str, object] | None = None
        self.selected_hack_tools: set[str] = set()
        self.post_hack_mode = "actions"

        self.scale = 1.0
        self.canvas_offset_x = 0
        self.canvas_offset_y = 0
        self.font_cache: dict[tuple[int, bool], pygame.font.Font] = {}
        self.manager: pygame_gui.UIManager
        self.buttons: dict[str, UIButton] = {}

        self.glitch_cycle_index = -1
        self.glitch_offsets: list[tuple[int, int]] = []
        self.random = random.Random(0x0DAD)
        self.order_random = random.Random()
        self.attack_random = random.Random()
        self.event_random = random.Random()
        self._reset_live_events()
        self._initialize_audio()
        self._refresh_save_slots()
        self._reset_messenger()

        self._refresh_geometry()
        self._rebuild_ui()

    # ------------------------------------------------------------------
    # Инициализация окна и UI
    # ------------------------------------------------------------------

    def _create_display(self, resolution_key: str) -> pygame.Surface:
        """Создаёт полноэкранное или оконное отображение для выбранного режима."""
        if resolution_key == FULLSCREEN_KEY:
            desktop_sizes = pygame.display.get_desktop_sizes()
            desktop_size = (
                desktop_sizes[0] if desktop_sizes else (DESIGN_WIDTH, DESIGN_HEIGHT)
            )
            return pygame.display.set_mode(desktop_size, FULLSCREEN_FLAGS)

        size = next(
            option_size
            for key, _label, option_size in RESOLUTION_OPTIONS
            if key == resolution_key and option_size is not None
        )
        return pygame.display.set_mode(size, WINDOW_FLAGS)

    def _refresh_geometry(self) -> None:
        self.window_width, self.window_height = self.screen.get_size()
        self.scale = min(
            self.window_width / DESIGN_WIDTH,
            self.window_height / DESIGN_HEIGHT,
        )
        scaled_width = DESIGN_WIDTH * self.scale
        scaled_height = DESIGN_HEIGHT * self.scale
        self.canvas_offset_x = round((self.window_width - scaled_width) / 2)
        self.canvas_offset_y = round((self.window_height - scaled_height) / 2)
        self.font_cache.clear()

    def _theme_data(self) -> dict[str, object]:
        gui_font_size = max(FONT_SIZE_SMALL, self._s(FONT_SIZE_BUTTON))
        gui_corner_radius = max(BUTTON_CORNER_RADIUS, self._s(BUTTON_CORNER_RADIUS))
        return {
            "defaults": {
                "colours": {
                    "normal_bg": COLOR_PANEL_HEX,
                    "hovered_bg": COLOR_ACCENT_HEX,
                    "disabled_bg": COLOR_BACKGROUND_HEX,
                    "selected_bg": COLOR_ACCENT_HEX,
                    "active_bg": COLOR_HOT_ACCENT_HEX,
                    "dark_bg": COLOR_BACKGROUND_HEX,
                    "normal_text": COLOR_TEXT_HEX,
                    "hovered_text": COLOR_TEXT_HEX,
                    "disabled_text": COLOR_ACCENT_HEX,
                    "selected_text": COLOR_SUCCESS_HEX,
                    "active_text": COLOR_TEXT_HEX,
                    "normal_text_shadow": COLOR_BACKGROUND_HEX,
                    "hovered_text_shadow": COLOR_BACKGROUND_HEX,
                    "disabled_text_shadow": COLOR_BACKGROUND_HEX,
                    "selected_text_shadow": COLOR_BACKGROUND_HEX,
                    "active_text_shadow": COLOR_BACKGROUND_HEX,
                    "normal_border": COLOR_ACCENT_HEX,
                    "hovered_border": COLOR_HOT_ACCENT_HEX,
                    "disabled_border": COLOR_PANEL_HEX,
                    "selected_border": COLOR_SUCCESS_HEX,
                    "active_border": COLOR_HOT_ACCENT_HEX,
                },
                "font": {
                    "name": "noto_sans",
                    "size": str(gui_font_size),
                    "bold": "0",
                },
            },
            "button": {
                "misc": {
                    "shape": "rounded_rectangle",
                    "shape_corner_radius": str(gui_corner_radius),
                    "border_width": str(max(BORDER_WIDTH, self._s(BORDER_WIDTH))),
                    "shadow_width": "0",
                    "text_shadow_size": "0",
                    "text_horiz_alignment": "center",
                    "text_vert_alignment": "center",
                }
            },
            "#exit_button": {
                "colours": {
                    "normal_border": COLOR_HOT_ACCENT_HEX,
                    "hovered_bg": COLOR_HOT_ACCENT_HEX,
                    "hovered_border": COLOR_ERROR_HEX,
                }
            },
            "#apply_button": {
                "colours": {
                    "normal_border": COLOR_SUCCESS_HEX,
                    "hovered_border": COLOR_SUCCESS_HEX,
                    "active_bg": COLOR_SUCCESS_HEX,
                    "active_text": COLOR_BACKGROUND_HEX,
                }
            },
        }

    def _rebuild_ui(self) -> None:
        self.manager = pygame_gui.UIManager(
            (self.window_width, self.window_height),
            theme_path=self._theme_data(),
            enable_live_theme_updates=False,
        )
        self.buttons = {}

        if self.state == STATE_MENU:
            self._build_menu_ui()
        elif self.state == STATE_SETTINGS:
            self._build_settings_ui()
        elif self.state == STATE_GUIDES:
            self._add_button("back", "Назад", GUIDES_BACK_RECT)
        elif self.state == STATE_SAVES:
            actions = (
                ("save_load", "Загрузить"),
                ("save_write", "Сохранить"),
                ("save_new_slot", "Новый слот"),
                ("save_back", "Назад"),
            )
            total_width = SAVE_MANAGER_BUTTON_WIDTH * len(
                actions
            ) + SAVE_MANAGER_BUTTON_GAP * (len(actions) - 1)
            start_x = (DESIGN_WIDTH - total_width) // 2
            for index, (action, label) in enumerate(actions):
                self._add_button(
                    action,
                    label,
                    (
                        start_x
                        + index * (SAVE_MANAGER_BUTTON_WIDTH + SAVE_MANAGER_BUTTON_GAP),
                        SAVE_MANAGER_BUTTON_Y,
                        SAVE_MANAGER_BUTTON_WIDTH,
                        SAVE_MANAGER_BUTTON_HEIGHT,
                    ),
                    object_id="#apply_button" if action == "save_load" else None,
                )
        elif self.state == STATE_ARREST:
            total_width = ARREST_BUTTON_SIZE[0] * 2 + ARREST_BUTTON_GAP
            start_x = (DESIGN_WIDTH - total_width) // 2
            self._add_button(
                "retry_after_arrest",
                "Новая попытка",
                (start_x, ARREST_BUTTON_Y, *ARREST_BUTTON_SIZE),
                object_id="#apply_button",
            )
            self._add_button(
                "arrest_menu",
                "Главное меню",
                (
                    start_x + ARREST_BUTTON_SIZE[0] + ARREST_BUTTON_GAP,
                    ARREST_BUTTON_Y,
                    *ARREST_BUTTON_SIZE,
                ),
                object_id="#exit_button",
            )
        elif self.state == STATE_STORY_FINALE:
            total_width = FINALE_BUTTON_SIZE[0] * 2 + FINALE_BUTTON_GAP
            start_x = (DESIGN_WIDTH - total_width) // 2
            self._add_button(
                "finale_continue",
                "Продолжить игру",
                (start_x, FINALE_BUTTON_Y, *FINALE_BUTTON_SIZE),
                object_id="#apply_button",
            )
            self._add_button(
                "finale_new_game",
                "Новая история",
                (
                    start_x + FINALE_BUTTON_SIZE[0] + FINALE_BUTTON_GAP,
                    FINALE_BUTTON_Y,
                    *FINALE_BUTTON_SIZE,
                ),
            )

    def _add_button(
        self,
        action: str,
        text: str,
        design_rect: tuple[int, int, int, int],
        *,
        object_id: str | None = None,
    ) -> UIButton:
        button = UIButton(
            relative_rect=self._rect(design_rect),
            text=text,
            manager=self.manager,
            object_id=object_id,
        )
        self.buttons[action] = button
        return button

    def _build_menu_ui(self) -> None:
        x = (DESIGN_WIDTH - MENU_BUTTON_WIDTH) // 2
        for index, (action, label) in enumerate(MENU_BUTTONS):
            y = MENU_BUTTON_START_Y + index * (MENU_BUTTON_HEIGHT + MENU_BUTTON_GAP)
            object_id = "#exit_button" if action == "exit" else None
            self._add_button(
                action,
                label,
                (x, y, MENU_BUTTON_WIDTH, MENU_BUTTON_HEIGHT),
                object_id=object_id,
            )

    def _build_settings_ui(self) -> None:
        x = (DESIGN_WIDTH - SETTINGS_CHOICE_WIDTH) // 2
        for index, (key, label, _size) in enumerate(RESOLUTION_OPTIONS):
            y = SETTINGS_CHOICE_START_Y + index * SETTINGS_CHOICE_GAP
            self._add_button(
                f"resolution:{key}",
                label,
                (x, y, SETTINGS_CHOICE_WIDTH, SETTINGS_CHOICE_HEIGHT),
            )

        audio_width = SETTINGS_AUDIO_BUTTON_SIZE[0] * 2 + SETTINGS_AUDIO_BUTTON_GAP
        audio_x = (DESIGN_WIDTH - audio_width) // 2
        self._add_button(
            "toggle_sound",
            f"Эффекты: {'ВКЛ' if self.audio_manager.effects_enabled else 'ВЫКЛ'}",
            (
                audio_x,
                SETTINGS_AUDIO_BUTTON_Y,
                *SETTINGS_AUDIO_BUTTON_SIZE,
            ),
        )
        self._add_button(
            "toggle_ambient",
            f"Музыка: {'ВКЛ' if self.audio_manager.music_enabled else 'ВЫКЛ'}",
            (
                audio_x + SETTINGS_AUDIO_BUTTON_SIZE[0] + SETTINGS_AUDIO_BUTTON_GAP,
                SETTINGS_AUDIO_BUTTON_Y,
                *SETTINGS_AUDIO_BUTTON_SIZE,
            ),
        )

        actions_width = SETTINGS_ACTION_WIDTH * 2 + SETTINGS_ACTION_GAP
        actions_x = (DESIGN_WIDTH - actions_width) // 2
        self._add_button(
            "apply_resolution",
            "Применить",
            (
                actions_x,
                SETTINGS_ACTION_Y,
                SETTINGS_ACTION_WIDTH,
                SETTINGS_ACTION_HEIGHT,
            ),
            object_id="#apply_button",
        )
        self._add_button(
            "back",
            "Назад",
            (
                actions_x + SETTINGS_ACTION_WIDTH + SETTINGS_ACTION_GAP,
                SETTINGS_ACTION_Y,
                SETTINGS_ACTION_WIDTH,
                SETTINGS_ACTION_HEIGHT,
            ),
        )
        self._sync_resolution_selection()

    def _sync_resolution_selection(self) -> None:
        for key, _label, _size in RESOLUTION_OPTIONS:
            button = self.buttons.get(f"resolution:{key}")
            if button is None:
                continue
            if key == self.pending_resolution_key:
                button.select()
            else:
                button.unselect()

    # ------------------------------------------------------------------
    # Генерируемый звук и эмбиент
    # ------------------------------------------------------------------

    def _initialize_audio(self) -> None:
        self.audio_manager.initialize()
        self.sound_enabled = self.audio_manager.effects_enabled
        self.ambient_enabled = self.audio_manager.music_enabled
        if self.audio_manager.available:
            self._sync_music_for_state(immediate=True)

    def _set_music_volume(self, value: float) -> None:
        self.audio_manager.set_music_volume(value)

    def _set_sfx_volume(self, value: float) -> None:
        self.audio_manager.set_sfx_volume(value)

    def _play_sound(self, sound_id: str) -> None:
        try:
            self.audio_manager.play_sfx(sound_id)
        except pygame.error as exc:
            self.audio_manager.available = False
            self.audio_manager.error = f"{type(exc).__name__}: {exc}"

    def _desired_auto_music_track(self) -> str:
        if self.hot_deal.get("active"):
            return "track_attack"
        attack_warning = (
            self.hacker_attack_warning_sent
            and self.hacker_attack_timer <= HACKER_ATTACK_WARNING_SECONDS
        )
        intrusion_active = isinstance(self.active_minigame, IntrusionDefense)
        if intrusion_active or (
            self.state == STATE_DESKTOP
            and (attack_warning or self.hacker_attack_time > 0.0)
        ):
            return "track_attack"
        if self.state in MINIGAME_STATES or self.state in (
            STATE_HACK_PREP,
            STATE_POST_HACK,
        ):
            return "track_hack"
        if self.state == STATE_DESKTOP:
            return "track_desktop"
        return "track_menu"

    def _selected_music_track(self) -> str:
        if self.hot_deal.get("active"):
            return "track_attack"
        return (
            self._desired_auto_music_track()
            if self.audio_manager.music_auto_mode
            else self.audio_manager.manual_music_track
        )

    def _start_music_track(self, track_id: str, *, fade_in: bool = True) -> None:
        try:
            self.audio_manager.start_track(track_id, fade_in=fade_in)
        except pygame.error as exc:
            self.audio_manager.available = False
            self.audio_manager.error = f"{type(exc).__name__}: {exc}"

    def _request_music_track(self, track_id: str, *, immediate: bool = False) -> None:
        try:
            self.audio_manager.request_track(track_id, immediate=immediate)
        except pygame.error as exc:
            self.audio_manager.available = False
            self.audio_manager.error = f"{type(exc).__name__}: {exc}"

    def _sync_music_for_state(self, *, immediate: bool = False) -> None:
        self._request_music_track(self._selected_music_track(), immediate=immediate)

    def _update_audio(self, delta_seconds: float) -> None:
        self.typing_sfx_cooldown = max(
            0.0,
            self.typing_sfx_cooldown - delta_seconds,
        )
        try:
            self.audio_manager.update(delta_seconds, self._selected_music_track())
        except pygame.error as exc:
            self.audio_manager.available = False
            self.audio_manager.error = f"{type(exc).__name__}: {exc}"

    def _toggle_sound(self) -> None:
        self.audio_manager.effects_enabled = not self.audio_manager.effects_enabled
        self.sound_enabled = self.audio_manager.effects_enabled
        if self.audio_manager.effects_enabled:
            self._play_sound("sfx_notify")
        self._rebuild_ui()

    def _toggle_ambient(self) -> None:
        self.audio_manager.music_enabled = not self.audio_manager.music_enabled
        self.ambient_enabled = self.audio_manager.music_enabled
        if self.audio_manager.music_enabled:
            self.audio_manager.music_paused = False
            self._sync_music_for_state()
        else:
            self.audio_manager.pending_music_track = None
            self.audio_manager.music_fade_remaining = 0.0
            if self.audio_manager.music_channel is not None:
                self.audio_manager.music_channel.fadeout(MUSIC_FADE_OUT_MS)
            self.audio_manager.current_music_track = None
            self.audio_manager.music_track_elapsed = 0.0
        self._rebuild_ui()

    def _toggle_music_pause(self) -> None:
        self.audio_manager.toggle_pause(self._selected_music_track())
        self.ambient_enabled = self.audio_manager.music_enabled

    def _select_manual_music_track(self, track_id: str) -> None:
        if track_id not in MUSIC_TRACK_IDS:
            return
        self.audio_manager.music_auto_mode = False
        self.audio_manager.manual_music_track = track_id
        self.audio_manager.music_paused = False
        self._request_music_track(track_id)

    def _step_manual_music_track(self, direction: int) -> None:
        basis = self.audio_manager.manual_music_track
        if (
            self.audio_manager.music_auto_mode
            and self.audio_manager.current_music_track in MUSIC_TRACK_IDS
        ):
            basis = str(self.audio_manager.current_music_track)
        index = MUSIC_TRACK_IDS.index(basis)
        next_track = MUSIC_TRACK_IDS[(index + direction) % len(MUSIC_TRACK_IDS)]
        self._select_manual_music_track(next_track)

    def _toggle_music_auto_mode(self) -> None:
        self.audio_manager.music_auto_mode = not self.audio_manager.music_auto_mode
        self.audio_manager.music_paused = False
        self._request_music_track(self._selected_music_track())

    # ------------------------------------------------------------------
    # Входящие звонки и горячие заказы
    # ------------------------------------------------------------------

    @staticmethod
    def _blank_call_state() -> dict[str, object]:
        return {
            "active": False,
            "timer": 0.0,
            "type": None,
            "answered": False,
            "dialog_step": 0,
            "phase": "idle",
            "caller_name": "",
            "elapsed": 0.0,
            "alarm_timer": 0.0,
            "messages": [],
            "message_elapsed": 0.0,
            "informant_bonus": None,
            "informant_bonus_target": "",
            "trap_errors": 0,
            "trap_result_applied": False,
            "trap_result": "",
            "threat_active": False,
            "threat_timer": 0.0,
        }

    def _reset_live_events(self) -> None:
        if hasattr(self, "audio_manager"):
            self.audio_manager.stop_sfx("sfx_alarm")
            self.audio_manager.set_music_duck(1.0)
        self.call_state = self._blank_call_state()
        self.hot_deal: dict[str, object] = {
            "active": False,
            "order": None,
            "timer": 0.0,
            "reward_multiplier": HOT_DEAL_REWARD_MULTIPLIER,
            "accepted": False,
        }
        self.next_call_time = self.event_random.uniform(
            CALL_INTERVAL_MIN_SECONDS,
            CALL_INTERVAL_MAX_SECONDS,
        )
        self.next_hot_deal_time = float(
            self.event_random.randint(
                HOT_DEAL_INTERVAL_MIN_SECONDS,
                HOT_DEAL_INTERVAL_MAX_SECONDS,
            )
        )
        self.darknet_discount_timer = 0.0
        self.informant_pending_difficulty_bonus = 0

    def _schedule_next_call(self, *, repeat_possible: bool = False) -> None:
        repeat = repeat_possible and self.event_random.random() < CALL_REPEAT_CHANCE
        self.next_call_time = self.event_random.uniform(
            CALL_REPEAT_MIN_SECONDS if repeat else CALL_INTERVAL_MIN_SECONDS,
            CALL_REPEAT_MAX_SECONDS if repeat else CALL_INTERVAL_MAX_SECONDS,
        )

    def _schedule_next_hot_deal(self) -> None:
        self.next_hot_deal_time = float(
            self.event_random.randint(
                HOT_DEAL_INTERVAL_MIN_SECONDS,
                HOT_DEAL_INTERVAL_MAX_SECONDS,
            )
        )

    def _live_events_can_start(self) -> bool:
        return (
            self.has_active_session
            and not self.arrested
            and self.state == STATE_DESKTOP
            and self.active_minigame is None
            and not self.hacker_attack_warning_sent
            and self.hacker_attack_time <= 0.0
        )

    def _start_incoming_call(self) -> bool:
        if (
            not self._live_events_can_start()
            or bool(self.hot_deal.get("active"))
            or bool(self.call_state.get("active"))
            or bool(self.call_state.get("threat_active"))
        ):
            return False
        selected = self.event_random.choices(
            call_types,
            weights=[int(call["weight"]) for call in call_types],
            k=1,
        )[0]
        self.call_state = self._blank_call_state()
        self.call_state.update(
            {
                "active": True,
                "timer": CALL_RING_SECONDS,
                "type": str(selected["type"]),
                "phase": "ringing",
                "caller_name": str(selected["name"]),
                "alarm_timer": CALL_ALARM_REPEAT_SECONDS,
            }
        )
        self.audio_manager.set_music_duck(CALL_MUSIC_DUCK_MULTIPLIER)
        self._play_sound("sfx_alarm")
        self.next_call_time = CALL_INTERVAL_MAX_SECONDS
        self._save_game()
        return True

    def _stop_call_alarm(self) -> None:
        self.audio_manager.stop_sfx("sfx_alarm")
        self.call_state["alarm_timer"] = 0.0

    def _close_incoming_call(
        self,
        *,
        repeat_possible: bool = False,
        save: bool = True,
    ) -> None:
        threat_active = bool(self.call_state.get("threat_active"))
        threat_timer = max(0.0, float(self.call_state.get("threat_timer", 0.0)))
        self._stop_call_alarm()
        self.audio_manager.set_music_duck(1.0)
        self.call_state = self._blank_call_state()
        self.call_state["threat_active"] = threat_active
        self.call_state["threat_timer"] = threat_timer
        self._schedule_next_call(repeat_possible=repeat_possible)
        if save:
            self._save_game()

    def _apply_informant_difficulty_bonus(self) -> str:
        candidates = self._customer_nicks()
        selected = self.messenger_selected_chat
        if selected in candidates:
            candidates.remove(selected)
            candidates.insert(0, selected)
        for customer in candidates:
            order = self.messenger_active_orders.get(customer)
            if order is not None and order.get("status") == "pending":
                order["difficulty_reduction"] = min(
                    1,
                    int(order.get("difficulty_reduction", 0)) + 1,
                )
                return str(order.get("target", customer))
        self.informant_pending_difficulty_bonus = 1
        return "следующий заказ"

    def _answer_incoming_call(self) -> None:
        if self.call_state.get("phase") != "ringing":
            return
        self._stop_call_alarm()
        self.call_state["answered"] = True
        self.call_state["dialog_step"] = 0
        self.call_state["message_elapsed"] = 0.0
        call_type = str(self.call_state.get("type"))
        if call_type == "informant":
            bonus = self.event_random.choice(("discount", "hint"))
            if bonus == "discount":
                self.darknet_discount_timer = max(
                    self.darknet_discount_timer,
                    CALL_INFORMANT_DISCOUNT_SECONDS,
                )
                bonus_message = CALL_INFORMANT_DISCOUNT_MESSAGE
                bonus_target = "DarkNet"
            else:
                bonus_target = self._apply_informant_difficulty_bonus()
                bonus_message = CALL_INFORMANT_HINT_MESSAGE
            self.call_state["informant_bonus"] = bonus
            self.call_state["informant_bonus_target"] = bonus_target
            self.call_state["messages"] = [
                message.format(bonus_message=bonus_message)
                for message in CALL_INFORMANT_BASE_MESSAGES
            ]
            self.call_state["phase"] = "informant"
            self._play_sound("sfx_typing")
        elif call_type == "trap":
            self.call_state["phase"] = "trap"
            self.call_state["trap_errors"] = 0
            self.call_state["trap_result_applied"] = False
        else:
            self.call_state["phase"] = "threat"
            self.call_state["messages"] = [CALL_THREAT_MESSAGE]
            self.call_state["threat_active"] = True
            self.call_state["threat_timer"] = CALL_THREAT_SECONDS
        self._save_game()

    def _answer_trap_round(self, option_index: int) -> None:
        if self.call_state.get("phase") != "trap":
            return
        round_index = int(self.call_state.get("dialog_step", 0))
        if not 0 <= round_index < len(CALL_TRAP_ROUNDS):
            return
        trap_round = CALL_TRAP_ROUNDS[round_index]
        correct = option_index == int(trap_round["correct"])
        if not correct:
            self.call_state["trap_errors"] = int(
                self.call_state.get("trap_errors", 0)
            ) + 1
            self._change_suspicion(
                CALL_TRAP_SUSPICION_PENALTY,
                "Ловушка телефонного мошенника раскрыла личные данные",
            )
            if self.arrested:
                return
        self.call_state["dialog_step"] = round_index + 1
        self._play_sound("sfx_click" if correct else "sfx_fail")
        if round_index + 1 >= len(CALL_TRAP_ROUNDS):
            errors = int(self.call_state.get("trap_errors", 0))
            if errors == 0:
                self._change_reputation(CALL_TRAP_REPUTATION_BONUS)
                result = "Хорошо, вы осторожны. Удачи."
            else:
                result = "Связь прервана."
            self.call_state["trap_result"] = result
            self.call_state["trap_result_applied"] = True
            self.call_state["phase"] = "trap_result"
        self._save_game()

    def _resolve_threat_vpn_success(self) -> bool:
        if not bool(self.call_state.get("threat_active")):
            return False
        self.call_state["threat_active"] = False
        self.call_state["threat_timer"] = 0.0
        self._push_notification(
            "Хах, быстрый. Ладно, в этот раз прощаю.",
            COLOR_SUCCESS,
            sound_id="success",
            force=True,
        )
        self._schedule_next_call()
        self._save_game()
        return True

    def _trigger_threat_intrusion(self) -> None:
        if not bool(self.call_state.get("threat_active")):
            return
        self.call_state["threat_active"] = False
        self.call_state["threat_timer"] = 0.0
        if bool(self.call_state.get("active")):
            self._close_incoming_call(save=False)
        self._push_notification(
            "УГРОЗА ИСПОЛНЕНА — НЕМЕДЛЕННАЯ АТАКА",
            COLOR_ERROR,
            sound_id="alarm",
            force=True,
        )
        if isinstance(self.active_minigame, IntrusionDefense):
            return
        if self.state == STATE_HACK_PREP:
            self._cancel_prepared_hack()
        elif self.state in MINIGAME_STATES:
            self._leave_minigame()
        elif self.state == STATE_POST_HACK:
            self._finish_post_hack(
                "Операция прервана входящей атакой",
                COLOR_ERROR,
            )
        self.pending_hack_launch = None
        self.selected_hack_tools = set()
        self.pending_minigame_order = None
        self.active_hack_context = None
        self.active_minigame = None
        self._start_intrusion_defense()
        self._save_game()

    def _hot_deal_order_for_customer(
        self,
        customer: str,
    ) -> dict[str, object] | None:
        order = self.hot_deal.get("order")
        if (
            bool(self.hot_deal.get("active"))
            and isinstance(order, dict)
            and str(order.get("customer")) == customer
        ):
            return order
        return None

    def _visible_messenger_order(
        self,
        customer: str,
    ) -> dict[str, object] | None:
        return self._hot_deal_order_for_customer(customer) or self.messenger_active_orders.get(
            customer
        )

    def _make_hot_deal_order(self, customer: str) -> dict[str, object]:
        self.messenger_order_sequence += 1
        template = self.order_random.choice(ORDER_TEMPLATES)
        ordinary_reward = round(
            self.order_random.uniform(
                float(template["reward_min"]),
                float(template["reward_max"]),
            )
            * self._reputation_reward_multiplier(),
            3,
        )
        reward = round(ordinary_reward * HOT_DEAL_REWARD_MULTIPLIER, 3)
        return {
            "id": self.messenger_order_sequence,
            "customer": customer,
            "target": str(template["target"]),
            "type": str(template["type"]),
            "category": str(template["category"]),
            "target_type": str(template["target_type"]),
            "description": str(template["description"]),
            "base_reward": ordinary_reward,
            "reward": reward,
            "reward_multiplier": HOT_DEAL_REWARD_MULTIPLIER,
            "deadline_at": time.time() + HOT_DEAL_DURATION_SECONDS,
            "deadline_minutes": 2,
            "is_story": False,
            "is_hot_deal": True,
            "status": "pending",
        }

    @staticmethod
    def _hot_deal_message(order: dict[str, object]) -> str:
        return (
            f"{HOT_DEAL_MESSAGE}\n"
            f"Цель: {order['target']}\n"
            f"Тип: {order['type']}\n"
            f"Задача: {order['description']}\n"
            f"Награда x3: ₿ {float(order['reward']):.3f}"
        )

    def _start_hot_deal(self) -> bool:
        if (
            not self._live_events_can_start()
            or bool(self.call_state.get("active"))
            or bool(self.call_state.get("threat_active"))
            or bool(self.hot_deal.get("active"))
        ):
            return False
        customer = self.event_random.choice(self._customer_nicks())
        order = self._make_hot_deal_order(customer)
        self.hot_deal = {
            "active": True,
            "order": order,
            "timer": HOT_DEAL_DURATION_SECONDS,
            "reward_multiplier": HOT_DEAL_REWARD_MULTIPLIER,
            "accepted": False,
        }
        self.desktop_notifications.clear()
        self._append_messenger_message(
            customer,
            "incoming",
            self._hot_deal_message(order),
            order_id=int(order["id"]),
            is_hot_deal=True,
        )
        self._push_notification(
            f"🔥 ГОРЯЧИЙ ЗАКАЗ ОТ {customer.upper()} — НАГРАДА x3",
            COLOR_GOLD,
            sound_id="alarm",
            force=True,
        )
        self.next_hot_deal_time = HOT_DEAL_INTERVAL_MAX_SECONDS
        self._sync_music_for_state()
        self._save_game()
        return True

    def _process_hot_deal(self, decision: str) -> None:
        order = self.hot_deal.get("order")
        if (
            not bool(self.hot_deal.get("active"))
            or not isinstance(order, dict)
            or order.get("status") != "pending"
        ):
            return
        if decision != "accepted":
            self._expire_hot_deal(
                accepted=False,
                message="Горячий заказ пропущен.",
            )
            return
        order["status"] = "accepted"
        self.hot_deal["accepted"] = True
        customer = str(order["customer"])
        game_to_start = self._minigame_for_order(order)
        target_type = str(order.get("target_type", "Обычный ПК"))
        target_parameters = TARGET_TYPES[target_type]
        difficulty_reduction = int(order.get("difficulty_reduction", 0))
        context = {
            "source": "hot_deal",
            "is_hot_deal": True,
            "customer": customer,
            "reward": float(order["reward"]),
            "order_id": int(order["id"]),
            "target": str(order["target"]),
            "target_type": target_type,
            "difficulty": max(
                MINIGAME_DIFFICULTY_MIN,
                int(target_parameters["difficulty"]) - difficulty_reduction,
            ),
            "game_id": game_to_start,
            "order": order,
        }
        self._append_messenger_message(
            customer,
            "outgoing",
            f"🔥 Беру горячий заказ. Запускаю модуль: {game_to_start}.",
            order_id=int(order["id"]),
            is_hot_deal=True,
        )
        self._prepare_hack(
            game_to_start,
            hack_context=context,
            difficulty_override=int(context["difficulty"]),
        )
        self._save_game()

    def _expire_hot_deal(
        self,
        *,
        accepted: bool | None = None,
        message: str = "⏱ Время вышло. Заказ потерян.",
    ) -> None:
        order = self.hot_deal.get("order")
        if not bool(self.hot_deal.get("active")) or not isinstance(order, dict):
            return
        was_accepted = (
            bool(self.hot_deal.get("accepted")) if accepted is None else accepted
        )
        customer = str(order["customer"])
        order["status"] = "expired" if was_accepted else "ignored"
        if was_accepted:
            self._change_reputation(HOT_DEAL_FAILURE_REPUTATION)
            self.messenger_orders_processed += 1
            self._append_messenger_message(
                customer,
                "incoming",
                message,
                order_id=int(order["id"]),
                is_hot_deal=True,
            )
        else:
            self._change_reputation(HOT_DEAL_IGNORED_REPUTATION)
            self.messenger_messages[customer][:] = [
                item
                for item in self.messenger_messages[customer]
                if not (
                    bool(item.get("is_hot_deal"))
                    and item.get("order_id") == order.get("id")
                )
            ]

        operation_active = bool(
            (self.active_hack_context or {}).get("is_hot_deal")
            or (
                isinstance((self.pending_hack_launch or {}).get("context"), dict)
                and bool(
                    (self.pending_hack_launch or {})["context"].get("is_hot_deal")
                )
            )
        )
        self.hot_deal["active"] = False
        self.hot_deal["timer"] = 0.0
        self.hot_deal["accepted"] = False
        self.hot_deal["order"] = None
        if operation_active:
            self.pending_hack_launch = None
            self.selected_hack_tools = set()
            self.pending_minigame_order = None
            self.active_hack_context = None
            self.active_minigame = None
            self.post_hack_mode = "actions"
            if not self.arrested:
                self._change_state(STATE_DESKTOP)
        self._schedule_next_hot_deal()
        self._sync_music_for_state()
        self._push_notification(
            message,
            COLOR_MUTED,
            sound_id="failure",
            force=True,
        )
        self._save_game()

    def _complete_hot_deal(self) -> str:
        order = self.hot_deal.get("order")
        if not bool(self.hot_deal.get("active")) or not isinstance(order, dict):
            return "Горячий заказ уже закрыт."
        customer = str(order["customer"])
        reward = float(order["reward"])
        order["status"] = "completed"
        self.completed_orders += 1
        self.messenger_orders_processed += 1
        self.skill_points += SKILL_POINTS_PER_COMPLETED_ORDER
        self.skill_points_earned += SKILL_POINTS_PER_COMPLETED_ORDER
        self._change_reputation(HOT_DEAL_COMPLETION_REPUTATION)
        self._change_balance(reward, f"Горячий заказ #{int(order['id']):03d}")
        message = f"🔥 ГОРЯЧИЙ ЗАКАЗ ВЫПОЛНЕН! +{reward:.3f} BTC!"
        self._append_messenger_message(
            customer,
            "incoming",
            message,
            order_id=int(order["id"]),
            is_hot_deal=True,
        )
        self.hot_deal["active"] = False
        self.hot_deal["timer"] = 0.0
        self.hot_deal["accepted"] = False
        self.hot_deal["order"] = None
        self._schedule_next_hot_deal()
        self._unlock_forum_if_needed()
        if not self.story_finale_reached:
            self._issue_due_story_order(customer)
        self._sync_music_for_state()
        return message

    def _update_live_events(self, delta_seconds: float) -> None:
        if not self.has_active_session or self.arrested:
            return
        informant_discount_dialog = (
            bool(self.call_state.get("active"))
            and self.call_state.get("phase") == "informant"
            and self.call_state.get("informant_bonus") == "discount"
        )
        if not informant_discount_dialog:
            self.darknet_discount_timer = max(
                0.0,
                self.darknet_discount_timer - delta_seconds,
            )

        if bool(self.call_state.get("threat_active")):
            self.call_state["threat_timer"] = max(
                0.0,
                float(self.call_state.get("threat_timer", 0.0)) - delta_seconds,
            )
            if float(self.call_state["threat_timer"]) <= 0.0:
                self._trigger_threat_intrusion()
                return

        if bool(self.hot_deal.get("active")):
            self.hot_deal["timer"] = max(
                0.0,
                float(self.hot_deal.get("timer", 0.0)) - delta_seconds,
            )
            if float(self.hot_deal["timer"]) <= 0.0:
                self._expire_hot_deal()
                return
        else:
            self.next_hot_deal_time -= delta_seconds

        if bool(self.call_state.get("active")):
            self.call_state["elapsed"] = float(
                self.call_state.get("elapsed", 0.0)
            ) + delta_seconds
            phase = str(self.call_state.get("phase"))
            if phase == "ringing":
                self.call_state["timer"] = max(
                    0.0,
                    float(self.call_state.get("timer", 0.0)) - delta_seconds,
                )
                self.call_state["alarm_timer"] = float(
                    self.call_state.get("alarm_timer", 0.0)
                ) - delta_seconds
                if float(self.call_state["alarm_timer"]) <= 0.0:
                    self._play_sound("sfx_alarm")
                    self.call_state["alarm_timer"] = CALL_ALARM_REPEAT_SECONDS
                if float(self.call_state["timer"]) <= 0.0:
                    self._close_incoming_call(repeat_possible=True)
                    return
            elif phase == "informant":
                messages = self.call_state.get("messages")
                message_list = messages if isinstance(messages, list) else []
                self.call_state["message_elapsed"] = float(
                    self.call_state.get("message_elapsed", 0.0)
                ) + delta_seconds
                step = int(self.call_state.get("dialog_step", 0))
                while (
                    step + 1 < len(message_list)
                    and float(self.call_state["message_elapsed"])
                    >= CALL_MESSAGE_INTERVAL_SECONDS
                ):
                    self.call_state["message_elapsed"] = float(
                        self.call_state["message_elapsed"]
                    ) - CALL_MESSAGE_INTERVAL_SECONDS
                    step += 1
                    self.call_state["dialog_step"] = step
                    self._play_sound("sfx_typing")
        else:
            self.next_call_time -= delta_seconds

        if not self._live_events_can_start():
            return
        if (
            self.next_call_time <= 0.0
            and not bool(self.hot_deal.get("active"))
            and not bool(self.call_state.get("threat_active"))
        ):
            self._start_incoming_call()
            return
        if (
            self.next_hot_deal_time <= 0.0
            and not bool(self.call_state.get("active"))
            and not bool(self.call_state.get("threat_active"))
        ):
            self._start_hot_deal()

    @staticmethod
    def _call_button_rects() -> dict[str, pygame.Rect]:
        width, height = CALL_BUTTON_SIZE
        total_width = width * 2 + CALL_BUTTON_GAP
        start_x = DESIGN_WIDTH // 2 - total_width // 2
        return {
            "answer": pygame.Rect(start_x, CALL_BUTTON_Y, width, height),
            "decline": pygame.Rect(
                start_x + width + CALL_BUTTON_GAP,
                CALL_BUTTON_Y,
                width,
                height,
            ),
        }

    @staticmethod
    def _call_dialog_button_rect() -> pygame.Rect:
        return pygame.Rect(CALL_DIALOG_BUTTON_RECT)

    @staticmethod
    def _call_trap_option_rect(index: int) -> pygame.Rect:
        dialog = pygame.Rect(CALL_DIALOG_RECT)
        return pygame.Rect(
            dialog.x + CALL_TRAP_OPTION_SIDE_MARGIN,
            CALL_TRAP_OPTION_START_Y
            + index * (CALL_TRAP_OPTION_HEIGHT + CALL_TRAP_OPTION_GAP),
            dialog.width - CALL_TRAP_OPTION_SIDE_MARGIN * 2,
            CALL_TRAP_OPTION_HEIGHT,
        )

    def _informant_dialog_complete(self) -> bool:
        messages = self.call_state.get("messages")
        message_list = messages if isinstance(messages, list) else []
        return bool(message_list) and int(self.call_state.get("dialog_step", 0)) >= (
            len(message_list) - 1
        ) and float(self.call_state.get("message_elapsed", 0.0)) >= min(
            CALL_MESSAGE_INTERVAL_SECONDS,
            len(str(message_list[-1])) / CALL_TYPING_CHARACTERS_PER_SECOND,
        )

    def _handle_incoming_call_event(self, event: pygame.event.Event) -> bool:
        if not bool(self.call_state.get("active")):
            return False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
            return False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            if self.call_state.get("phase") == "ringing":
                self._play_sound("sfx_click")
                self._close_incoming_call(repeat_possible=True)
            return True
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return True
        mouse = self._desktop_point(event.pos)
        phase = str(self.call_state.get("phase"))
        if phase == "ringing":
            buttons = self._call_button_rects()
            if buttons["answer"].collidepoint(mouse):
                self._play_sound("sfx_click")
                self._answer_incoming_call()
            elif buttons["decline"].collidepoint(mouse):
                self._play_sound("sfx_click")
                self._close_incoming_call(repeat_possible=True)
            return True
        if phase == "informant":
            if (
                self._informant_dialog_complete()
                and self._call_dialog_button_rect().collidepoint(mouse)
            ):
                self._play_sound("sfx_notify")
                self._close_incoming_call()
            return True
        if phase == "trap":
            for index in range(3):
                if self._call_trap_option_rect(index).collidepoint(mouse):
                    self._answer_trap_round(index)
                    break
            return True
        if phase == "trap_result":
            if self._call_dialog_button_rect().collidepoint(mouse):
                self._close_incoming_call()
            return True
        if phase == "threat":
            if self._call_dialog_button_rect().collidepoint(mouse):
                self._play_sound("sfx_click")
                self._close_incoming_call()
            return True
        return True

    def _draw_phone_icon(self) -> None:
        center = CALL_PHONE_CENTER
        pygame.draw.circle(
            self.screen,
            COLOR_ACCENT,
            self._point(center),
            self._s(CALL_PHONE_ICON_RADIUS),
        )
        pygame.draw.circle(
            self.screen,
            COLOR_HOT_ACCENT,
            self._point(center),
            self._s(CALL_PHONE_ICON_RADIUS),
            self._s(CALL_PHONE_ICON_STROKE),
        )
        pygame.draw.line(
            self.screen,
            COLOR_TEXT,
            self._point((center[0] - 9, center[1] + 8)),
            self._point((center[0] + 9, center[1] - 8)),
            self._s(CALL_PHONE_ICON_STROKE + 1),
        )
        pygame.draw.line(
            self.screen,
            COLOR_TEXT,
            self._point((center[0] - 14, center[1] + 3)),
            self._point((center[0] - 8, center[1] + 10)),
            self._s(CALL_PHONE_ICON_STROKE + 1),
        )
        pygame.draw.line(
            self.screen,
            COLOR_TEXT,
            self._point((center[0] + 8, center[1] - 10)),
            self._point((center[0] + 14, center[1] - 3)),
            self._s(CALL_PHONE_ICON_STROKE + 1),
        )

    @staticmethod
    def _event_display_text(text: str) -> str:
        return (
            text.replace("🔥", "[HOT]")
            .replace("⏱", "[TIME]")
            .replace("📞", "")
            .replace("❌", "")
            .strip()
        )

    def _draw_flame_icon(
        self,
        center: tuple[float, float],
        size: int = 10,
    ) -> None:
        x, y = center
        outer = (
            (x, y - size),
            (x + size * 0.72, y - size * 0.05),
            (x + size * 0.55, y + size),
            (x, y + size * 0.72),
            (x - size * 0.62, y + size),
            (x - size * 0.76, y),
        )
        inner = (
            (x, y - size * 0.34),
            (x + size * 0.35, y + size * 0.25),
            (x, y + size * 0.68),
            (x - size * 0.30, y + size * 0.20),
        )
        pygame.draw.polygon(
            self.screen,
            COLOR_ERROR,
            [self._point(point) for point in outer],
        )
        pygame.draw.polygon(
            self.screen,
            COLOR_GOLD,
            [self._point(point) for point in inner],
        )

    def _draw_call_button(
        self,
        rect: pygame.Rect,
        label: str,
        color: pygame.Color,
        mouse: tuple[float, float],
    ) -> None:
        pygame.draw.rect(
            self.screen,
            color,
            self._window_rect(rect),
            border_radius=self._s(8),
        )
        if rect.collidepoint(mouse):
            pygame.draw.rect(
                self.screen,
                COLOR_TEXT,
                self._window_rect(rect),
                width=self._s(2),
                border_radius=self._s(8),
            )
        icon_kind = ""
        if label.startswith("📞"):
            icon_kind = "phone"
        elif label.startswith("❌"):
            icon_kind = "reject"
        label_center = (rect.centerx + (8 if icon_kind else 0), rect.centery)
        self._draw_text(
            self._event_display_text(label),
            label_center,
            CALL_BUTTON_FONT_SIZE,
            COLOR_BACKGROUND if color == COLOR_SUCCESS else COLOR_TEXT,
            center=True,
            bold=True,
        )
        if icon_kind == "phone":
            icon_color = COLOR_BACKGROUND
            x, y = rect.x + 31, rect.centery
            pygame.draw.line(
                self.screen,
                icon_color,
                self._point((x - 5, y + 5)),
                self._point((x + 5, y - 5)),
                self._s(3),
            )
            pygame.draw.line(
                self.screen,
                icon_color,
                self._point((x - 8, y + 1)),
                self._point((x - 4, y + 7)),
                self._s(3),
            )
            pygame.draw.line(
                self.screen,
                icon_color,
                self._point((x + 4, y - 7)),
                self._point((x + 8, y - 1)),
                self._s(3),
            )
        elif icon_kind == "reject":
            icon_color = COLOR_TEXT
            x = rect.x + 30
            pygame.draw.line(
                self.screen,
                icon_color,
                self._point((x - 6, rect.centery - 6)),
                self._point((x + 6, rect.centery + 6)),
                self._s(3),
            )
            pygame.draw.line(
                self.screen,
                icon_color,
                self._point((x + 6, rect.centery - 6)),
                self._point((x - 6, rect.centery + 6)),
                self._s(3),
            )

    def _draw_ringing_call(self, mouse: tuple[float, float]) -> None:
        modal = pygame.Rect(CALL_MODAL_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_BACKGROUND,
            self._window_rect(modal),
            border_radius=self._s(CALL_MODAL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ERROR,
            self._window_rect(modal),
            width=self._s(CALL_MODAL_BORDER_WIDTH),
            border_radius=self._s(CALL_MODAL_CORNER_RADIUS),
        )
        self._draw_phone_icon()
        blink = int(float(self.call_state.get("elapsed", 0.0)) * 2.0) % 2 == 0
        self._draw_text(
            "ВХОДЯЩИЙ ВЫЗОВ",
            (DESIGN_WIDTH // 2, CALL_TITLE_Y),
            CALL_TITLE_FONT_SIZE,
            COLOR_ERROR if blink else COLOR_HOT_ACCENT,
            center=True,
            bold=True,
        )
        self._draw_text(
            str(self.call_state.get("caller_name", "Неизвестный номер")),
            (DESIGN_WIDTH // 2, CALL_CALLER_Y),
            CALL_CALLER_FONT_SIZE,
            COLOR_TEXT,
            center=True,
        )
        countdown = max(0, math.ceil(float(self.call_state.get("timer", 0.0))))
        self._draw_text(
            f"{countdown:02d}",
            (DESIGN_WIDTH // 2, CALL_COUNTDOWN_Y),
            CALL_COUNTDOWN_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        buttons = self._call_button_rects()
        self._draw_call_button(
            buttons["answer"],
            CALL_ANSWER_LABEL,
            COLOR_SUCCESS,
            mouse,
        )
        self._draw_call_button(
            buttons["decline"],
            CALL_DECLINE_LABEL,
            COLOR_ERROR,
            mouse,
        )

    def _draw_call_dialog_frame(self, title: str) -> pygame.Rect:
        dialog = pygame.Rect(CALL_DIALOG_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_BACKGROUND,
            self._window_rect(dialog),
            border_radius=self._s(CALL_MODAL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ERROR,
            self._window_rect(dialog),
            width=self._s(CALL_MODAL_BORDER_WIDTH),
            border_radius=self._s(CALL_MODAL_CORNER_RADIUS),
        )
        self._draw_text(
            title,
            (dialog.centerx, CALL_DIALOG_TITLE_Y),
            CALL_TITLE_FONT_SIZE,
            COLOR_HOT_ACCENT,
            center=True,
            bold=True,
        )
        return dialog

    def _draw_informant_dialog(self, mouse: tuple[float, float]) -> None:
        self._draw_call_dialog_frame("ЗАШИФРОВАННЫЙ КАНАЛ // ИНФОРМАТОР")
        messages_value = self.call_state.get("messages")
        messages = messages_value if isinstance(messages_value, list) else []
        current_step = min(
            len(messages) - 1,
            max(0, int(self.call_state.get("dialog_step", 0))),
        )
        y = CALL_DIALOG_TEXT_START_Y
        font = self._font(CALL_DIALOG_FONT_SIZE)
        for index, message_value in enumerate(messages[: current_step + 1]):
            message = str(message_value)
            if index == current_step:
                visible_count = max(
                    1,
                    int(
                        float(self.call_state.get("message_elapsed", 0.0))
                        * CALL_TYPING_CHARACTERS_PER_SECOND
                    ),
                )
                message = message[:visible_count]
            lines = self._wrap_text(
                f"> {message}",
                font,
                self._s(CALL_DIALOG_TEXT_WIDTH),
            )
            for line in lines:
                self._draw_text(
                    line,
                    (CALL_DIALOG_TEXT_X, y),
                    CALL_DIALOG_FONT_SIZE,
                    COLOR_TEXT if index < current_step else COLOR_SUCCESS,
                )
                y += CALL_DIALOG_LINE_GAP
        if self._informant_dialog_complete():
            button = self._call_dialog_button_rect()
            self._draw_call_button(
                button,
                "Спасибо",
                COLOR_SUCCESS,
                mouse,
            )

    def _draw_trap_dialog(self, mouse: tuple[float, float]) -> None:
        phase = str(self.call_state.get("phase"))
        self._draw_call_dialog_frame("ВЫЗОВ // ТЕХПОДДЕРЖКА ПРОВАЙДЕРА")
        self._draw_text(
            "Привет, это техподдержка вашего провайдера.",
            (DESIGN_WIDTH // 2, 198),
            CALL_DIALOG_FONT_SIZE,
            COLOR_TEXT,
            center=True,
        )
        if phase == "trap_result":
            errors = int(self.call_state.get("trap_errors", 0))
            self._draw_text(
                str(self.call_state.get("trap_result", "Связь прервана.")),
                (DESIGN_WIDTH // 2, 305),
                CALL_TITLE_FONT_SIZE,
                COLOR_SUCCESS if errors == 0 else COLOR_ERROR,
                center=True,
                bold=True,
            )
            self._draw_text(
                "+2% репутации" if errors == 0 else f"Ошибок: {errors} • подозрение +{errors * 5}%",
                (DESIGN_WIDTH // 2, 348),
                CALL_DIALOG_SMALL_FONT_SIZE,
                COLOR_SUCCESS if errors == 0 else COLOR_ERROR,
                center=True,
            )
            self._draw_call_button(
                self._call_dialog_button_rect(),
                "Завершить",
                COLOR_ERROR if errors else COLOR_SUCCESS,
                mouse,
            )
            return

        round_index = min(
            len(CALL_TRAP_ROUNDS) - 1,
            max(0, int(self.call_state.get("dialog_step", 0))),
        )
        trap_round = CALL_TRAP_ROUNDS[round_index]
        self._draw_text(
            f"РАУНД {round_index + 1}/3",
            (DESIGN_WIDTH // 2, 235),
            CALL_DIALOG_SMALL_FONT_SIZE,
            COLOR_HOT_ACCENT,
            center=True,
            bold=True,
        )
        question_lines = self._wrap_text(
            str(trap_round["question"]),
            self._font(CALL_DIALOG_FONT_SIZE, True),
            self._s(CALL_DIALOG_TEXT_WIDTH),
        )
        question_y = 273
        for line in question_lines[:2]:
            self._draw_text(
                line,
                (DESIGN_WIDTH // 2, question_y),
                CALL_DIALOG_FONT_SIZE,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
            question_y += 25
        options_value = trap_round["options"]
        options = options_value if isinstance(options_value, tuple) else ()
        for index, option in enumerate(options):
            rect = self._call_trap_option_rect(index)
            self._draw_call_button(
                rect,
                str(option),
                COLOR_ACCENT if not rect.collidepoint(mouse) else COLOR_HOT_ACCENT,
                mouse,
            )

    def _draw_threat_dialog(self, mouse: tuple[float, float]) -> None:
        self._draw_call_dialog_frame("ЗАБЛОКИРОВАННЫЙ НОМЕР // УГРОЗА")
        lines = self._wrap_text(
            CALL_THREAT_MESSAGE,
            self._font(CALL_TITLE_FONT_SIZE, True),
            self._s(CALL_DIALOG_TEXT_WIDTH - 50),
        )
        y = 260
        for line in lines:
            self._draw_text(
                line,
                (DESIGN_WIDTH // 2, y),
                CALL_TITLE_FONT_SIZE,
                COLOR_ERROR,
                center=True,
                bold=True,
            )
            y += 36
        self._draw_text(
            "После закрытия вызова откройте DarkNet → VPN или активируйте заряд VPN.",
            (DESIGN_WIDTH // 2, 392),
            CALL_DIALOG_SMALL_FONT_SIZE,
            COLOR_TEXT,
            center=True,
        )
        self._draw_call_button(
            self._call_dialog_button_rect(),
            "Понял",
            COLOR_ERROR,
            mouse,
        )

    def _draw_incoming_call(self) -> None:
        if not bool(self.call_state.get("active")):
            return
        dim = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 158))
        self.screen.blit(dim, (0, 0))
        mouse = self._desktop_point(pygame.mouse.get_pos())
        phase = str(self.call_state.get("phase"))
        if phase == "ringing":
            self._draw_ringing_call(mouse)
        elif phase == "informant":
            self._draw_informant_dialog(mouse)
        elif phase in ("trap", "trap_result"):
            self._draw_trap_dialog(mouse)
        elif phase == "threat":
            self._draw_threat_dialog(mouse)

    @staticmethod
    def _format_countdown(seconds_left: float) -> str:
        seconds_total = max(0, math.ceil(seconds_left))
        minutes, seconds = divmod(seconds_total, 60)
        return f"{minutes:02d}:{seconds:02d}"

    def _draw_hot_deal_timer(self) -> None:
        if not bool(self.hot_deal.get("active")):
            return
        timer_rect = pygame.Rect(HOT_DEAL_TIMER_RECT)
        pulse = int(self.total_elapsed * 4.0) % 2 == 0
        pygame.draw.rect(
            self.screen,
            COLOR_ERROR if pulse else COLOR_HOT_ACCENT,
            self._window_rect(timer_rect),
            border_radius=self._s(8),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_GOLD,
            self._window_rect(timer_rect),
            width=self._s(2),
            border_radius=self._s(8),
        )
        self._draw_flame_icon((timer_rect.x + 18, timer_rect.y + 14), size=7)
        self._draw_text(
            "HOT DEAL x3",
            (timer_rect.centerx + 7, timer_rect.y + 7),
            HOT_DEAL_TIMER_LABEL_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        self._draw_text(
            self._format_countdown(float(self.hot_deal.get("timer", 0.0))),
            (timer_rect.centerx, timer_rect.y + 25),
            HOT_DEAL_TIMER_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )

    def _draw_threat_timer(self) -> None:
        if not bool(self.call_state.get("threat_active")):
            return
        timer_rect = pygame.Rect(CALL_THREAT_TIMER_RECT)
        blink = int(self.total_elapsed * 2.0) % 2 == 0
        pygame.draw.rect(
            self.screen,
            COLOR_BACKGROUND,
            self._window_rect(timer_rect),
            border_radius=self._s(6),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ERROR if blink else COLOR_HOT_ACCENT,
            self._window_rect(timer_rect),
            width=self._s(3),
            border_radius=self._s(6),
        )
        self._draw_text(
            f"СМЕНИ VPN  {self._format_countdown(float(self.call_state.get('threat_timer', 0.0)))}",
            timer_rect.center,
            CALL_DIALOG_SMALL_FONT_SIZE,
            COLOR_ERROR if blink else COLOR_TEXT,
            center=True,
            bold=True,
        )

    def _draw_live_event_overlays(self) -> None:
        if self.arrested:
            return
        self._draw_hot_deal_timer()
        self._draw_threat_timer()
        self._draw_incoming_call()

    def _apply_call_screen_shake(self) -> None:
        if (
            not bool(self.call_state.get("active"))
            or self.call_state.get("phase") != "ringing"
        ):
            return
        shake = CALL_SHAKE_PIXELS
        phase = int(
            float(self.call_state.get("elapsed", 0.0))
            * CALL_SHAKE_UPDATES_PER_SECOND
            * 2.0
        ) % 2
        offset_x = -shake if phase == 0 else shake
        offset_y = 0
        snapshot = self.screen.copy()
        self.screen.fill(COLOR_BACKGROUND)
        self.screen.blit(
            snapshot,
            (
                round(offset_x * self.scale),
                round(offset_y * self.scale),
            ),
        )

    # ------------------------------------------------------------------
    # Масштабирование и текст
    # ------------------------------------------------------------------

    def _s(self, value: float) -> int:
        return max(1, round(value * self.scale))

    def _point(self, point: tuple[float, float]) -> tuple[int, int]:
        return (
            self.canvas_offset_x + round(point[0] * self.scale),
            self.canvas_offset_y + round(point[1] * self.scale),
        )

    def _rect(self, rect: tuple[int, int, int, int]) -> pygame.Rect:
        x, y = self._point((rect[0], rect[1]))
        return pygame.Rect(x, y, self._s(rect[2]), self._s(rect[3]))

    def _window_rect(self, rect: pygame.Rect) -> pygame.Rect:
        """Переводит прямоугольник из координат рабочего стола в экранные."""
        return self._rect((rect.x, rect.y, rect.width, rect.height))

    def _desktop_point(self, screen_point: tuple[int, int]) -> tuple[float, float]:
        """Переводит координаты мыши в базовый холст 1280×720."""
        return (
            (screen_point[0] - self.canvas_offset_x) / self.scale,
            (screen_point[1] - self.canvas_offset_y) / self.scale,
        )

    def _font(self, design_size: int, bold: bool = False) -> pygame.font.Font:
        pixel_size = max(FONT_SIZE_TINY, self._s(design_size))
        cache_key = (pixel_size, bold)
        if cache_key not in self.font_cache:
            font_path = None
            for family in FONT_CANDIDATES:
                font_path = pygame.font.match_font(family, bold=bold)
                if font_path:
                    break
            self.font_cache[cache_key] = pygame.font.Font(font_path, pixel_size)
            self.font_cache[cache_key].set_bold(bold)
        return self.font_cache[cache_key]

    def _draw_text(
        self,
        text: str,
        position: tuple[float, float],
        design_size: int,
        color: pygame.Color = COLOR_TEXT,
        *,
        center: bool = False,
        center_y: bool = False,
        right: bool = False,
        bold: bool = False,
    ) -> pygame.Rect:
        image = self._font(design_size, bold).render(text, True, color)
        if center:
            rect = image.get_rect(center=self._point(position))
        elif right and center_y:
            rect = image.get_rect(midright=self._point(position))
        elif center_y:
            rect = image.get_rect(midleft=self._point(position))
        elif right:
            rect = image.get_rect(topright=self._point(position))
        else:
            rect = image.get_rect(topleft=self._point(position))
        self.screen.blit(image, rect)
        return rect

    # ------------------------------------------------------------------
    # События и переходы между экранами
    # ------------------------------------------------------------------

    def _change_state(self, new_state: str) -> None:
        if self.arrested and new_state not in (
            STATE_ARREST,
            STATE_MENU,
            STATE_SETTINGS,
            STATE_GUIDES,
            STATE_SAVES,
        ):
            new_state = STATE_ARREST
        self.dragged_window = None
        self.music_player_dragging_volume = False
        self.settings_dragging_slider = None
        self.desktop_launcher_open = False
        self.state = new_state
        self.state_elapsed = 0.0
        self.transition_remaining = SCREEN_TRANSITION_SECONDS
        if new_state == STATE_GUIDES:
            self.guide_scroll = 0.0
            self.guide_scroll_target = 0.0
        elif new_state == STATE_SAVES:
            self._refresh_save_slots()
        self._rebuild_ui()

    def _set_status(self, message: str, color: pygame.Color = COLOR_TEXT) -> None:
        self.status_message = message
        self.status_color = color
        self.status_time_left = STATUS_MESSAGE_SECONDS

    @staticmethod
    def _settings_slider_rect(slider_id: str) -> pygame.Rect:
        rect = (
            SETTINGS_MUSIC_SLIDER_RECT
            if slider_id == "music"
            else SETTINGS_SFX_SLIDER_RECT
        )
        return pygame.Rect(rect)

    def _set_settings_slider_at(self, slider_id: str, mouse_x: float) -> None:
        slider = self._settings_slider_rect(slider_id)
        value = (mouse_x - slider.x) / max(1, slider.width)
        if slider_id == "music":
            self._set_music_volume(value)
        else:
            self._set_sfx_volume(value)

    def _handle_settings_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse = self._desktop_point(event.pos)
            for slider_id in ("music", "effects"):
                hit_rect = self._settings_slider_rect(slider_id).inflate(
                    0,
                    SETTINGS_SLIDER_HIT_PADDING * 2,
                )
                if hit_rect.collidepoint(mouse):
                    self.settings_dragging_slider = slider_id
                    self._set_settings_slider_at(slider_id, mouse[0])
                    return True
        elif event.type == pygame.MOUSEMOTION and self.settings_dragging_slider:
            mouse_x, _mouse_y = self._desktop_point(event.pos)
            self._set_settings_slider_at(self.settings_dragging_slider, mouse_x)
            return True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            was_dragging = self.settings_dragging_slider is not None
            self.settings_dragging_slider = None
            return was_dragging
        return False

    def _handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.QUIT:
            if self.state in MINIGAME_STATES:
                self._leave_minigame()
            elif self.state == STATE_HACK_PREP:
                self._cancel_prepared_hack()
            elif self.state == STATE_POST_HACK:
                self._finish_post_hack("Сессия закрыта без действия", COLOR_ERROR)
            self._save_game()
            self.running = False
            return

        if bool(self.call_state.get("active")) and self._handle_incoming_call_event(
            event
        ):
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._play_sound("click")

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_F11:
                self._toggle_fullscreen()
                return
            if self.state == STATE_SETTINGS and event.key == pygame.K_r:
                self._initialize_audio()
                self._set_status(
                    "Аудио восстановлено"
                    if self.audio_manager.available
                    else f"Аудио недоступно: {self.audio_manager.error}",
                    COLOR_SUCCESS if self.audio_manager.available else COLOR_ERROR,
                )
                return
            if event.key == pygame.K_ESCAPE:
                if self.state == STATE_DESKTOP and self.browser_input_focused:
                    self.browser_input_focused = False
                    self._save_game(notify=True)
                elif self.state in INTRO_STATES:
                    self._change_state(STATE_MENU)
                elif self.state in MINIGAME_STATES:
                    self._leave_minigame()
                    self._save_game(notify=True)
                elif self.state == STATE_HACK_PREP:
                    self._cancel_prepared_hack()
                    self._save_game(notify=True)
                elif self.state == STATE_POST_HACK:
                    if self.post_hack_mode == "blackmail":
                        self.post_hack_mode = "actions"
                    else:
                        self._finish_post_hack(
                            "Доступ закрыт без действия", COLOR_ERROR
                        )
                    self._save_game(notify=True)
                elif self.state == STATE_STORY_FINALE:
                    self.story_finale_acknowledged = True
                    self._save_game(notify=True)
                    self._change_state(STATE_DESKTOP)
                elif self.state in (
                    STATE_ARREST,
                    STATE_SETTINGS,
                    STATE_GUIDES,
                    STATE_SAVES,
                    STATE_DESKTOP,
                ):
                    self.pending_resolution_key = self.current_resolution_key
                    self._save_game(notify=True)
                    self._change_state(STATE_MENU)
                else:
                    self._save_game()
                    self.running = False
                return
            if event.key == pygame.K_SPACE and self.state in INTRO_STATES:
                self._change_state(STATE_MENU)
                return
            if (
                self.state == STATE_DESKTOP
                and self.desktop_launcher_open
                and pygame.K_1 <= event.key <= pygame.K_5
            ):
                self.difficulty = event.key - pygame.K_0
                self._push_notification(
                    f"Сложность мини-игр: {self.difficulty}",
                    COLOR_HOT_ACCENT,
                )
                return

        if self.state in MINIGAME_STATES:
            self._handle_minigame_event(event)
            return
        if self.state == STATE_HACK_PREP:
            self._handle_hack_prep_event(event)
            return
        if self.state == STATE_POST_HACK:
            self._handle_post_hack_event(event)
            return
        if self.state == STATE_SETTINGS and self._handle_settings_event(event):
            return
        if self.state == STATE_DESKTOP and self._handle_desktop_event(event):
            return
        if self.state == STATE_GUIDES and self._handle_guides_event(event):
            return
        if self.state == STATE_SAVES and self._handle_saves_event(event):
            return

        self.manager.process_events(event)
        if event.type == pygame_gui.UI_BUTTON_PRESSED:
            for action, button in tuple(self.buttons.items()):
                if event.ui_element is button:
                    self._handle_action(action)
                    break

    def _handle_minigame_event(self, event: pygame.event.Event) -> None:
        if self.active_minigame is None:
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            point = self._desktop_point(event.pos)
            if pygame.Rect(MINIGAME_BACK_RECT).collidepoint(point):
                self._leave_minigame()
                return
            if self.active_minigame.finished and pygame.Rect(
                MINIGAME_RESULT_OK_RECT
            ).collidepoint(point):
                self._leave_minigame(report_result=True)
                return
        if not self.active_minigame.finished:
            self.active_minigame.handle_event(event, self)

    @staticmethod
    def _hack_prep_tool_rect(index: int) -> pygame.Rect:
        width, height = HACK_PREP_TOOL_SIZE
        start_x, start_y = HACK_PREP_TOOL_START
        return pygame.Rect(
            start_x,
            start_y + index * (height + HACK_PREP_TOOL_GAP),
            width,
            height,
        )

    def _handle_hack_prep_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        mouse = self._desktop_point(event.pos)
        for index, product in enumerate(self._hack_prep_products()):
            if self._hack_prep_tool_rect(index).collidepoint(mouse):
                self._toggle_hack_tool(str(product["id"]))
                return
        if pygame.Rect(HACK_PREP_START_RECT).collidepoint(mouse):
            self._launch_prepared_hack()
        elif pygame.Rect(HACK_PREP_BACK_RECT).collidepoint(mouse):
            self._cancel_prepared_hack()

    def _guide_total_height(self, section_index: int) -> int:
        section = GUIDE_SECTIONS[section_index]
        paragraphs_value = section.get("paragraphs", ())
        paragraphs = paragraphs_value if isinstance(paragraphs_value, tuple) else ()
        body_font = self._font(GUIDES_BODY_FONT_SIZE)
        text_width = self._s(
            GUIDES_CONTENT_RECT[2]
            - GUIDES_CONTENT_PADDING * 2
            - GUIDES_SCROLLBAR_WIDTH
            - 8
        )
        total_height = GUIDES_PAGE_TITLE_HEIGHT
        for paragraph in paragraphs:
            wrapped = self._wrap_text(str(paragraph), body_font, text_width)
            total_height += len(wrapped) * GUIDES_TEXT_LINE_GAP + GUIDES_PARAGRAPH_GAP
        return total_height

    def _guide_max_scroll(self) -> float:
        viewport_height = GUIDES_CONTENT_RECT[3] - GUIDES_CONTENT_PADDING * 2
        return float(
            max(
                0,
                self._guide_total_height(self.guide_section_index) - viewport_height,
            )
        )

    def _select_guide_section(self, section_index: int) -> None:
        self.guide_section_index = min(
            len(GUIDE_SECTIONS) - 1,
            max(0, section_index),
        )
        self.guide_scroll = 0.0
        self.guide_scroll_target = 0.0

    def _handle_guides_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEWHEEL:
            mouse = self._desktop_point(pygame.mouse.get_pos())
            if pygame.Rect(GUIDES_CONTENT_RECT).collidepoint(mouse):
                self.guide_scroll_target = min(
                    self._guide_max_scroll(),
                    max(
                        0.0,
                        self.guide_scroll_target - event.y * GUIDES_SCROLL_STEP,
                    ),
                )
                return True
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_UP, pygame.K_PAGEUP, pygame.K_HOME):
                amount = (
                    self._guide_max_scroll()
                    if event.key == pygame.K_HOME
                    else GUIDES_SCROLL_STEP * (4 if event.key == pygame.K_PAGEUP else 1)
                )
                self.guide_scroll_target = max(
                    0.0,
                    0.0
                    if event.key == pygame.K_HOME
                    else self.guide_scroll_target - amount,
                )
                return True
            if event.key in (pygame.K_DOWN, pygame.K_PAGEDOWN, pygame.K_END):
                maximum = self._guide_max_scroll()
                amount = GUIDES_SCROLL_STEP * (
                    4 if event.key == pygame.K_PAGEDOWN else 1
                )
                self.guide_scroll_target = min(
                    maximum,
                    maximum
                    if event.key == pygame.K_END
                    else self.guide_scroll_target + amount,
                )
                return True
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return False
        mouse = self._desktop_point(event.pos)
        nav = pygame.Rect(GUIDES_NAV_RECT)
        for section_index in range(len(GUIDE_SECTIONS)):
            row = pygame.Rect(
                nav.x,
                nav.y
                + section_index * (GUIDES_SECTION_ROW_HEIGHT + GUIDES_SECTION_ROW_GAP),
                nav.width,
                GUIDES_SECTION_ROW_HEIGHT,
            )
            if row.collidepoint(mouse):
                self._select_guide_section(section_index)
                return True
        return False

    def _ensure_selected_save_visible(self) -> None:
        if self.selected_save_index < self.save_scroll_index:
            self.save_scroll_index = self.selected_save_index
        elif (
            self.selected_save_index
            >= self.save_scroll_index + SAVE_MANAGER_VISIBLE_ROWS
        ):
            self.save_scroll_index = (
                self.selected_save_index - SAVE_MANAGER_VISIBLE_ROWS + 1
            )
        self.save_scroll_index = min(
            max(0, len(self.save_slot_paths) - SAVE_MANAGER_VISIBLE_ROWS),
            max(0, self.save_scroll_index),
        )

    def _handle_saves_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEWHEEL:
            mouse = self._desktop_point(pygame.mouse.get_pos())
            if pygame.Rect(SAVE_MANAGER_LIST_RECT).collidepoint(mouse):
                max_scroll = max(
                    0,
                    len(self.save_slot_paths) - SAVE_MANAGER_VISIBLE_ROWS,
                )
                self.save_scroll_index = min(
                    max_scroll,
                    max(0, self.save_scroll_index - event.y),
                )
                return True
        if event.type == pygame.KEYDOWN and self.save_slot_paths:
            if event.key in (pygame.K_UP, pygame.K_HOME):
                self.selected_save_index = (
                    0
                    if event.key == pygame.K_HOME
                    else max(0, self.selected_save_index - 1)
                )
                self._ensure_selected_save_visible()
                return True
            if event.key in (pygame.K_DOWN, pygame.K_END):
                self.selected_save_index = (
                    len(self.save_slot_paths) - 1
                    if event.key == pygame.K_END
                    else min(
                        len(self.save_slot_paths) - 1,
                        self.selected_save_index + 1,
                    )
                )
                self._ensure_selected_save_visible()
                return True
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self._handle_action("save_load")
                return True
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return False
        mouse = self._desktop_point(event.pos)
        list_rect = pygame.Rect(SAVE_MANAGER_LIST_RECT)
        if not list_rect.collidepoint(mouse):
            return False
        for visible_index in range(SAVE_MANAGER_VISIBLE_ROWS):
            slot_index = self.save_scroll_index + visible_index
            if slot_index >= len(self.save_slot_paths):
                break
            row_y = list_rect.y + visible_index * (
                SAVE_MANAGER_ROW_HEIGHT + SAVE_MANAGER_ROW_GAP
            )
            row = pygame.Rect(
                list_rect.x,
                row_y,
                list_rect.width,
                SAVE_MANAGER_ROW_HEIGHT,
            )
            if row.collidepoint(mouse):
                self.selected_save_index = slot_index
                return True
        return False

    def _handle_action(self, action: str) -> None:
        if action == "new_game":
            self.has_active_session = True
            self.attempt_number = 1
            self.total_arrests = 0
            self.current_save_path = self.save_directory / SAVE_DEFAULT_FILENAME
            self._reset_desktop()
            self._save_game()
            self._change_state(STATE_DESKTOP)
        elif action == "continue":
            if self.has_active_session:
                self._change_state(STATE_ARREST if self.arrested else STATE_DESKTOP)
            else:
                self._refresh_save_slots()
                candidate = (
                    self.current_save_path
                    if self.current_save_path.exists()
                    else max(
                        self.save_slot_paths,
                        key=lambda path: path.stat().st_mtime,
                        default=None,
                    )
                )
                if candidate is None:
                    self._set_status("Сохранение не найдено", COLOR_ERROR)
                elif not bool(self.save_slot_metadata.get(candidate, {}).get("valid")):
                    self._set_status("Сохранение повреждено", COLOR_ERROR)
                    self._play_sound("failure")
                else:
                    self._load_game(candidate)
        elif action == "saves":
            self._refresh_save_slots()
            self._change_state(STATE_SAVES)
        elif action == "save_load":
            if self.save_slot_paths:
                path = self.save_slot_paths[self.selected_save_index]
                if bool(self.save_slot_metadata.get(path, {}).get("valid")):
                    self._load_game(path)
                else:
                    self._set_status("Выбранный слот повреждён", COLOR_ERROR)
                    self._play_sound("failure")
            else:
                self._set_status("Нет доступных слотов", COLOR_ERROR)
        elif action == "save_write":
            path = (
                self.save_slot_paths[self.selected_save_index]
                if self.save_slot_paths
                else self.current_save_path
            )
            self._save_game(path, notify=True)
        elif action == "save_new_slot":
            self._refresh_save_slots()
            self.current_save_path = self._next_save_path()
            self.has_active_session = True
            self.attempt_number = 1
            self.total_arrests = 0
            self._reset_desktop()
            self._save_game(notify=True)
            self._change_state(STATE_DESKTOP)
        elif action == "save_back":
            self._change_state(STATE_MENU)
        elif action == "retry_after_arrest":
            self.attempt_number += 1
            self.has_active_session = True
            self._reset_desktop()
            self._save_game()
            self._change_state(STATE_DESKTOP)
        elif action == "arrest_menu":
            self._change_state(STATE_MENU)
        elif action == "finale_continue":
            self.story_finale_acknowledged = True
            self._save_game()
            self._change_state(STATE_DESKTOP)
        elif action == "finale_new_game":
            self.attempt_number = 1
            self.total_arrests = 0
            self.has_active_session = True
            self._reset_desktop()
            self._save_game()
            self._change_state(STATE_DESKTOP)
        elif action == "toggle_sound":
            self._toggle_sound()
        elif action == "toggle_ambient":
            self._toggle_ambient()
        elif action == "settings":
            self.pending_resolution_key = self.current_resolution_key
            self._change_state(STATE_SETTINGS)
        elif action == "guides":
            self._change_state(STATE_GUIDES)
        elif action == "exit":
            self.running = False
        elif action == "back":
            self.pending_resolution_key = self.current_resolution_key
            self._change_state(STATE_MENU)
        elif action == "apply_resolution":
            self._apply_resolution(self.pending_resolution_key)
        elif action.startswith("resolution:"):
            self.pending_resolution_key = action.split(":", maxsplit=1)[1]
            self._sync_resolution_selection()

    # ------------------------------------------------------------------
    # Рабочий стол, мессенджер и система окон
    # ------------------------------------------------------------------

    @staticmethod
    def _customer_nicks() -> list[str]:
        return [customer["nick"] for customer in MESSENGER_CUSTOMERS]

    def _game_hour_value(self) -> float:
        return (GAME_START_HOUR + self.game_time_elapsed / GAME_SECONDS_PER_HOUR) % 24

    def _is_game_night(self) -> bool:
        hour = self._game_hour_value()
        return hour >= GAME_NIGHT_START_HOUR or hour < GAME_NIGHT_END_HOUR

    def _format_game_time(self) -> str:
        hour_value = self._game_hour_value()
        hours = int(hour_value) % 24
        minutes = int((hour_value - int(hour_value)) * 60) % 60
        return f"{hours:02d}:{minutes:02d}"

    def _advance_game_clock(self, delta_seconds: float) -> None:
        self.game_time_elapsed += max(0.0, delta_seconds)
        is_night = self._is_game_night()
        if is_night == self.was_night:
            return
        self.was_night = is_night
        if is_night:
            self.hacker_attack_timer = max(
                HACKER_ATTACK_INTERVAL_FLOOR_SECONDS,
                self.hacker_attack_timer / GAME_NIGHT_ATTACK_FREQUENCY_MULTIPLIER,
            )
            self._push_notification(
                "NIGHT MODE: цели проще, атаки чаще",
                COLOR_HOT_ACCENT,
                sound_id="alarm",
            )
        else:
            self.hacker_attack_timer = min(
                HACKER_ATTACK_INTERVAL_MAX_SECONDS,
                self.hacker_attack_timer * GAME_NIGHT_ATTACK_FREQUENCY_MULTIPLIER,
            )
            self._push_notification(
                "DAY MODE: интенсивность атак снижена",
                COLOR_SUCCESS,
            )

    @staticmethod
    def _save_slot_number(path: Path) -> int:
        if path.name == SAVE_DEFAULT_FILENAME:
            return 0
        suffix = path.stem.removeprefix(SAVE_SLOT_PREFIX)
        return int(suffix) if suffix.isdigit() else sys.maxsize

    def _refresh_save_slots(self) -> None:
        candidates = [
            path
            for path in self.save_directory.glob(
                f"{SAVE_SLOT_PREFIX}*{SAVE_SLOT_SUFFIX}"
            )
            if path.name == SAVE_DEFAULT_FILENAME
            or (
                path.stem.startswith(SAVE_SLOT_PREFIX)
                and path.stem[len(SAVE_SLOT_PREFIX) :].isdigit()
            )
        ]
        self.save_slot_paths = sorted(candidates, key=self._save_slot_number)
        self.save_slot_metadata = {}
        for path in self.save_slot_paths:
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(payload, dict):
                    raise TypeError
                self.save_slot_metadata[path] = {
                    "saved_at": str(payload.get("saved_at", "—")),
                    "balance": float(payload.get("balance", 0.0)),
                    "reputation": int(payload.get("reputation", 0)),
                    "completed_orders": int(payload.get("completed_orders", 0)),
                    "valid": True,
                }
            except (OSError, json.JSONDecodeError, TypeError, ValueError):
                self.save_slot_metadata[path] = {"valid": False}
        if self.current_save_path in self.save_slot_paths:
            self.selected_save_index = self.save_slot_paths.index(
                self.current_save_path
            )
        elif self.save_slot_paths:
            self.selected_save_index = min(
                self.selected_save_index,
                len(self.save_slot_paths) - 1,
            )
        else:
            self.selected_save_index = 0
        max_scroll = max(0, len(self.save_slot_paths) - SAVE_MANAGER_VISIBLE_ROWS)
        self.save_scroll_index = min(self.save_scroll_index, max_scroll)

    def _next_save_path(self) -> Path:
        used_numbers = {self._save_slot_number(path) for path in self.save_slot_paths}
        slot_number = 1
        while slot_number in used_numbers:
            slot_number += 1
        return (
            self.save_directory / f"{SAVE_SLOT_PREFIX}{slot_number}{SAVE_SLOT_SUFFIX}"
        )

    def _save_payload(self) -> dict[str, object]:
        return {
            "version": SAVE_VERSION,
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "balance": self.btc_balance,
            "btc_balance": self.btc_balance,
            "reputation": self.messenger_reputation,
            "suspicion": self.suspicion,
            "skills": sorted(self.unlocked_skills),
            "unlocked_skills": sorted(self.unlocked_skills),
            "skill_points": self.skill_points,
            "skill_points_earned": self.skill_points_earned,
            "completed_orders": self.completed_orders,
            "processed_orders": self.messenger_orders_processed,
            "completed_hacks": self.completed_hacks,
            "miners": self.miner_targets,
            "miner_earned_total": self.miner_earned_total,
            "miner_pending_income": self.miner_pending_income,
            "vpn": self.vpn_charges,
            "vpn_charges": self.vpn_charges,
            "inventory": self.inventory,
            "transactions": self.transactions,
            "difficulty": self.difficulty,
            "game_time_elapsed": self.game_time_elapsed,
            "hacker_attack_timer": self.hacker_attack_timer,
            "hacker_attacks_survived": self.hacker_attacks_survived,
            "live_events": {
                "next_call_time": self.next_call_time,
                "call_state": self.call_state,
                "next_hot_deal_time": self.next_hot_deal_time,
                "hot_deal": self.hot_deal,
                "darknet_discount_timer": self.darknet_discount_timer,
                "informant_pending_difficulty_bonus": (
                    self.informant_pending_difficulty_bonus
                ),
            },
            "attempt_number": self.attempt_number,
            "total_arrests": self.total_arrests,
            "arrested": self.arrested,
            "arrest_reason": self.arrest_reason,
            # Старые ключи оставлены для обратной совместимости.
            "sound_enabled": self.audio_manager.effects_enabled,
            "ambient_enabled": self.audio_manager.music_enabled,
            "effects_enabled": self.audio_manager.effects_enabled,
            "music_enabled": self.audio_manager.music_enabled,
            "music_volume": self.audio_manager.music_volume,
            "sfx_volume": self.audio_manager.sfx_volume,
            "music_auto_mode": self.audio_manager.music_auto_mode,
            "manual_music_track": self.audio_manager.manual_music_track,
            "active_operation": (
                {
                    "state": STATE_POST_HACK,
                    "context": self.active_hack_context,
                    "mode": self.post_hack_mode,
                }
                if self.state == STATE_POST_HACK
                and self.active_hack_context is not None
                else None
            ),
            "tutorial": {
                "active": self.tutorial_active,
                "step": self.tutorial_step,
                "completed": self.tutorial_completed,
                "attempts": self.tutorial_attempts,
                "order_id": self.tutorial_order_id,
            },
            "story": {
                "chapters_issued": self.story_chapters_issued,
                "chapters_completed": self.story_chapters_completed,
                "choices": self.story_choices,
                "scores": self.story_scores,
                "finale_reached": self.story_finale_reached,
                "finale_acknowledged": self.story_finale_acknowledged,
                "ending_key": self.story_ending_key,
            },
            "messenger": {
                "selected_chat": self.messenger_selected_chat,
                "order_sequence": self.messenger_order_sequence,
                "refusals": self.messenger_refusals,
                "active_orders": self.messenger_active_orders,
                "messages": self.messenger_messages,
                "forum_unlocked": self.messenger_forum_unlocked,
                "forum_orders": self.messenger_forum_orders,
            },
        }

    def _save_game(
        self,
        path: Path | None = None,
        *,
        notify: bool = False,
    ) -> bool:
        if not self.has_active_session:
            if notify:
                self._set_status("Нет активной сессии для сохранения", COLOR_ERROR)
            return False
        destination = path or self.current_save_path
        temporary = destination.with_suffix(f"{destination.suffix}.tmp")
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary.write_text(
                json.dumps(self._save_payload(), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            temporary.replace(destination)
        except (OSError, TypeError, ValueError) as exc:
            if temporary.exists():
                try:
                    temporary.unlink()
                except OSError:
                    pass
            if notify:
                error_message = f"Ошибка сохранения: {exc}"
                self._set_status(error_message, COLOR_ERROR)
                if self.state == STATE_DESKTOP:
                    self._push_notification(
                        error_message,
                        COLOR_ERROR,
                        sound_id="failure",
                    )
                else:
                    self._play_sound("failure")
            return False
        self.current_save_path = destination
        self._refresh_save_slots()
        if notify:
            message = f"Сохранено: {destination.name}"
            self._set_status(message, COLOR_SUCCESS)
            if self.state == STATE_DESKTOP:
                self._push_notification(message, COLOR_SUCCESS, sound_id="success")
            else:
                self._play_sound("success")
        return True

    @staticmethod
    def _safe_dict_list(value: object) -> list[dict[str, object]]:
        if not isinstance(value, list):
            return []
        return [dict(item) for item in value if isinstance(item, dict)]

    def _load_live_event_state(self, payload: dict[str, object]) -> None:
        live_value = payload.get("live_events")
        if not isinstance(live_value, dict):
            return
        self.next_call_time = max(
            0.0,
            float(live_value.get("next_call_time", self.next_call_time)),
        )
        self.next_hot_deal_time = max(
            0.0,
            float(live_value.get("next_hot_deal_time", self.next_hot_deal_time)),
        )
        self.darknet_discount_timer = max(
            0.0,
            float(
                live_value.get(
                    "darknet_discount_timer",
                    self.darknet_discount_timer,
                )
            ),
        )
        self.informant_pending_difficulty_bonus = min(
            1,
            max(
                0,
                int(
                    live_value.get(
                        "informant_pending_difficulty_bonus",
                        self.informant_pending_difficulty_bonus,
                    )
                ),
            ),
        )

        loaded_call = live_value.get("call_state")
        if isinstance(loaded_call, dict):
            restored_call = self._blank_call_state()
            valid_types = {str(item["type"]) for item in call_types}
            call_type_value = loaded_call.get("type")
            call_type = (
                str(call_type_value)
                if call_type_value is not None
                and str(call_type_value) in valid_types
                else None
            )
            valid_phases = {
                "idle",
                "ringing",
                "informant",
                "trap",
                "trap_result",
                "threat",
            }
            phase = str(loaded_call.get("phase", "idle"))
            if phase not in valid_phases:
                phase = "idle"
            messages_value = loaded_call.get("messages")
            messages = (
                [str(message) for message in messages_value[:5]]
                if isinstance(messages_value, list)
                else []
            )
            restored_call.update(
                {
                    "active": bool(loaded_call.get("active"))
                    and call_type is not None
                    and phase != "idle",
                    "timer": max(0.0, float(loaded_call.get("timer", 0.0))),
                    "type": call_type,
                    "answered": bool(loaded_call.get("answered")),
                    "dialog_step": max(
                        0,
                        int(loaded_call.get("dialog_step", 0)),
                    ),
                    "phase": phase,
                    "caller_name": str(loaded_call.get("caller_name", "")),
                    "elapsed": max(0.0, float(loaded_call.get("elapsed", 0.0))),
                    "alarm_timer": max(
                        0.0,
                        float(loaded_call.get("alarm_timer", 0.0)),
                    ),
                    "messages": messages,
                    "message_elapsed": max(
                        0.0,
                        float(loaded_call.get("message_elapsed", 0.0)),
                    ),
                    "informant_bonus": loaded_call.get("informant_bonus"),
                    "informant_bonus_target": str(
                        loaded_call.get("informant_bonus_target", "")
                    ),
                    "trap_errors": min(
                        len(CALL_TRAP_ROUNDS),
                        max(0, int(loaded_call.get("trap_errors", 0))),
                    ),
                    "trap_result_applied": bool(
                        loaded_call.get("trap_result_applied")
                    ),
                    "trap_result": str(loaded_call.get("trap_result", "")),
                    "threat_active": bool(loaded_call.get("threat_active")),
                    "threat_timer": max(
                        0.0,
                        float(loaded_call.get("threat_timer", 0.0)),
                    ),
                }
            )
            self.call_state = restored_call

        loaded_hot = live_value.get("hot_deal")
        if isinstance(loaded_hot, dict):
            order_value = loaded_hot.get("order")
            order = dict(order_value) if isinstance(order_value, dict) else None
            customer = str(order.get("customer", "")) if order is not None else ""
            valid_order = order is not None and customer in self._customer_nicks()
            self.hot_deal = {
                "active": bool(loaded_hot.get("active"))
                and valid_order
                and not bool(self.call_state.get("active"))
                and not bool(self.call_state.get("threat_active")),
                "order": order if valid_order else None,
                "timer": max(0.0, float(loaded_hot.get("timer", 0.0))),
                "reward_multiplier": HOT_DEAL_REWARD_MULTIPLIER,
                "accepted": bool(loaded_hot.get("accepted")),
            }

        if bool(self.call_state.get("active")):
            self.audio_manager.set_music_duck(CALL_MUSIC_DUCK_MULTIPLIER)
            if self.call_state.get("phase") == "ringing":
                self._play_sound("sfx_alarm")
        else:
            self.audio_manager.set_music_duck(1.0)

    def _load_game(self, path: Path, *, notify: bool = True) -> bool:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise TypeError("корневой объект сохранения повреждён")
            self._reset_desktop()
            self.current_save_path = path
            self.btc_balance = float(
                payload.get(
                    "balance",
                    payload.get("btc_balance", DESKTOP_INITIAL_BTC),
                )
            )
            self.messenger_reputation = min(
                REPUTATION_MAX,
                max(REPUTATION_MIN, int(payload.get("reputation", 0))),
            )
            self.suspicion = min(
                SUSPICION_MAX,
                max(SUSPICION_MIN, float(payload.get("suspicion", 0.0))),
            )
            valid_skills = {str(node["id"]) for node in self._skill_nodes()}
            skills_value = payload.get(
                "skills",
                payload.get("unlocked_skills", []),
            )
            self.unlocked_skills = (
                {str(skill) for skill in skills_value if str(skill) in valid_skills}
                if isinstance(skills_value, list)
                else set()
            )
            self.skill_points = max(0, int(payload.get("skill_points", 0)))
            self.skill_points_earned = max(
                self.skill_points,
                int(payload.get("skill_points_earned", self.skill_points)),
            )
            self.completed_orders = max(0, int(payload.get("completed_orders", 0)))
            self.messenger_orders_processed = max(
                self.completed_orders,
                int(payload.get("processed_orders", self.completed_orders)),
            )
            self.completed_hacks = max(0, int(payload.get("completed_hacks", 0)))
            self.miner_targets = self._safe_dict_list(payload.get("miners"))
            self.miner_earned_total = max(
                0.0,
                float(payload.get("miner_earned_total", 0.0)),
            )
            self.miner_pending_income = max(
                0.0,
                float(payload.get("miner_pending_income", 0.0)),
            )
            self._set_vpn_charges(
                int(payload.get("vpn", payload.get("vpn_charges", 0)))
            )
            inventory_value = payload.get("inventory")
            if isinstance(inventory_value, dict):
                self.inventory = {
                    item_id: max(0, int(inventory_value.get(item_id, 0)))
                    for item_id in DARKNET_INVENTORY_IDS
                }
            self.transactions = self._safe_dict_list(payload.get("transactions"))[
                -TRANSACTION_HISTORY_LIMIT:
            ]
            self.difficulty = min(
                MINIGAME_DIFFICULTY_MAX,
                max(
                    MINIGAME_DIFFICULTY_MIN,
                    int(payload.get("difficulty", MINIGAME_DEFAULT_DIFFICULTY)),
                ),
            )
            self.game_time_elapsed = max(
                0.0,
                float(payload.get("game_time_elapsed", 0.0)),
            )
            self.was_night = self._is_game_night()
            self.hacker_attack_timer = max(
                0.0,
                float(
                    payload.get(
                        "hacker_attack_timer",
                        HACKER_ATTACK_INTERVAL_MAX_SECONDS,
                    )
                ),
            )
            self.hacker_attacks_survived = max(
                0,
                int(payload.get("hacker_attacks_survived", 0)),
            )
            self.attempt_number = max(1, int(payload.get("attempt_number", 1)))
            self.total_arrests = max(0, int(payload.get("total_arrests", 0)))

            story_value = payload.get("story")
            if isinstance(story_value, dict):
                self.story_chapters_issued = min(
                    len(STORY_CHAPTERS),
                    max(0, int(story_value.get("chapters_issued", 0))),
                )
                self.story_chapters_completed = min(
                    self.story_chapters_issued,
                    max(0, int(story_value.get("chapters_completed", 0))),
                )
                self.story_choices = self._safe_dict_list(story_value.get("choices"))
                scores_value = story_value.get("scores")
                if isinstance(scores_value, dict):
                    self.story_scores = {
                        key: int(scores_value.get(key, 0))
                        for key in ("null", "red", "peace", "chaos")
                    }
                self.story_finale_reached = bool(
                    story_value.get("finale_reached", False)
                )
                self.story_finale_acknowledged = bool(
                    story_value.get("finale_acknowledged", False)
                )
                ending_key = str(story_value.get("ending_key", ""))
                self.story_ending_key = (
                    ending_key if ending_key in STORY_ENDINGS else ""
                )

            tutorial_value = payload.get("tutorial")
            if isinstance(tutorial_value, dict):
                self.tutorial_completed = bool(
                    tutorial_value.get("completed", self.completed_orders > 0)
                )
                self.tutorial_active = (
                    bool(tutorial_value.get("active", not self.tutorial_completed))
                    and not self.tutorial_completed
                )
                self.tutorial_step = min(
                    max(TUTORIAL_MESSAGES),
                    max(0, int(tutorial_value.get("step", 0))),
                )
                self.tutorial_attempts = max(
                    0,
                    int(tutorial_value.get("attempts", 0)),
                )
                order_id = tutorial_value.get("order_id")
                self.tutorial_order_id = (
                    int(order_id) if isinstance(order_id, (int, float)) else None
                )
            else:
                self.tutorial_completed = self.completed_orders > 0
                self.tutorial_active = not self.tutorial_completed

            messenger_value = payload.get("messenger")
            if isinstance(messenger_value, dict):
                selected_chat = str(
                    messenger_value.get("selected_chat", TUTORIAL_CUSTOMER)
                )
                valid_chats = {*self._customer_nicks(), MESSENGER_FORUM_ID}
                self.messenger_selected_chat = (
                    selected_chat if selected_chat in valid_chats else TUTORIAL_CUSTOMER
                )
                self.messenger_order_sequence = max(
                    0,
                    int(messenger_value.get("order_sequence", 0)),
                )
                refusals_value = messenger_value.get("refusals")
                if isinstance(refusals_value, dict):
                    self.messenger_refusals = {
                        nick: max(0, int(refusals_value.get(nick, 0)))
                        for nick in self._customer_nicks()
                    }
                orders_value = messenger_value.get("active_orders")
                if isinstance(orders_value, dict):
                    self.messenger_active_orders = {
                        nick: dict(order)
                        if isinstance((order := orders_value.get(nick)), dict)
                        else None
                        for nick in self._customer_nicks()
                    }
                messages_value = messenger_value.get("messages")
                if isinstance(messages_value, dict):
                    self.messenger_messages = {
                        nick: self._safe_dict_list(messages_value.get(nick))[
                            -MESSENGER_HISTORY_LIMIT:
                        ]
                        for nick in self._customer_nicks()
                    }
                self.messenger_forum_unlocked = bool(
                    messenger_value.get("forum_unlocked", False)
                )
                self.messenger_forum_orders = self._safe_dict_list(
                    messenger_value.get("forum_orders")
                )

            self.audio_manager.effects_enabled = bool(
                payload.get(
                    "effects_enabled",
                    payload.get("sound_enabled", self.audio_manager.effects_enabled),
                )
            )
            self.audio_manager.music_enabled = bool(
                payload.get(
                    "music_enabled",
                    payload.get("ambient_enabled", self.audio_manager.music_enabled),
                )
            )
            self.sound_enabled = self.audio_manager.effects_enabled
            self.ambient_enabled = self.audio_manager.music_enabled
            self._set_music_volume(
                float(payload.get("music_volume", self.audio_manager.music_volume))
            )
            self._set_sfx_volume(float(payload.get("sfx_volume", self.audio_manager.sfx_volume)))
            self.audio_manager.music_auto_mode = bool(
                payload.get("music_auto_mode", self.audio_manager.music_auto_mode)
            )
            manual_track = str(
                payload.get("manual_music_track", self.audio_manager.manual_music_track)
            )
            self.audio_manager.manual_music_track = (
                manual_track if manual_track in MUSIC_TRACK_IDS else "track_menu"
            )
            self.audio_manager.music_paused = False
            self.audio_manager.pending_music_track = None
            self.audio_manager.music_fade_remaining = 0.0
            if not self.audio_manager.music_enabled:
                if self.audio_manager.music_channel is not None:
                    self.audio_manager.music_channel.fadeout(MUSIC_FADE_OUT_MS)
                self.audio_manager.current_music_track = None
                self.audio_manager.music_track_elapsed = 0.0
            self.arrested = bool(payload.get("arrested", False)) or (
                self.suspicion >= SUSPICION_MAX
            )
            self.arrest_reason = str(payload.get("arrest_reason", ""))
            self.has_active_session = True
            self._load_live_event_state(payload)
            if self.arrested:
                self._reset_live_events()
            self.active_minigame = None
            self.pending_minigame_order = None
            self.pending_hack_launch = None
            self.selected_hack_tools = set()
            operation_value = payload.get("active_operation")
            operation = operation_value if isinstance(operation_value, dict) else None
            operation_context = (
                operation.get("context") if operation is not None else None
            )
            if (
                operation is not None
                and operation.get("state") == STATE_POST_HACK
                and isinstance(operation_context, dict)
                and not self.arrested
            ):
                self.active_hack_context = dict(operation_context)
                if bool(self.active_hack_context.get("order_pending")):
                    operation_customer = str(
                        self.active_hack_context.get("customer", "")
                    )
                    operation_order_id = int(
                        self.active_hack_context.get("order_id", -1)
                    )
                    active_order = self.messenger_active_orders.get(operation_customer)
                    if (
                        active_order is not None
                        and int(active_order.get("id", -2)) == operation_order_id
                    ):
                        self.active_hack_context["order"] = active_order
                if bool(self.active_hack_context.get("is_hot_deal")):
                    hot_order = self.hot_deal.get("order")
                    if (
                        bool(self.hot_deal.get("active"))
                        and isinstance(hot_order, dict)
                        and int(hot_order.get("id", -2))
                        == int(self.active_hack_context.get("order_id", -1))
                    ):
                        self.active_hack_context["order"] = hot_order
                operation_mode = str(operation.get("mode", "actions"))
                self.post_hack_mode = (
                    operation_mode
                    if operation_mode in ("actions", "blackmail")
                    else "actions"
                )
                target_state = STATE_POST_HACK
            else:
                self.active_hack_context = None
                self.post_hack_mode = "actions"
                target_state = STATE_ARREST if self.arrested else STATE_DESKTOP
            self._update_browser_results()
            self._refresh_save_slots()
            self._change_state(target_state)
            if self.audio_manager.music_enabled:
                self._sync_music_for_state()
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            if notify:
                self._set_status(f"Ошибка загрузки: {exc}", COLOR_ERROR)
                self._play_sound("failure")
            return False
        if notify:
            self._push_notification(
                f"Загружено: {path.name}",
                COLOR_SUCCESS,
                sound_id="success",
            )
        return True

    def _change_balance(self, amount: float, transaction_type: str) -> None:
        """Меняет баланс и добавляет запись в журнал CryptoWallet."""
        self.btc_balance += amount
        if amount > 0.0:
            self._play_sound("sfx_coin")
        if abs(self.btc_balance) < 1e-12:
            self.btc_balance = 0.0
        self.transactions.append(
            {
                "timestamp": time.time(),
                "type": transaction_type,
                "amount": amount,
            }
        )
        if len(self.transactions) > TRANSACTION_HISTORY_LIMIT:
            del self.transactions[: len(self.transactions) - TRANSACTION_HISTORY_LIMIT]

    def _change_reputation(self, amount: int) -> int:
        """Изменяет репутацию, всегда сохраняя диапазон -100..+100."""
        previous = self.messenger_reputation
        self.messenger_reputation = min(
            REPUTATION_MAX,
            max(REPUTATION_MIN, previous + int(amount)),
        )
        return self.messenger_reputation - previous

    def _change_suspicion(self, amount: float, reason: str = "") -> float:
        """Изменяет подозрение в диапазоне 0–100 и запускает арест на максимуме."""
        previous = self.suspicion
        self.suspicion = min(
            SUSPICION_MAX,
            max(SUSPICION_MIN, previous + float(amount)),
        )
        if self.suspicion >= SUSPICION_MAX and not self.arrested:
            self._trigger_arrest(reason or "Цифровой след достиг критического уровня")
        return self.suspicion - previous

    def _trigger_arrest(self, reason: str) -> None:
        if self.arrested:
            return
        self.arrested = True
        self.total_arrests += 1
        self.arrest_reason = reason
        self._reset_live_events()
        self._play_sound("alarm")
        self.browser_input_focused = False
        self.dragged_window = None
        self.desktop_launcher_open = False
        self._change_state(STATE_ARREST)
        self._save_game()

    @staticmethod
    def _skill_nodes() -> tuple[dict[str, object], ...]:
        return tuple(
            node
            for branch in SKILL_TREE_BRANCHES
            for node in branch["nodes"]
            if isinstance(node, dict)
        )

    @classmethod
    def _skill_definition(cls, skill_id: str) -> dict[str, object] | None:
        return next(
            (node for node in cls._skill_nodes() if node.get("id") == skill_id),
            None,
        )

    def _has_skill(self, skill_id: str) -> bool:
        return skill_id in self.unlocked_skills

    def _effective_target_difficulty(self, base_difficulty: int) -> int:
        reduction = 0
        if self._has_skill("hack_tuning"):
            reduction += SKILL_HACK_DIFFICULTY_REDUCTION
        if self._is_game_night():
            reduction += GAME_NIGHT_DIFFICULTY_REDUCTION
        return min(
            MINIGAME_DIFFICULTY_MAX,
            max(MINIGAME_DIFFICULTY_MIN, int(base_difficulty) - reduction),
        )

    def _skill_can_unlock(self, skill: dict[str, object]) -> bool:
        skill_id = str(skill["id"])
        required = skill.get("requires")
        return (
            skill_id not in self.unlocked_skills
            and (required is None or str(required) in self.unlocked_skills)
            and self.skill_points >= int(skill["cost"])
        )

    def _unlock_skill(self, skill_id: str) -> bool:
        skill = self._skill_definition(skill_id)
        if skill is None or skill_id in self.unlocked_skills:
            return False
        required = skill.get("requires")
        if required is not None and str(required) not in self.unlocked_skills:
            self._push_notification("Сначала откройте предыдущий навык", COLOR_ERROR)
            return False
        cost = int(skill["cost"])
        if self.skill_points < cost:
            self._push_notification(
                f"Недостаточно очков навыков: нужно {cost}",
                COLOR_ERROR,
            )
            return False
        self.skill_points -= cost
        self.unlocked_skills.add(skill_id)
        self._push_notification(
            f"Навык открыт: {skill['name']}",
            COLOR_SUCCESS,
        )
        return True

    def _reputation_reward_multiplier(self) -> float:
        reputation_ratio = self.messenger_reputation / REPUTATION_MAX
        multiplier = 1.0 + reputation_ratio * ORDER_REWARD_REPUTATION_INFLUENCE
        if self._has_skill("negotiator"):
            multiplier *= SKILL_ORDER_REWARD_MULTIPLIER
        return multiplier

    def _order_deadline_multiplier(self) -> float:
        reputation_ratio = self.messenger_reputation / REPUTATION_MAX
        multiplier = 1.0 + reputation_ratio * ORDER_DEADLINE_REPUTATION_INFLUENCE
        if self._has_skill("fixer_network"):
            multiplier *= SKILL_DEADLINE_MULTIPLIER
        return multiplier

    def _set_vpn_charges(self, value: int) -> int:
        """Ограничивает ресурс VPN диапазоном 0–5 и синхронизирует статус."""
        previous = self.vpn_charges
        self.vpn_charges = min(VPN_MAX_CHARGES, max(0, int(value)))
        self.vpn_connected = self.vpn_charges > 0
        return self.vpn_charges - previous

    @staticmethod
    def _darknet_product(product_id: str) -> dict[str, object] | None:
        return next(
            (
                product
                for product in DARKNET_PRODUCTS
                if str(product["id"]) == product_id
            ),
            None,
        )

    def _darknet_effective_price(self, product: dict[str, object]) -> float:
        price = float(product["price"])
        if self.darknet_discount_timer > 0.0:
            price *= 1.0 - CALL_INFORMANT_DISCOUNT_RATE
        return round(price, 6)

    def _purchase_darknet_product(self, product: dict[str, object]) -> bool:
        price = self._darknet_effective_price(product)
        vpn_charge_value = product.get("vpn_charges")
        threat_active = bool(self.call_state.get("threat_active"))
        if (
            vpn_charge_value is not None
            and self.vpn_charges >= VPN_MAX_CHARGES
            and not threat_active
        ):
            self._push_notification("VPN уже заряжен до максимума", COLOR_ERROR)
            return False
        if self.btc_balance + 1e-12 < price:
            self._push_notification(
                f"Недостаточно BTC для {product['name']}",
                COLOR_ERROR,
            )
            return False

        product_id = str(product["id"])
        self._change_balance(-price, f"Покупка: {product['name']}")
        if vpn_charge_value is not None:
            added_charges = self._set_vpn_charges(
                self.vpn_charges + int(vpn_charge_value)
            )
            result = (
                f"VPN: +{added_charges} зарядов"
                if added_charges > 0
                else "VPN-маршрут обновлён"
            )
            self._resolve_threat_vpn_success()
        elif product_id == "skill_course":
            self.skill_points += 1
            self.skill_points_earned += 1
            result = f"Очки навыков: {self.skill_points}"
        else:
            self.inventory[product_id] += 1
            result = f"В инвентаре: {self.inventory[product_id]}"
        self._push_notification(
            f"Куплено: {product['name']} • {result}",
            COLOR_SUCCESS,
        )
        return True

    def _consume_inventory(self, product_id: str) -> bool:
        count = self.inventory.get(product_id, 0)
        if count <= 0:
            return False
        self.inventory[product_id] = count - 1
        return True

    def _withdraw_miner_income(self) -> bool:
        if self.miner_pending_income <= 1e-12:
            self._push_notification("Нет накопленного дохода", COLOR_ERROR)
            return False
        amount = self.miner_pending_income
        self.miner_pending_income = 0.0
        self._change_balance(amount, "Доход майнеров")
        self._push_notification(
            f"Доход майнеров зачислен: +₿ {amount:.6f}",
            COLOR_SUCCESS,
        )
        return True

    def _reset_messenger(self) -> None:
        customer_nicks = self._customer_nicks()
        self.messenger_selected_chat = customer_nicks[0]
        self.messenger_reputation = MESSENGER_INITIAL_REPUTATION
        self.messenger_order_sequence = 0
        self.messenger_orders_processed = 0
        self.story_chapters_issued = 0
        self.story_chapters_completed = 0
        self.story_choices = []
        self.story_scores = {"null": 0, "red": 0, "peace": 0, "chaos": 0}
        self.story_finale_reached = False
        self.story_finale_acknowledged = False
        self.story_ending_key = ""
        self.messenger_refusals = {nick: 0 for nick in customer_nicks}
        self.messenger_active_orders: dict[str, dict[str, object] | None] = {
            nick: None for nick in customer_nicks
        }
        self.messenger_messages: dict[str, list[dict[str, object]]] = {
            nick: [] for nick in customer_nicks
        }
        self.messenger_forum_unlocked = False
        self.messenger_forum_orders: list[dict[str, object]] = []
        for nick in customer_nicks:
            self._issue_order(nick, notify=False)

    def _make_tutorial_order(self) -> dict[str, object]:
        self.messenger_order_sequence += 1
        self.tutorial_attempts += 1
        self.tutorial_order_id = self.messenger_order_sequence
        return {
            "id": self.messenger_order_sequence,
            "customer": TUTORIAL_CUSTOMER,
            "target": TUTORIAL_TARGET,
            "type": "учебный аудит доступа",
            "category": "data",
            "target_type": "Обычный ПК",
            "description": (
                "Пройти безопасную песочницу и передать контрольную фразу. "
                "Система ZERO DAY будет подсвечивать каждый шаг."
            ),
            "reward": TUTORIAL_REWARD,
            "deadline_at": time.time() + TUTORIAL_DEADLINE_MINUTES * 60,
            "deadline_minutes": TUTORIAL_DEADLINE_MINUTES,
            "is_story": False,
            "is_tutorial": True,
            "status": "pending",
        }

    def _make_order(self, customer: str) -> dict[str, object]:
        self.messenger_order_sequence += 1
        template = self.order_random.choice(ORDER_TEMPLATES)
        reward = round(
            self.order_random.uniform(
                float(template["reward_min"]),
                float(template["reward_max"]),
            )
            * self._reputation_reward_multiplier(),
            3,
        )
        base_deadline = self.order_random.randint(
            MESSENGER_DEADLINE_MINUTES_MIN,
            MESSENGER_DEADLINE_MINUTES_MAX,
        )
        deadline_minutes = min(
            ORDER_DEADLINE_MINUTES_CEILING,
            max(
                ORDER_DEADLINE_MINUTES_FLOOR,
                round(base_deadline * self._order_deadline_multiplier()),
            ),
        )
        sequence = self.messenger_order_sequence
        difficulty_reduction = min(1, self.informant_pending_difficulty_bonus)
        self.informant_pending_difficulty_bonus = max(
            0,
            self.informant_pending_difficulty_bonus - difficulty_reduction,
        )
        return {
            "id": sequence,
            "customer": customer,
            "target": str(template["target"]),
            "type": str(template["type"]),
            "category": str(template["category"]),
            "target_type": str(template["target_type"]),
            "description": str(template["description"]),
            "reward": reward,
            "deadline_at": time.time() + deadline_minutes * 60,
            "deadline_minutes": deadline_minutes,
            "is_story": False,
            "difficulty_reduction": difficulty_reduction,
            "status": "pending",
        }

    def _story_order_due(self) -> bool:
        return (
            not self.story_finale_reached
            and self.story_chapters_issued < len(STORY_CHAPTERS)
            and self.story_chapters_completed == self.story_chapters_issued
            and self.completed_orders
            >= (self.story_chapters_issued + 1) * MESSENGER_STORY_INTERVAL
        )

    def _make_story_order(self, customer: str) -> dict[str, object]:
        chapter_index = self.story_chapters_issued
        chapter = STORY_CHAPTERS[chapter_index]
        self.story_chapters_issued += 1
        self.messenger_order_sequence += 1
        base_reward = self.order_random.uniform(
            float(chapter["reward_min"]),
            float(chapter["reward_max"]),
        )
        reward = round(base_reward * self._reputation_reward_multiplier(), 3)
        base_deadline = self.order_random.randint(
            MESSENGER_DEADLINE_MINUTES_MIN,
            MESSENGER_DEADLINE_MINUTES_MAX,
        )
        deadline_minutes = min(
            ORDER_DEADLINE_MINUTES_CEILING,
            max(
                ORDER_DEADLINE_MINUTES_FLOOR,
                round(base_deadline * self._order_deadline_multiplier()),
            ),
        )
        return {
            "id": self.messenger_order_sequence,
            "customer": customer,
            "target": str(chapter["target"]),
            "type": str(chapter["type"]),
            "category": str(chapter["category"]),
            "target_type": str(chapter["target_type"]),
            "description": str(chapter["description"]),
            "reward": reward,
            "deadline_at": time.time() + deadline_minutes * 60,
            "deadline_minutes": deadline_minutes,
            "is_story": True,
            "story_chapter": chapter_index,
            "story_title": str(chapter["title"]),
            "story_faction": str(chapter["faction"]),
            "accept_label": str(chapter["accept_label"]),
            "reject_label": str(chapter["reject_label"]),
            "status": "pending",
        }

    @staticmethod
    def _order_message(order: dict[str, object]) -> str:
        if bool(order.get("is_hot_deal")):
            return ZeroDayApp._hot_deal_message(order)
        if bool(order.get("is_tutorial")):
            return (
                "ОБУЧЕНИЕ // ПЕРВЫЙ КОНТРАКТ\n"
                f"Цель: {order['target']}\n"
                f"Задача: {order['description']}\n"
                f"Награда: ₿ {float(order['reward']):.3f} + 1 SP"
            )
        if bool(order["is_story"]):
            return (
                f"СЮЖЕТНЫЙ ЗАКАЗ // {order['story_title']}\n"
                f"Канал: {order['story_faction']}\n"
                f"Цель: {order['target']}\n"
                f"{order['description']}\n"
                f"ВЫБОР: {order['accept_label']} / {order['reject_label']}\n"
                f"Награда: ₿ {float(order['reward']):.3f}"
            )
        return (
            f"ЗАКАЗ #{int(order['id']):03d}\n"
            f"Цель: {order['target']}\n"
            f"Тип: {order['type']}\n"
            f"Задача: {order['description']}\n"
            f"Награда: ₿ {float(order['reward']):.3f}"
        )

    def _append_messenger_message(
        self,
        customer: str,
        direction: str,
        text: str,
        *,
        order_id: int | None = None,
        is_story: bool = False,
        is_hot_deal: bool = False,
    ) -> None:
        messages = self.messenger_messages[customer]
        messages.append(
            {
                "direction": direction,
                "text": text,
                "order_id": order_id,
                "is_story": is_story,
                "is_hot_deal": is_hot_deal,
            }
        )
        if len(messages) > MESSENGER_HISTORY_LIMIT:
            del messages[: len(messages) - MESSENGER_HISTORY_LIMIT]

    def _issue_order(self, customer: str, *, notify: bool = True) -> None:
        if self.messenger_active_orders[customer] is not None:
            return
        if (
            self.tutorial_active
            and customer == TUTORIAL_CUSTOMER
            and self.completed_orders == 0
        ):
            order = self._make_tutorial_order()
        elif self._story_order_due():
            order = self._make_story_order(customer)
        else:
            order = self._make_order(customer)
        self.messenger_active_orders[customer] = order
        self._append_messenger_message(
            customer,
            "incoming",
            self._order_message(order),
            order_id=int(order["id"]),
            is_story=bool(order["is_story"]),
        )
        if notify:
            title = "Сюжетный заказ" if bool(order["is_story"]) else "Новый заказ"
            color = COLOR_ERROR if bool(order["is_story"]) else COLOR_SUCCESS
            self._push_notification(f"{title} от {customer}", color)
        self._update_browser_results()

    def _issue_due_story_order(self, preferred_customer: str | None = None) -> bool:
        if not self._story_order_due():
            return False
        candidates = self._customer_nicks()
        if preferred_customer in candidates:
            candidates.remove(str(preferred_customer))
            candidates.insert(0, str(preferred_customer))
        customer = next(
            (
                nick
                for nick in candidates
                if self.messenger_active_orders.get(nick) is None
            ),
            None,
        )
        if customer is None:
            return False
        self._issue_order(customer)
        return True

    def _push_notification(
        self,
        message: str,
        color: pygame.Color = COLOR_SUCCESS,
        *,
        sound_id: str | None = "notification",
        force: bool = False,
    ) -> None:
        if bool(self.hot_deal.get("active")) and not force:
            return
        self.desktop_notifications.append(
            {
                "message": message,
                "remaining": DESKTOP_NOTIFICATION_DURATION_SECONDS,
                "color": color,
            }
        )
        if len(self.desktop_notifications) > DESKTOP_NOTIFICATION_MAX_VISIBLE:
            del self.desktop_notifications[
                : len(self.desktop_notifications) - DESKTOP_NOTIFICATION_MAX_VISIBLE
            ]
        if sound_id is not None:
            self._play_sound(sound_id)

    def _record_story_choice(
        self,
        order: dict[str, object],
        decision: str,
    ) -> None:
        if not bool(order.get("is_story")) or bool(order.get("story_choice_recorded")):
            return
        chapter_index = int(order["story_chapter"])
        chapter = STORY_CHAPTERS[chapter_index]
        effect_key = "accepted_effect" if decision == "accepted" else "rejected_effect"
        effect = chapter[effect_key]
        if not isinstance(effect, dict):
            return
        for score_key in ("null", "red", "peace", "chaos"):
            self.story_scores[score_key] += int(effect.get(score_key, 0))
        if chapter_index == len(STORY_CHAPTERS) - 1 and decision == "rejected":
            if self.story_scores["null"] > self.story_scores["red"]:
                self.story_scores["null"] += 2
            elif self.story_scores["red"] > self.story_scores["null"]:
                self.story_scores["red"] += 2
            else:
                self.story_scores["chaos"] += 1
        reputation_change = self._change_reputation(int(effect.get("reputation", 0)))
        suspicion_change = self._change_suspicion(
            float(effect.get("suspicion", 0.0)),
            f"Сюжетный выбор: {chapter['title']}",
        )
        order["story_choice_recorded"] = True
        order["story_choice"] = decision
        self.story_choices.append(
            {
                "chapter": chapter_index,
                "decision": decision,
                "reputation": reputation_change,
                "suspicion": suspicion_change,
            }
        )

    def _determine_story_ending(self) -> str:
        peace = self.story_scores["peace"]
        chaos = self.story_scores["chaos"]
        null_score = self.story_scores["null"]
        red_score = self.story_scores["red"]
        if peace >= 4 and peace > chaos:
            return "truce"
        if chaos >= 5 and abs(null_score - red_score) <= 1:
            return "blackout"
        if null_score > red_score:
            return "null_victory"
        if red_score > null_score:
            return "red_victory"
        if chaos >= 3:
            return "blackout"
        return "independent"

    def _complete_story_order(
        self,
        order: dict[str, object],
        outcome: str,
    ) -> None:
        if not bool(order.get("is_story")) or bool(order.get("story_resolved")):
            return
        order["story_resolved"] = True
        chapter_index = int(order["story_chapter"])
        self.story_chapters_completed = max(
            self.story_chapters_completed,
            chapter_index + 1,
        )
        chapter = STORY_CHAPTERS[chapter_index]
        customer = str(order["customer"])
        if outcome == "completed":
            story_message = str(chapter["success_message"])
        elif outcome == "rejected":
            story_message = (
                "Альтернативная сторона получила ваш ответ. Война изменила курс."
            )
        else:
            self.story_scores["chaos"] += 2 if outcome == "expired" else 1
            story_message = "Операция сорвана. Обе стороны используют провал как повод для эскалации."
        self._append_messenger_message(
            customer,
            "incoming",
            f"STORY UPDATE: {story_message}",
            is_story=True,
        )
        if chapter_index == len(STORY_CHAPTERS) - 1:
            self.story_ending_key = self._determine_story_ending()
            self.story_finale_reached = True
            self.story_finale_acknowledged = False
            ending = STORY_ENDINGS[self.story_ending_key]
            self._push_notification(f"ФИНАЛ: {ending['title']}", COLOR_HOT_ACCENT)

    def _resolve_order_outcome(
        self,
        order: dict[str, object],
        outcome: str,
    ) -> None:
        if bool(order.get("career_outcome_recorded")):
            return
        order["career_outcome_recorded"] = True
        is_story = bool(order.get("is_story"))
        if outcome == "completed":
            self.completed_orders += 1
            self.skill_points += SKILL_POINTS_PER_COMPLETED_ORDER
            self.skill_points_earned += SKILL_POINTS_PER_COMPLETED_ORDER
            reputation_gain = ORDER_COMPLETION_REPUTATION_GAIN
            if self._has_skill("fixer_network"):
                reputation_gain += SKILL_REPUTATION_GAIN_BONUS
            self._change_reputation(reputation_gain)
            suspicion_reduction = SUSPICION_CLEAN_ORDER_REDUCTION
            if self._has_skill("trace_cleaner"):
                suspicion_reduction += SKILL_ORDER_SUSPICION_REDUCTION
            self._change_suspicion(-suspicion_reduction)
            self._push_notification(
                f"Заказ завершён: +{SKILL_POINTS_PER_COMPLETED_ORDER} SP",
                COLOR_SUCCESS,
            )
        elif outcome == "rejected":
            if not is_story:
                self._change_reputation(-MESSENGER_REFUSAL_PENALTY)
        elif outcome == "failed":
            self._change_reputation(-ORDER_FAILURE_REPUTATION_PENALTY)
        elif outcome == "aborted":
            self._change_reputation(-ORDER_ABORT_REPUTATION_PENALTY)
        elif outcome == "closed_without_delivery":
            self._change_reputation(-ORDER_NO_DELIVERY_REPUTATION_PENALTY)
        elif outcome == "expired":
            self._change_reputation(-ORDER_EXPIRED_REPUTATION_PENALTY)
        self._complete_story_order(order, outcome)

    def _show_story_finale_if_ready(self) -> bool:
        if (
            self.story_finale_reached
            and not self.story_finale_acknowledged
            and not self.arrested
        ):
            self._reset_live_events()
            self._change_state(STATE_STORY_FINALE)
            return True
        return False

    def _attack_progress(self) -> int:
        return self.completed_hacks + self.messenger_orders_processed

    def _schedule_next_hacker_attack(self) -> None:
        progress_multiplier = max(
            HACKER_ATTACK_MIN_MULTIPLIER,
            1.0 - self._attack_progress() * HACKER_ATTACK_PROGRESS_REDUCTION,
        )
        base_interval = self.attack_random.uniform(
            HACKER_ATTACK_INTERVAL_MIN_SECONDS,
            HACKER_ATTACK_INTERVAL_MAX_SECONDS,
        )
        reputation_multiplier = 1.0 + (
            self.messenger_reputation
            / REPUTATION_MAX
            * HACKER_ATTACK_REPUTATION_INFLUENCE
        )
        defense_multiplier = (
            HACKER_ATTACK_DEFENSE_SKILL_MULTIPLIER
            if self._has_skill("threat_forecast")
            else 1.0
        )
        night_multiplier = (
            1.0 / GAME_NIGHT_ATTACK_FREQUENCY_MULTIPLIER
            if self._is_game_night()
            else 1.0
        )
        self.hacker_attack_timer = min(
            HACKER_ATTACK_INTERVAL_MAX_SECONDS,
            max(
                HACKER_ATTACK_INTERVAL_FLOOR_SECONDS,
                base_interval
                * progress_multiplier
                * reputation_multiplier
                * defense_multiplier
                * night_multiplier,
            ),
        )
        self.hacker_attack_warning_sent = False

    def _start_intrusion_defense(self) -> None:
        reputation_difficulty = (
            1
            if self.messenger_reputation <= -50
            else -1
            if self.messenger_reputation >= 50
            else 0
        )
        defense_difficulty = min(
            MINIGAME_DIFFICULTY_MAX,
            max(
                MINIGAME_DIFFICULTY_MIN,
                MINIGAME_DIFFICULTY_MIN
                + self._attack_progress() // INTRUSION_PROGRESS_PER_DIFFICULTY
                + reputation_difficulty,
            ),
        )
        duration = self.attack_random.uniform(
            INTRUSION_DURATION_MIN_SECONDS,
            INTRUSION_DURATION_MAX_SECONDS,
        )
        defense = IntrusionDefense(defense_difficulty, duration)
        if self._has_skill("packet_armor"):
            defense.speed_multiplier = SKILL_INTRUSION_SPEED_MULTIPLIER
        self.active_minigame = defense
        self.pending_minigame_order = None
        self.active_hack_context = None
        self._play_sound("sfx_glitch")
        self._change_state(STATE_INTRUSION_DEFENSE)

    def _resolve_hacker_attack(self) -> None:
        if self.vpn_charges > 0:
            self._set_vpn_charges(self.vpn_charges - 1)
            self.hacker_attacks_survived += 1
            self._push_notification("Attack blocked!", COLOR_SUCCESS)
            self._schedule_next_hacker_attack()
        else:
            self._set_vpn_charges(0)
            self._push_notification("VPN depleted — defend the server!", COLOR_ERROR)
            self._start_intrusion_defense()

    def _update_hacker_attack_timer(self, delta_seconds: float) -> None:
        if (
            not self.has_active_session
            or self.state != STATE_DESKTOP
            or bool(self.call_state.get("active"))
            or bool(self.call_state.get("threat_active"))
            or bool(self.hot_deal.get("active"))
        ):
            return
        self.hacker_attack_timer -= delta_seconds
        if (
            self.hacker_attack_timer <= HACKER_ATTACK_WARNING_SECONDS
            and not self.hacker_attack_warning_sent
        ):
            self.hacker_attack_warning_sent = True
            self._push_notification(
                "⚠ INCOMING ATTACK",
                COLOR_ERROR,
                sound_id="alarm",
            )
        if self.hacker_attack_timer <= 0.0:
            self._resolve_hacker_attack()

    def _unlock_forum_if_needed(self) -> None:
        if (
            self.messenger_forum_unlocked
            or self.messenger_orders_processed < MESSENGER_FORUM_UNLOCK_ORDER
        ):
            return
        self.messenger_forum_unlocked = True
        self.messenger_forum_orders = []
        for index in range(MESSENGER_FORUM_ORDER_COUNT):
            template = self.order_random.choice(ORDER_TEMPLATES)
            base_minutes = self.order_random.randint(
                MESSENGER_DEADLINE_MINUTES_MIN,
                MESSENGER_DEADLINE_MINUTES_MAX,
            )
            minutes = min(
                ORDER_DEADLINE_MINUTES_CEILING,
                max(
                    ORDER_DEADLINE_MINUTES_FLOOR,
                    round(base_minutes * self._order_deadline_multiplier()),
                ),
            )
            self.messenger_forum_orders.append(
                {
                    "id": index + 1,
                    "target": str(template["target"]),
                    "type": str(template["type"]),
                    "reward": round(
                        self.order_random.uniform(
                            float(template["reward_min"]),
                            float(template["reward_max"]),
                        )
                        * self._reputation_reward_multiplier(),
                        3,
                    ),
                    "deadline_at": time.time() + minutes * 60,
                }
            )
        self._push_notification("Открыта новая вкладка «Форум»", COLOR_HOT_ACCENT)

    def _trigger_hacker_attack(self, customer: str) -> None:
        self.hacker_attack_time = MESSENGER_ATTACK_FLASH_SECONDS
        self.hacker_attack_timer = min(
            self.hacker_attack_timer,
            HACKER_ATTACK_WARNING_SECONDS,
        )
        self.hacker_attack_warning_sent = False
        self._play_sound("sfx_glitch")
        self._append_messenger_message(
            customer,
            "incoming",
            "INTRUSION DETECTED. Три отказа приняты слишком лично.",
        )
        self._push_notification(f"АТАКА ХАКЕРА: {customer}", COLOR_ERROR)

    def _minigame_for_order(self, order: dict[str, object]) -> str:
        category_value = order.get("category")
        if category_value is None:
            target_description = (
                f"{order.get('target', '')} {order.get('type', '')}"
            ).lower()
            category_value = "network"
            for category, keywords in TARGET_CATEGORY_KEYWORDS.items():
                if any(keyword in target_description for keyword in keywords):
                    category_value = category
                    break
        compatible_games = TARGET_MINIGAME_MAP.get(
            str(category_value),
            tuple(entry[0] for entry in MINIGAME_ENTRIES),
        )
        return self.order_random.choice(compatible_games)

    def _process_order(self, customer: str, decision: str) -> None:
        order = self.messenger_active_orders.get(customer)
        if order is None or order.get("status") != "pending":
            return
        is_story = bool(order.get("is_story"))
        is_tutorial = bool(order.get("is_tutorial"))
        order["status"] = decision
        if is_story:
            self._record_story_choice(order, decision)
        reward = float(order["reward"])
        game_to_start: str | None = None
        order_context: dict[str, object] | None = None
        if decision == "accepted" and not self.arrested:
            if is_tutorial:
                self.tutorial_step = 3
            game_to_start = self._minigame_for_order(order)
            target_type = str(order.get("target_type", "Обычный ПК"))
            target_parameters = TARGET_TYPES[target_type]
            difficulty_reduction = int(order.get("difficulty_reduction", 0))
            order_context = {
                "source": "order",
                "customer": customer,
                "reward": reward,
                "order_id": int(order["id"]),
                "target": str(order["target"]),
                "target_type": target_type,
                "difficulty": max(
                    MINIGAME_DIFFICULTY_MIN,
                    int(target_parameters["difficulty"]) - difficulty_reduction,
                ),
                "game_id": game_to_start,
                "order": order,
            }
            accepted_label = (
                str(order.get("accept_label")) if is_story else "Заказ принят"
            )
            self._append_messenger_message(
                customer,
                "outgoing",
                f"{accepted_label}. Запускаю модуль: {game_to_start}.",
                is_story=is_story,
            )
            self._push_notification(f"Взлом цели: {order['target']}", COLOR_SUCCESS)
        elif decision == "rejected":
            if is_story:
                rejected_label = str(order.get("reject_label", "Альтернативный выбор"))
                self._append_messenger_message(
                    customer,
                    "outgoing",
                    f"Сюжетный выбор: {rejected_label}.",
                    is_story=True,
                )
                self._push_notification("Сюжетный выбор зафиксирован", COLOR_HOT_ACCENT)
            else:
                self.messenger_refusals[customer] += 1
                refusals = self.messenger_refusals[customer]
                self._append_messenger_message(
                    customer,
                    "outgoing",
                    f"Заказ отклонён. Репутация -{MESSENGER_REFUSAL_PENALTY}.",
                )
                self._push_notification(f"Заказ {customer} отклонён", COLOR_ERROR)
                if refusals == MESSENGER_ATTACK_REFUSALS:
                    self._trigger_hacker_attack(customer)
            self._resolve_order_outcome(order, "rejected")
        else:
            self._resolve_order_outcome(order, "aborted")

        self.messenger_active_orders[customer] = None
        self.messenger_orders_processed += 1
        self._unlock_forum_if_needed()
        if is_tutorial and decision != "accepted" and self.tutorial_active:
            self.tutorial_step = 2
            self._issue_order(customer)
        if not self.arrested and not self.story_finale_reached:
            self._issue_due_story_order(customer)
        self._update_browser_results()
        if game_to_start is None:
            self._save_game()
        if self._show_story_finale_if_ready() or self.arrested:
            return
        if game_to_start is not None and order_context is not None:
            self._prepare_hack(
                game_to_start,
                hack_context=order_context,
                difficulty_override=int(order_context["difficulty"]),
            )

    def _expire_messenger_orders(self) -> None:
        current_time = time.time()
        expired_customers: list[str] = []
        for customer, order in self.messenger_active_orders.items():
            if (
                order is not None
                and order.get("status") == "pending"
                and current_time >= float(order["deadline_at"])
            ):
                order["status"] = "expired"
                expired_customers.append(customer)

        for customer in expired_customers:
            expired_order = self.messenger_active_orders[customer]
            self.messenger_active_orders[customer] = None
            self.messenger_orders_processed += 1
            if isinstance(expired_order, dict):
                self._resolve_order_outcome(expired_order, "expired")
                if self.tutorial_active and bool(expired_order.get("is_tutorial")):
                    self.tutorial_step = 2
                    self._issue_order(customer)
            self._append_messenger_message(
                customer,
                "incoming",
                "SYSTEM: дедлайн заказа истёк.",
                is_story=bool(expired_order and expired_order.get("is_story")),
            )
            self._push_notification(f"Дедлайн {customer} истёк", COLOR_ERROR)
        if expired_customers:
            self._unlock_forum_if_needed()
            if not self.story_finale_reached:
                self._issue_due_story_order(expired_customers[0])
            self._update_browser_results()
            self._save_game()
            self._show_story_finale_if_ready()

    @staticmethod
    def _format_deadline(deadline_at: float) -> str:
        seconds_left = max(0, math.ceil(deadline_at - time.time()))
        minutes, seconds = divmod(seconds_left, 60)
        return f"{minutes:02d}:{seconds:02d}"

    def _update_desktop_timers(self, delta_seconds: float) -> None:
        self.hacker_attack_time = max(
            0.0,
            self.hacker_attack_time - delta_seconds,
        )
        for notification in self.desktop_notifications:
            notification["remaining"] = max(
                0.0,
                float(notification["remaining"]) - delta_seconds,
            )
        self.desktop_notifications[:] = [
            notification
            for notification in self.desktop_notifications
            if float(notification["remaining"]) > 0.0
        ]
        if (
            self.has_active_session
            and not self.arrested
            and self.state != STATE_STORY_FINALE
        ):
            self._advance_game_clock(delta_seconds)
            self._update_hacker_attack_timer(delta_seconds)
            self._expire_messenger_orders()
            total_miner_rate = sum(
                float(miner.get("rate", MINER_RATE_BTC_PER_MINUTE))
                for miner in self.miner_targets
            )
            miner_income = total_miner_rate * delta_seconds / 60.0
            self.miner_pending_income += miner_income
            self.miner_earned_total += miner_income

    def _reset_desktop(self) -> None:
        self.arrested = False
        self.arrest_reason = ""
        self.desktop_session_elapsed = 0.0
        self.desktop_windows.clear()
        self.dragged_window = None
        self.desktop_launcher_open = False
        self.vpn_connected = False
        self.vpn_charges = 0
        self.suspicion = 0.0
        self.btc_balance = DESKTOP_INITIAL_BTC
        self.desktop_notifications.clear()
        self.hacker_attack_time = 0.0
        self.hacker_attacks_survived = 0
        self.completed_hacks = 0
        self.completed_orders = 0
        self.game_time_elapsed = 0.0
        self.was_night = self._is_game_night()
        self.tutorial_active = True
        self.tutorial_step = 0
        self.tutorial_completed = False
        self.tutorial_attempts = 0
        self.tutorial_order_id = None
        self.hacker_attack_warning_sent = False
        self.browser_query = ""
        self.browser_input_focused = False
        self.browser_selected_target = None
        self.browser_results = []
        self.darknet_category = DARKNET_CATEGORIES[0][0]
        self.darknet_page = 0
        self.inventory = {item_id: 0 for item_id in DARKNET_INVENTORY_IDS}
        self.skill_points = 0
        self.skill_points_earned = 0
        self.unlocked_skills = set()
        self.transactions = []
        self.miner_targets = []
        self.miner_earned_total = 0.0
        self.miner_pending_income = 0.0
        self.active_minigame = None
        self.pending_minigame_order = None
        self.active_hack_context = None
        self.pending_hack_launch = None
        self.selected_hack_tools = set()
        self.post_hack_mode = "actions"
        self._reset_live_events()
        self._reset_messenger()
        self._schedule_next_hacker_attack()

    @staticmethod
    def _desktop_icon_square(index: int) -> pygame.Rect:
        column = index % DESKTOP_ICON_COLUMNS
        row = index // DESKTOP_ICON_COLUMNS
        return pygame.Rect(
            DESKTOP_ICON_START_X + column * DESKTOP_ICON_COLUMN_STEP,
            DESKTOP_ICON_START_Y + row * DESKTOP_ICON_ROW_STEP,
            DESKTOP_ICON_SIZE,
            DESKTOP_ICON_SIZE,
        )

    @classmethod
    def _desktop_icon_hit_rect(cls, index: int) -> pygame.Rect:
        square = cls._desktop_icon_square(index)
        side_margin = (DESKTOP_ICON_HIT_WIDTH - DESKTOP_ICON_SIZE) // 2
        return pygame.Rect(
            square.x - side_margin,
            square.y,
            DESKTOP_ICON_HIT_WIDTH,
            DESKTOP_ICON_HIT_HEIGHT,
        )

    @staticmethod
    def _launcher_item_rect(index: int) -> pygame.Rect:
        return pygame.Rect(
            DESKTOP_LAUNCHER_ITEM_X,
            DESKTOP_LAUNCHER_ITEM_START_Y + index * DESKTOP_LAUNCHER_ITEM_HEIGHT,
            DESKTOP_LAUNCHER_ITEM_WIDTH,
            DESKTOP_LAUNCHER_ITEM_HEIGHT,
        )

    @staticmethod
    def _launcher_minigame_rect(index: int) -> pygame.Rect:
        return pygame.Rect(
            DESKTOP_LAUNCHER_ITEM_X,
            DESKTOP_LAUNCHER_MINIGAME_START_Y + index * DESKTOP_LAUNCHER_ITEM_HEIGHT,
            DESKTOP_LAUNCHER_ITEM_WIDTH,
            DESKTOP_LAUNCHER_ITEM_HEIGHT,
        )

    @staticmethod
    def _messenger_content_rect(window: DesktopWindow) -> pygame.Rect:
        return pygame.Rect(
            window.rect.x,
            window.rect.y + DESKTOP_WINDOW_TITLE_HEIGHT,
            window.rect.width,
            window.rect.height - DESKTOP_WINDOW_TITLE_HEIGHT,
        )

    @classmethod
    def _messenger_sidebar_rect(cls, window: DesktopWindow) -> pygame.Rect:
        content = cls._messenger_content_rect(window)
        return pygame.Rect(
            content.x,
            content.y,
            MESSENGER_SIDEBAR_WIDTH,
            content.height,
        )

    @classmethod
    def _messenger_right_rect(cls, window: DesktopWindow) -> pygame.Rect:
        content = cls._messenger_content_rect(window)
        return pygame.Rect(
            content.x + MESSENGER_SIDEBAR_WIDTH,
            content.y,
            content.width - MESSENGER_SIDEBAR_WIDTH,
            content.height,
        )

    @classmethod
    def _messenger_chat_row_rect(
        cls,
        window: DesktopWindow,
        index: int,
    ) -> pygame.Rect:
        sidebar = cls._messenger_sidebar_rect(window)
        return pygame.Rect(
            sidebar.x + MESSENGER_CHAT_ROW_SIDE_MARGIN,
            sidebar.y
            + MESSENGER_SIDEBAR_HEADER_HEIGHT
            + index * MESSENGER_CHAT_ROW_HEIGHT,
            sidebar.width - MESSENGER_CHAT_ROW_SIDE_MARGIN * 2,
            MESSENGER_CHAT_ROW_HEIGHT,
        )

    @classmethod
    def _messenger_action_rects(
        cls,
        window: DesktopWindow,
    ) -> dict[str, pygame.Rect]:
        right = cls._messenger_right_rect(window)
        available_width = right.width - MESSENGER_ACTION_SIDE_MARGIN * 2
        button_width = (available_width - MESSENGER_ACTION_GAP) // 2
        y = right.bottom - MESSENGER_ACTION_BOTTOM_MARGIN - MESSENGER_ACTION_HEIGHT
        accept = pygame.Rect(
            right.x + MESSENGER_ACTION_SIDE_MARGIN,
            y,
            button_width,
            MESSENGER_ACTION_HEIGHT,
        )
        reject = pygame.Rect(
            accept.right + MESSENGER_ACTION_GAP,
            y,
            button_width,
            MESSENGER_ACTION_HEIGHT,
        )
        return {"accepted": accept, "rejected": reject}

    @staticmethod
    def _window_content_rect(window: DesktopWindow) -> pygame.Rect:
        return pygame.Rect(
            window.rect.x,
            window.rect.y + DESKTOP_WINDOW_TITLE_HEIGHT,
            window.rect.width,
            window.rect.height - DESKTOP_WINDOW_TITLE_HEIGHT,
        )

    @classmethod
    def _skill_tree_node_rect(
        cls,
        window: DesktopWindow,
        branch_index: int,
        node_index: int,
    ) -> pygame.Rect:
        content = cls._window_content_rect(window)
        available_width = (
            content.width
            - SKILL_TREE_CONTENT_MARGIN * 2
            - SKILL_TREE_BRANCH_GAP * (len(SKILL_TREE_BRANCHES) - 1)
        )
        branch_width = available_width // len(SKILL_TREE_BRANCHES)
        x = (
            content.x
            + SKILL_TREE_CONTENT_MARGIN
            + branch_index * (branch_width + SKILL_TREE_BRANCH_GAP)
        )
        y = (
            content.y
            + SKILL_TREE_CONTENT_MARGIN
            + SKILL_TREE_HEADER_HEIGHT
            + SKILL_TREE_BRANCH_TITLE_HEIGHT
            + node_index * (SKILL_TREE_NODE_HEIGHT + SKILL_TREE_NODE_GAP)
        )
        if branch_index == len(SKILL_TREE_BRANCHES) - 1:
            branch_width = content.right - SKILL_TREE_CONTENT_MARGIN - x
        return pygame.Rect(x, y, branch_width, SKILL_TREE_NODE_HEIGHT)

    def _handle_skill_tree_click(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> bool:
        for branch_index, branch in enumerate(SKILL_TREE_BRANCHES):
            nodes = branch.get("nodes")
            if not isinstance(nodes, tuple):
                continue
            for node_index, node in enumerate(nodes):
                if not isinstance(node, dict):
                    continue
                if self._skill_tree_node_rect(
                    window,
                    branch_index,
                    node_index,
                ).collidepoint(mouse):
                    self._unlock_skill(str(node["id"]))
                    return True
        return False

    @classmethod
    def _browser_address_rect(cls, window: DesktopWindow) -> pygame.Rect:
        content = cls._window_content_rect(window)
        return pygame.Rect(
            content.x + BROWSER_CONTENT_MARGIN,
            content.y + BROWSER_CONTENT_MARGIN,
            content.width - BROWSER_CONTENT_MARGIN * 2,
            BROWSER_ADDRESS_HEIGHT,
        )

    @classmethod
    def _browser_result_rect(cls, window: DesktopWindow, index: int) -> pygame.Rect:
        content = cls._window_content_rect(window)
        return pygame.Rect(
            content.x + BROWSER_CONTENT_MARGIN,
            content.y
            + BROWSER_RESULTS_START_OFFSET
            + index * (BROWSER_RESULT_HEIGHT + BROWSER_RESULT_GAP),
            content.width - BROWSER_CONTENT_MARGIN * 2,
            BROWSER_RESULT_HEIGHT,
        )

    @classmethod
    def _browser_hack_rect(cls, window: DesktopWindow) -> pygame.Rect:
        content = cls._window_content_rect(window)
        width, height = BROWSER_HACK_BUTTON_SIZE
        return pygame.Rect(
            content.right - BROWSER_HACK_BUTTON_MARGIN - width,
            content.bottom - BROWSER_HACK_BUTTON_MARGIN - height,
            width,
            height,
        )

    def _browser_available_targets(self) -> list[dict[str, object]]:
        query = self.browser_query.strip().casefold()
        if not query:
            return []

        results: list[dict[str, object]] = []
        for catalog_target in TARGET_CATALOG:
            target_type = catalog_target["type"]
            if query not in target_type.casefold():
                continue
            parameters = TARGET_TYPES[target_type]
            results.append(
                {
                    "key": f"catalog:{catalog_target['name']}",
                    "name": catalog_target["name"],
                    "target_type": target_type,
                    "location": catalog_target["location"],
                    "description": str(parameters["description"]),
                    "protection": str(parameters["protection"]),
                    "difficulty": int(parameters["difficulty"]),
                }
            )

        # Незакрытые заказы тоже доступны через Browser и помечаются как связанные.
        active_order_items = list(self.messenger_active_orders.items())
        active_order_items.sort(
            key=lambda item: item[0] != self.messenger_selected_chat
        )
        for customer, order in active_order_items:
            if order is None or order.get("status") != "pending":
                continue
            target_type = str(order.get("target_type", "Обычный ПК"))
            if query not in target_type.casefold():
                continue
            parameters = TARGET_TYPES[target_type]
            results.append(
                {
                    "key": f"order:{int(order['id'])}",
                    "name": str(order["target"]),
                    "target_type": target_type,
                    "location": f"заказчик {customer}",
                    "description": str(order["description"]),
                    "protection": str(parameters["protection"]),
                    "difficulty": int(parameters["difficulty"]),
                    "customer": customer,
                    "reward": float(order["reward"]),
                    "order_id": int(order["id"]),
                    "order_pending": True,
                    "order": order,
                }
            )
        return results[:BROWSER_RESULT_MAX_VISIBLE]

    def _update_browser_results(self) -> None:
        selected_key = (
            str(self.browser_selected_target.get("key"))
            if self.browser_selected_target is not None
            else None
        )
        self.browser_results = self._browser_available_targets()
        self.browser_selected_target = next(
            (
                target
                for target in self.browser_results
                if str(target["key"]) == selected_key
            ),
            None,
        )

    def _start_browser_hack(self) -> None:
        target = self.browser_selected_target
        if target is None:
            return
        target_type = str(target["target_type"])
        parameters = TARGET_TYPES[target_type]
        game_id = self.order_random.choice(tuple(parameters["minigames"]))
        context: dict[str, object] = {
            "source": "browser",
            "target": str(target["name"]),
            "target_type": target_type,
            "difficulty": int(parameters["difficulty"]),
            "game_id": game_id,
        }
        for key in ("customer", "reward", "order_id", "order_pending", "order"):
            if key in target:
                context[key] = target[key]
        order_reference = context.get("order")
        if isinstance(order_reference, dict) and bool(order_reference.get("is_story")):
            self._record_story_choice(order_reference, "accepted")
            if self.arrested:
                return
        self.browser_input_focused = False
        self._prepare_hack(
            game_id,
            hack_context=context,
            difficulty_override=int(parameters["difficulty"]),
        )

    def _handle_browser_key(self, event: pygame.event.Event) -> bool:
        if not self.browser_input_focused:
            return False
        if event.type != pygame.KEYDOWN:
            return False
        if event.key == pygame.K_BACKSPACE:
            self.browser_query = self.browser_query[:-1]
        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.browser_input_focused = False
        elif event.key == pygame.K_TAB:
            normalized = self.browser_query.casefold()
            completion = next(
                (
                    target_type
                    for target_type in TARGET_TYPES
                    if target_type.casefold().startswith(normalized)
                ),
                None,
            )
            if completion is not None:
                self.browser_query = completion
        elif (
            event.unicode
            and event.unicode.isprintable()
            and len(self.browser_query) < BROWSER_INPUT_MAX_LENGTH
        ):
            self.browser_query += event.unicode
        else:
            return True
        if (
            event.key not in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_TAB)
            and self.typing_sfx_cooldown <= 0.0
        ):
            self._play_sound("sfx_typing")
            self.typing_sfx_cooldown = SFX_TYPING_DURATION
        self._update_browser_results()
        return True

    def _handle_browser_click(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> bool:
        if self._browser_address_rect(window).collidepoint(mouse):
            self.browser_input_focused = True
            return True
        self.browser_input_focused = False
        for index, target in enumerate(self.browser_results):
            if self._browser_result_rect(window, index).collidepoint(mouse):
                self.browser_selected_target = target
                return True
        if self.browser_selected_target is not None and self._browser_hack_rect(
            window
        ).collidepoint(mouse):
            self._start_browser_hack()
            return True
        return False

    @classmethod
    def _darknet_sidebar_rect(cls, window: DesktopWindow) -> pygame.Rect:
        content = cls._window_content_rect(window)
        return pygame.Rect(
            content.x,
            content.y,
            DARKNET_SIDEBAR_WIDTH,
            content.height,
        )

    @classmethod
    def _darknet_category_rect(
        cls,
        window: DesktopWindow,
        index: int,
    ) -> pygame.Rect:
        sidebar = cls._darknet_sidebar_rect(window)
        return pygame.Rect(
            sidebar.x + DARKNET_CATEGORY_MARGIN,
            sidebar.y
            + DARKNET_HEADER_HEIGHT
            + index * (DARKNET_CATEGORY_ROW_HEIGHT + DARKNET_CATEGORY_GAP),
            sidebar.width - DARKNET_CATEGORY_MARGIN * 2,
            DARKNET_CATEGORY_ROW_HEIGHT,
        )

    @classmethod
    def _darknet_card_rect(cls, window: DesktopWindow, slot: int) -> pygame.Rect:
        content = cls._window_content_rect(window)
        area_x = content.x + DARKNET_SIDEBAR_WIDTH
        area_width = content.width - DARKNET_SIDEBAR_WIDTH
        usable_width = area_width - DARKNET_CARD_MARGIN * 2
        card_width = (usable_width - DARKNET_CARD_GAP) // DARKNET_CARD_COLUMNS
        column = slot % DARKNET_CARD_COLUMNS
        row = slot // DARKNET_CARD_COLUMNS
        return pygame.Rect(
            area_x + DARKNET_CARD_MARGIN + column * (card_width + DARKNET_CARD_GAP),
            content.y
            + DARKNET_CARD_START_Y_OFFSET
            + row * (DARKNET_CARD_HEIGHT + DARKNET_CARD_GAP),
            card_width,
            DARKNET_CARD_HEIGHT,
        )

    @staticmethod
    def _darknet_buy_rect(card: pygame.Rect) -> pygame.Rect:
        width, height = DARKNET_BUY_BUTTON_SIZE
        return pygame.Rect(
            card.right - DARKNET_BUY_BUTTON_MARGIN - width,
            card.bottom - DARKNET_BUY_BUTTON_MARGIN - height,
            width,
            height,
        )

    @classmethod
    def _darknet_page_rects(cls, window: DesktopWindow) -> dict[str, pygame.Rect]:
        sidebar = cls._darknet_sidebar_rect(window)
        width, height = DARKNET_PAGE_BUTTON_SIZE
        combined_width = width * 2 + DARKNET_PAGE_BUTTON_GAP
        start_x = sidebar.centerx - combined_width // 2
        y = sidebar.bottom - DARKNET_PAGE_BUTTON_BOTTOM_MARGIN - height
        return {
            "previous": pygame.Rect(start_x, y, width, height),
            "next": pygame.Rect(
                start_x + width + DARKNET_PAGE_BUTTON_GAP,
                y,
                width,
                height,
            ),
        }

    def _darknet_category_products(self) -> list[dict[str, object]]:
        return [
            product
            for product in DARKNET_PRODUCTS
            if product["category"] == self.darknet_category
        ]

    def _darknet_page_count(self) -> int:
        products = self._darknet_category_products()
        return max(1, math.ceil(len(products) / DARKNET_CARDS_PER_PAGE))

    def _darknet_visible_products(self) -> list[dict[str, object]]:
        products = self._darknet_category_products()
        self.darknet_page = min(self.darknet_page, self._darknet_page_count() - 1)
        start = self.darknet_page * DARKNET_CARDS_PER_PAGE
        return products[start : start + DARKNET_CARDS_PER_PAGE]

    def _handle_darknet_click(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> bool:
        for index, (category_id, _label) in enumerate(DARKNET_CATEGORIES):
            if self._darknet_category_rect(window, index).collidepoint(mouse):
                self.darknet_category = category_id
                self.darknet_page = 0
                return True

        page_count = self._darknet_page_count()
        for direction, button in self._darknet_page_rects(window).items():
            if not button.collidepoint(mouse):
                continue
            if direction == "previous":
                self.darknet_page = max(0, self.darknet_page - 1)
            else:
                self.darknet_page = min(page_count - 1, self.darknet_page + 1)
            return True

        for slot, product in enumerate(self._darknet_visible_products()):
            card = self._darknet_card_rect(window, slot)
            if self._darknet_buy_rect(card).collidepoint(mouse):
                self._purchase_darknet_product(product)
                return True
        return False

    @classmethod
    def _miner_withdraw_rect(cls, window: DesktopWindow) -> pygame.Rect:
        content = cls._window_content_rect(window)
        width, height = MINER_MANAGER_WITHDRAW_SIZE
        return pygame.Rect(
            content.right - MINER_MANAGER_WITHDRAW_MARGIN - width,
            content.bottom - MINER_MANAGER_WITHDRAW_MARGIN - height,
            width,
            height,
        )

    @staticmethod
    def _window_title_rect(window: DesktopWindow) -> pygame.Rect:
        return pygame.Rect(
            window.rect.x,
            window.rect.y,
            window.rect.width,
            DESKTOP_WINDOW_TITLE_HEIGHT,
        )

    @staticmethod
    def _window_control_rects(window: DesktopWindow) -> dict[str, pygame.Rect]:
        control_width, control_height = DESKTOP_WINDOW_CONTROL_SIZE
        controls_count = len(DESKTOP_WINDOW_CONTROL_SYMBOLS)
        controls_width = (
            controls_count * control_width
            + (controls_count - 1) * DESKTOP_WINDOW_CONTROL_GAP
        )
        start_x = window.rect.right - DESKTOP_WINDOW_CONTROL_MARGIN - controls_width
        y = window.rect.y + (DESKTOP_WINDOW_TITLE_HEIGHT - control_height) // 2
        return {
            action: pygame.Rect(
                start_x + index * (control_width + DESKTOP_WINDOW_CONTROL_GAP),
                y,
                control_width,
                control_height,
            )
            for index, (action, _symbol) in enumerate(DESKTOP_WINDOW_CONTROL_SYMBOLS)
        }

    def _bring_window_to_front(self, window: DesktopWindow) -> None:
        if self.desktop_windows and self.desktop_windows[-1] is window:
            return
        self.desktop_windows.remove(window)
        self.desktop_windows.append(window)

    def _open_desktop_window(self, app_id: str) -> None:
        if (
            self.tutorial_active
            and app_id == MESSENGER_APP_ID
            and self.tutorial_step == 0
        ):
            self.tutorial_step = 1
        for window in self.desktop_windows:
            if window.app_id == app_id:
                window.minimized = False
                self._bring_window_to_front(window)
                if app_id == BROWSER_APP_ID:
                    self._update_browser_results()
                return

        app = next(item for item in DESKTOP_APPS if item[0] == app_id)
        cascade_slot = len(self.desktop_windows) % DESKTOP_WINDOW_CASCADE_SLOTS
        width, height = DESKTOP_WINDOW_DEFAULT_SIZE
        start_x, start_y = DESKTOP_WINDOW_START_POS
        window = DesktopWindow(
            app_id=app_id,
            title=app[1],
            rect=pygame.Rect(
                start_x + cascade_slot * DESKTOP_WINDOW_CASCADE_OFFSET,
                start_y + cascade_slot * DESKTOP_WINDOW_CASCADE_OFFSET,
                width,
                height,
            ),
        )
        self.desktop_windows.append(window)
        if app_id == BROWSER_APP_ID:
            self._update_browser_results()

    def _toggle_window_maximize(self, window: DesktopWindow) -> None:
        if window.maximized:
            if window.restore_rect is not None:
                window.rect = window.restore_rect.copy()
            window.restore_rect = None
            window.maximized = False
            return
        window.restore_rect = window.rect.copy()
        window.rect = pygame.Rect(DESKTOP_WINDOW_MAXIMIZED_RECT)
        window.maximized = True

    def _close_desktop_window(self, window: DesktopWindow) -> None:
        if self.dragged_window is window:
            self.dragged_window = None
        if window.app_id == BROWSER_APP_ID:
            self.browser_input_focused = False
        self.desktop_windows.remove(window)

    def _handle_window_control(self, action: str, window: DesktopWindow) -> None:
        if action == "close":
            self._close_desktop_window(window)
        elif action == "maximize":
            self._toggle_window_maximize(window)
        elif action == "minimize":
            window.minimized = True
            self.dragged_window = None
            if window.app_id == BROWSER_APP_ID:
                self.browser_input_focused = False

    def _handle_messenger_click(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> bool:
        for index, customer in enumerate(MESSENGER_CUSTOMERS):
            if self._messenger_chat_row_rect(window, index).collidepoint(mouse):
                nick = customer["nick"]
                self.messenger_selected_chat = nick
                if (
                    self.tutorial_active
                    and self.tutorial_step == 1
                    and nick == TUTORIAL_CUSTOMER
                ):
                    self.tutorial_step = 2
                if self.messenger_active_orders[nick] is None:
                    self._issue_order(nick)
                self._update_browser_results()
                return True

        if self.messenger_forum_unlocked:
            forum_index = len(MESSENGER_CUSTOMERS)
            forum_rect = self._messenger_chat_row_rect(window, forum_index)
            if forum_rect.collidepoint(mouse):
                self.messenger_selected_chat = MESSENGER_FORUM_ID
                return True

        selected = self.messenger_selected_chat
        if selected == MESSENGER_FORUM_ID:
            return False
        order = self._visible_messenger_order(selected)
        if order is None or order.get("status") != "pending":
            return False
        for decision, button_rect in self._messenger_action_rects(window).items():
            if button_rect.collidepoint(mouse):
                if bool(order.get("is_hot_deal")):
                    self._process_hot_deal(decision)
                else:
                    self._process_order(selected, decision)
                return True
        return False

    def _handle_desktop_event(self, event: pygame.event.Event) -> bool:
        if self.music_player_dragging_volume:
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                self.music_player_dragging_volume = False
                return True
            if event.type == pygame.MOUSEMOTION:
                music_window = next(
                    (
                        window
                        for window in reversed(self.desktop_windows)
                        if window.app_id == MUSIC_PLAYER_APP_ID and not window.minimized
                    ),
                    None,
                )
                if music_window is not None:
                    mouse_x, _mouse_y = self._desktop_point(event.pos)
                    self._set_music_player_volume_at(music_window, mouse_x)
                return True
        if self._handle_browser_key(event):
            return True
        if event.type == pygame.MOUSEMOTION and self.dragged_window is not None:
            mouse_x, mouse_y = self._desktop_point(event.pos)
            window = self.dragged_window
            window.rect.x = round(mouse_x - self.drag_offset.x)
            window.rect.y = round(mouse_y - self.drag_offset.y)
            max_x = max(0, DESIGN_WIDTH - window.rect.width)
            min_y = DESKTOP_TASKBAR_HEIGHT
            max_y = max(
                min_y,
                DESIGN_HEIGHT - window.rect.height - DESKTOP_WINDOW_DRAG_BOTTOM_MARGIN,
            )
            window.rect.x = min(max(window.rect.x, 0), max_x)
            window.rect.y = min(max(window.rect.y, min_y), max_y)
            return True

        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            was_dragging = self.dragged_window is not None
            self.dragged_window = None
            return was_dragging

        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return False

        mouse = self._desktop_point(event.pos)
        self.browser_input_focused = False
        if pygame.Rect(DESKTOP_MENU_BUTTON_RECT).collidepoint(mouse):
            self.desktop_launcher_open = not self.desktop_launcher_open
            return True
        if pygame.Rect(DESKTOP_VPN_RECT).collidepoint(mouse):
            if bool(self.call_state.get("threat_active")) and self.vpn_charges > 0:
                self._set_vpn_charges(self.vpn_charges - 1)
                self._resolve_threat_vpn_success()
            else:
                self._push_notification(
                    f"VPN charges: {self.vpn_charges}/{VPN_MAX_CHARGES}",
                    COLOR_SUCCESS if self.vpn_charges > 0 else COLOR_ERROR,
                )
            return True
        if mouse[1] < DESKTOP_TASKBAR_HEIGHT:
            self.desktop_launcher_open = False
            return True

        if self.desktop_launcher_open:
            for index, (app_id, _title, _symbol) in enumerate(DESKTOP_APPS):
                if self._launcher_item_rect(index).collidepoint(mouse):
                    self._open_desktop_window(app_id)
                    self.desktop_launcher_open = False
                    return True
            for index, (game_id, _title, _symbol) in enumerate(MINIGAME_ENTRIES):
                if self._launcher_minigame_rect(index).collidepoint(mouse):
                    self._prepare_hack(game_id)
                    return True
            if pygame.Rect(DESKTOP_LAUNCHER_DIFFICULTY_RECT).collidepoint(mouse):
                self.difficulty = (
                    self.difficulty % MINIGAME_DIFFICULTY_MAX
                ) + MINIGAME_DIFFICULTY_MIN
                self._push_notification(
                    f"Сложность мини-игр: {self.difficulty}",
                    COLOR_HOT_ACCENT,
                )
                return True
            if pygame.Rect(DESKTOP_LAUNCHER_HOME_RECT).collidepoint(mouse):
                self._change_state(STATE_MENU)
                return True
            if pygame.Rect(DESKTOP_LAUNCHER_RECT).collidepoint(mouse):
                return True
            self.desktop_launcher_open = False

        for window in reversed(self.desktop_windows):
            if window.minimized or not window.rect.collidepoint(mouse):
                continue
            self._bring_window_to_front(window)
            for action, control_rect in self._window_control_rects(window).items():
                if control_rect.collidepoint(mouse):
                    self._handle_window_control(action, window)
                    return True
            if not window.maximized and self._window_title_rect(window).collidepoint(
                mouse
            ):
                self.dragged_window = window
                self.drag_offset.update(
                    mouse[0] - window.rect.x,
                    mouse[1] - window.rect.y,
                )
            elif window.app_id == MESSENGER_APP_ID:
                self._handle_messenger_click(window, mouse)
            elif window.app_id == BROWSER_APP_ID:
                self._handle_browser_click(window, mouse)
            elif window.app_id == DARKNET_APP_ID:
                self._handle_darknet_click(window, mouse)
            elif window.app_id == TERMINAL_APP_ID:
                self._handle_skill_tree_click(window, mouse)
            elif window.app_id == MUSIC_PLAYER_APP_ID:
                self._handle_music_player_click(window, mouse)
            elif window.app_id == MINER_MANAGER_APP_ID and self._miner_withdraw_rect(
                window
            ).collidepoint(mouse):
                self._withdraw_miner_income()
            return True

        for index, (app_id, _title, _symbol) in enumerate(DESKTOP_APPS):
            if self._desktop_icon_hit_rect(index).collidepoint(mouse):
                self._open_desktop_window(app_id)
                return True
        return True

    def _available_hack_tools(
        self,
        game_id: str,
        hack_context: dict[str, object] | None,
    ) -> list[dict[str, object]]:
        product_ids: list[str] = []
        exploit_id = EXPLOIT_FOR_MINIGAME.get(game_id)
        if exploit_id is not None and self.inventory.get(exploit_id, 0) > 0:
            product_ids.append(exploit_id)
        if (
            game_id == "social_engineering"
            and self.inventory.get("fake_documents", 0) > 0
        ):
            product_ids.append("fake_documents")
        if (
            hack_context is not None
            and hack_context.get("target_type") == "Обычный ПК"
            and self.inventory.get("botnet_pc", 0) > 0
        ):
            product_ids.insert(0, "botnet_pc")
        return [
            product
            for product_id in product_ids
            if (product := self._darknet_product(product_id)) is not None
        ]

    def _prepare_hack(
        self,
        game_id: str,
        *,
        hack_context: dict[str, object] | None = None,
        difficulty_override: int | None = None,
    ) -> None:
        game_difficulty = min(
            MINIGAME_DIFFICULTY_MAX,
            max(
                MINIGAME_DIFFICULTY_MIN,
                self.difficulty
                if difficulty_override is None
                else int(difficulty_override),
            ),
        )
        if not self._available_hack_tools(game_id, hack_context):
            self._start_minigame(
                game_id,
                order_context=(
                    hack_context
                    if hack_context is not None
                    and hack_context.get("source") == "order"
                    else None
                ),
                hack_context=hack_context,
                difficulty_override=game_difficulty,
            )
            return
        self.pending_hack_launch = {
            "game_id": game_id,
            "difficulty": game_difficulty,
            "context": hack_context,
        }
        self.selected_hack_tools = set()
        self._change_state(STATE_HACK_PREP)

    def _hack_prep_products(self) -> list[dict[str, object]]:
        if self.pending_hack_launch is None:
            return []
        context = self.pending_hack_launch.get("context")
        return self._available_hack_tools(
            str(self.pending_hack_launch["game_id"]),
            context if isinstance(context, dict) else None,
        )

    def _toggle_hack_tool(self, product_id: str) -> None:
        if product_id in self.selected_hack_tools:
            self.selected_hack_tools.remove(product_id)
            return
        if product_id == "botnet_pc":
            self.selected_hack_tools = {product_id}
        else:
            self.selected_hack_tools.discard("botnet_pc")
            self.selected_hack_tools.add(product_id)

    def _launch_prepared_hack(self) -> None:
        launch = self.pending_hack_launch
        if launch is None:
            self._change_state(STATE_DESKTOP)
            return
        game_id = str(launch["game_id"])
        difficulty_value = int(launch["difficulty"])
        context_value = launch.get("context")
        context = context_value if isinstance(context_value, dict) else None
        available_ids = {str(product["id"]) for product in self._hack_prep_products()}
        selected_tools = self.selected_hack_tools & available_ids

        if "botnet_pc" in selected_tools and context is not None:
            self._consume_inventory("botnet_pc")
            context["applied_tools"] = ("botnet_pc",)
            self.pending_hack_launch = None
            self.selected_hack_tools = set()
            self.pending_minigame_order = (
                context if context.get("source") == "order" else None
            )
            self.active_hack_context = context
            self.post_hack_mode = "actions"
            self.completed_hacks += 1
            order_reference = context.get("order")
            if (
                self.tutorial_active
                and isinstance(order_reference, dict)
                and bool(order_reference.get("is_tutorial"))
            ):
                self.tutorial_step = 4
            self._push_notification(
                "Ботнет выполнил авто-взлом ПК",
                COLOR_SUCCESS,
                sound_id="success",
            )
            self._change_state(STATE_POST_HACK)
            return

        consumed_tools = {
            product_id
            for product_id in selected_tools
            if self._consume_inventory(product_id)
        }
        self.pending_hack_launch = None
        self.selected_hack_tools = set()
        self._start_minigame(
            game_id,
            order_context=(
                context
                if context is not None and context.get("source") == "order"
                else None
            ),
            hack_context=context,
            difficulty_override=difficulty_value,
            applied_tools=consumed_tools,
        )

    def _cancel_prepared_hack(self) -> None:
        launch = self.pending_hack_launch
        context_value = launch.get("context") if launch is not None else None
        context = context_value if isinstance(context_value, dict) else None
        if context is not None and bool(context.get("is_hot_deal")):
            self._expire_hot_deal(
                accepted=True,
                message="⏱ Горячий заказ отменён и потерян.",
            )
            return
        resolved_order = False
        if context is not None and context.get("source") == "order":
            order_reference = context.get("order")
            customer_value = context.get("customer")
            customer = str(customer_value) if customer_value is not None else None
            if isinstance(order_reference, dict):
                order_reference["status"] = "aborted"
                self._resolve_order_outcome(order_reference, "aborted")
                resolved_order = True
                if (
                    self.tutorial_active
                    and bool(order_reference.get("is_tutorial"))
                    and customer is not None
                ):
                    self.tutorial_step = 2
                    self._issue_order(customer)
                elif (
                    not self.story_finale_reached
                    and customer is not None
                    and self._story_order_due()
                ):
                    self._issue_due_story_order(customer)
            message = "Взлом цели прерван до запуска."
            if customer is not None:
                self._append_messenger_message(customer, "outgoing", message)
            self._push_notification(message, COLOR_ERROR, sound_id="failure")
        self.pending_hack_launch = None
        self.selected_hack_tools = set()
        self._update_browser_results()
        if resolved_order:
            self._save_game()
        if not self._show_story_finale_if_ready():
            self._change_state(STATE_DESKTOP)

    def _apply_hack_tools(
        self,
        minigame: MiniGameBase,
        applied_tools: set[str],
    ) -> None:
        if "lock_override" in applied_tools and isinstance(minigame, BruteForceLock):
            reduction = min(
                EXPLOIT_LOCK_RING_REDUCTION,
                max(0, minigame.ring_count - 1),
            )
            if reduction:
                del minigame.rings[-reduction:]
                minigame.ring_count = len(minigame.rings)
                minigame.selected_ring = min(
                    minigame.selected_ring,
                    minigame.ring_count - 1,
                )
            minigame.correct_zone_degrees *= EXPLOIT_LOCK_ZONE_MULTIPLIER

        if "firewall_bypass" in applied_tools and isinstance(minigame, FirewallMaze):
            for scanner in minigame.scanners:
                scanner["speed"] = (
                    float(scanner["speed"]) * EXPLOIT_FIREWALL_SPEED_MULTIPLIER
                )

        if "packet_filter" in applied_tools and isinstance(minigame, PacketSniffer):
            minigame.harmful_packet_multiplier = EXPLOIT_PACKET_HARMFUL_MULTIPLIER

        if "topology_solver" in applied_tools and isinstance(minigame, NetworkNodes):
            minigame.node_count = max(
                3,
                minigame.node_count - EXPLOIT_TOPOLOGY_NODE_REDUCTION,
            )
            minigame.edges = minigame._make_planar_edges()
            minigame.nodes = minigame._make_scrambled_nodes()
            minigame.intersecting_edges = minigame._find_intersecting_edges()

        if "traffic_amplifier" in applied_tools and isinstance(minigame, DDoSClicker):
            minigame.max_hp = max(
                1,
                math.ceil(minigame.max_hp * EXPLOIT_TRAFFIC_HP_MULTIPLIER),
            )
            minigame.hp = minigame.max_hp
            minigame.request_limit = max(
                DDOS_MAX_REQUESTS_PER_SECOND,
                math.ceil(
                    DDOS_MAX_REQUESTS_PER_SECOND
                    * EXPLOIT_TRAFFIC_REQUEST_LIMIT_MULTIPLIER
                ),
            )

        if "osint_dossier" in applied_tools and isinstance(minigame, SocialEngineering):
            simplified_dialogues: list[dict[str, object]] = []
            for dialogue in minigame.dialogues:
                cloned_dialogue = dict(dialogue)
                options_value = dialogue.get("options")
                options = (
                    [dict(option) for option in options_value]
                    if isinstance(options_value, list)
                    else []
                )
                wrong_index = next(
                    (
                        index
                        for index, option in enumerate(options)
                        if not bool(option.get("correct"))
                    ),
                    None,
                )
                if wrong_index is not None:
                    del options[wrong_index]
                cloned_dialogue["options"] = options
                simplified_dialogues.append(cloned_dialogue)
            minigame.dialogues = simplified_dialogues

        if "fake_documents" in applied_tools and isinstance(
            minigame, SocialEngineering
        ):
            minigame.trust = min(100, minigame.trust + FAKE_DOCUMENTS_TRUST_BONUS)
        minigame.active_tools = tuple(sorted(applied_tools))

    def _start_minigame(
        self,
        game_id: str,
        *,
        order_context: dict[str, object] | None = None,
        hack_context: dict[str, object] | None = None,
        difficulty_override: int | None = None,
        applied_tools: set[str] | None = None,
    ) -> None:
        game_difficulty = min(
            MINIGAME_DIFFICULTY_MAX,
            max(
                MINIGAME_DIFFICULTY_MIN,
                self.difficulty
                if difficulty_override is None
                else int(difficulty_override),
            ),
        )
        effective_context = hack_context or order_context
        if effective_context is not None:
            game_difficulty = self._effective_target_difficulty(game_difficulty)
        if game_id == "bruteforce_lock":
            self.active_minigame = BruteForceLock(game_difficulty)
            state = STATE_MINIGAME_LOCK
        elif game_id == "firewall_maze":
            self.active_minigame = FirewallMaze(game_difficulty)
            state = STATE_MINIGAME_FIREWALL
        elif game_id == "packet_sniffer":
            self.active_minigame = PacketSniffer(game_difficulty)
            state = STATE_MINIGAME_SNIFFER
        elif game_id == "network_nodes":
            self.active_minigame = NetworkNodes(game_difficulty)
            state = STATE_MINIGAME_NETWORK
        elif game_id == "ddos_clicker":
            self.active_minigame = DDoSClicker(game_difficulty)
            state = STATE_MINIGAME_DDOS
        elif game_id == "social_engineering":
            self.active_minigame = SocialEngineering(game_difficulty)
            state = STATE_MINIGAME_SOCIAL
        else:
            return
        active_tools = applied_tools or set()
        self._apply_hack_tools(self.active_minigame, active_tools)
        if effective_context is not None and self._has_skill("rapid_exploit"):
            self.active_minigame.time_left *= SKILL_HACK_TIME_MULTIPLIER
        if isinstance(self.active_minigame, SocialEngineering) and self._has_skill(
            "rapport"
        ):
            self.active_minigame.trust = min(
                100,
                self.active_minigame.trust + SKILL_SOCIAL_TRUST_BONUS,
            )
        self.pending_minigame_order = order_context
        self.active_hack_context = effective_context
        if self.active_hack_context is not None:
            self.active_hack_context["applied_tools"] = tuple(sorted(active_tools))
            self.active_hack_context["effective_difficulty"] = game_difficulty
        self.post_hack_mode = "actions"
        self._change_state(state)

    def _apply_intrusion_outcome(self, defense: IntrusionDefense) -> None:
        if defense.outcome_applied or not defense.finished:
            return
        defense.outcome_applied = True
        if defense.success:
            self.hacker_attacks_survived += 1
            self._push_notification(
                "Intrusion repelled!",
                COLOR_SUCCESS,
                sound_id="success",
            )
        else:
            self._change_balance(-INTRUSION_BTC_LOSS, "Провал защиты сервера")
            self._change_suspicion(
                INTRUSION_SUSPICION_PENALTY,
                "Сервер взломан во время Intrusion Defense",
            )
            self._push_notification(
                (
                    f"SERVER BREACHED: -{INTRUSION_BTC_LOSS:.2f} BTC, "
                    f"подозрение +{INTRUSION_SUSPICION_PENALTY:.0f}%"
                ),
                COLOR_ERROR,
                sound_id="failure",
            )

    def _finish_intrusion_defense(self, succeeded: bool) -> None:
        defense = self.active_minigame
        if isinstance(defense, IntrusionDefense):
            if not defense.finished:
                defense.finish(succeeded)
            self._apply_intrusion_outcome(defense)
        self.pending_minigame_order = None
        self.active_hack_context = None
        self.active_minigame = None
        self._schedule_next_hacker_attack()
        self._change_state(STATE_DESKTOP)

    def _leave_minigame(self, *, report_result: bool = False) -> None:
        minigame = self.active_minigame
        if isinstance(minigame, IntrusionDefense):
            succeeded = report_result and minigame.finished and minigame.success
            self._finish_intrusion_defense(succeeded)
            return
        game_succeeded = report_result and minigame is not None and minigame.success
        context = self.active_hack_context or self.pending_minigame_order
        if (
            context is not None
            and bool(context.get("is_hot_deal"))
            and not game_succeeded
        ):
            self._expire_hot_deal(
                accepted=True,
                message="⏱ Горячий заказ провален и потерян.",
            )
            return
        if context is not None and game_succeeded:
            self.completed_hacks += 1
            order_reference = context.get("order")
            if (
                self.tutorial_active
                and isinstance(order_reference, dict)
                and bool(order_reference.get("is_tutorial"))
            ):
                self.tutorial_step = 4
            self._play_sound("success")
            self.active_minigame = None
            self.post_hack_mode = "actions"
            self._change_state(STATE_POST_HACK)
            return

        if context is not None:
            if report_result:
                message = "Взлом цели провален. Доступ к действиям не получен."
                order_status = "failed"
            else:
                message = "Взлом цели прерван оператором."
                order_status = "aborted"
            order_reference = context.get("order")
            customer = context.get("customer")
            if isinstance(order_reference, dict):
                order_reference["status"] = order_status
                self._resolve_order_outcome(order_reference, order_status)
                if bool(context.get("order_pending")) and customer is not None:
                    active_order = self.messenger_active_orders.get(str(customer))
                    if active_order is order_reference:
                        self.messenger_active_orders[str(customer)] = None
                        self.messenger_orders_processed += 1
                        self._unlock_forum_if_needed()
                if not self.story_finale_reached and customer is not None:
                    self._issue_due_story_order(str(customer))
                if (
                    self.tutorial_active
                    and bool(order_reference.get("is_tutorial"))
                    and customer is not None
                ):
                    self.tutorial_step = 2
                    self._issue_order(str(customer))
            if customer is not None:
                self._append_messenger_message(str(customer), "outgoing", message)
            self._push_notification(
                message,
                COLOR_ERROR,
                sound_id="failure",
            )
            if isinstance(order_reference, dict):
                self._save_game()
        elif report_result and minigame is not None:
            result_text = (
                "Мини-игра завершена: успех"
                if minigame.success
                else "Мини-игра завершена: провал"
            )
            result_color = COLOR_SUCCESS if minigame.success else COLOR_ERROR
            self._push_notification(
                result_text,
                result_color,
                sound_id="success" if minigame.success else "failure",
            )
        self.pending_minigame_order = None
        self.active_hack_context = None
        self.active_minigame = None
        self._update_browser_results()
        if not self._show_story_finale_if_ready():
            self._change_state(STATE_DESKTOP)

    @staticmethod
    def _post_hack_action_rect(index: int) -> pygame.Rect:
        column = index % POST_HACK_BUTTON_COLUMNS
        row = index // POST_HACK_BUTTON_COLUMNS
        width, height = POST_HACK_BUTTON_SIZE
        start_x, start_y = POST_HACK_BUTTON_START
        return pygame.Rect(
            start_x + column * (width + POST_HACK_BUTTON_COLUMN_GAP),
            start_y + row * (height + POST_HACK_BUTTON_ROW_GAP),
            width,
            height,
        )

    @staticmethod
    def _post_hack_blackmail_rect(index: int) -> pygame.Rect:
        width, height = POST_HACK_BLACKMAIL_BUTTON_SIZE
        return pygame.Rect(
            POST_HACK_BLACKMAIL_BUTTON_START_X
            + index * (width + POST_HACK_BLACKMAIL_BUTTON_GAP),
            POST_HACK_BLACKMAIL_BUTTON_Y,
            width,
            height,
        )

    def _finish_post_hack(
        self,
        message: str,
        color: pygame.Color = COLOR_SUCCESS,
        *,
        delivered_order: bool = False,
    ) -> None:
        context = self.active_hack_context
        if (
            context is not None
            and bool(context.get("is_hot_deal"))
            and bool(self.hot_deal.get("active"))
        ):
            message = self._complete_hot_deal()
            color = COLOR_GOLD
            delivered_order = True
        order_reference = context.get("order") if context is not None else None
        resolved_order = isinstance(order_reference, dict)
        tutorial_order = resolved_order and bool(order_reference.get("is_tutorial"))
        if (
            context is not None
            and context.get("customer") is not None
            and not delivered_order
        ):
            customer = str(context["customer"])
            order_reference = context.get("order")
            if isinstance(order_reference, dict):
                order_reference["status"] = "closed_without_delivery"
                self._resolve_order_outcome(order_reference, "closed_without_delivery")
                if bool(context.get("order_pending")):
                    active_order = self.messenger_active_orders.get(customer)
                    if active_order is order_reference:
                        self.messenger_active_orders[customer] = None
                        self.messenger_orders_processed += 1
                        self._unlock_forum_if_needed()
                if not self.story_finale_reached:
                    self._issue_due_story_order(customer)
            self._append_messenger_message(
                customer,
                "outgoing",
                "Доступ получен, но информация заказчику не передана. Оплата отменена.",
            )
            if self.tutorial_active and tutorial_order:
                self.tutorial_step = 2
                self._issue_order(customer)
        self._push_notification(
            message,
            color,
            sound_id="failure" if color == COLOR_ERROR else "success",
        )
        self.pending_minigame_order = None
        self.active_hack_context = None
        self.post_hack_mode = "actions"
        self._update_browser_results()
        if resolved_order:
            self._save_game()
        if not self._show_story_finale_if_ready():
            self._change_state(STATE_DESKTOP)

    def _deliver_order_information(self) -> bool:
        context = self.active_hack_context
        if context is None:
            return False
        if bool(context.get("is_hot_deal")):
            message = self._complete_hot_deal()
            self._finish_post_hack(
                message,
                COLOR_GOLD,
                delivered_order=True,
            )
            return True
        customer_value = context.get("customer")
        reward_value = context.get("reward")
        order_id_value = context.get("order_id")
        if customer_value is None or reward_value is None or order_id_value is None:
            self._push_notification("Нет связанного заказа", COLOR_ERROR)
            return False

        customer = str(customer_value)
        order_id = int(order_id_value)
        if bool(context.get("order_pending")):
            active_order = self.messenger_active_orders.get(customer)
            if (
                active_order is None
                or int(active_order["id"]) != order_id
                or active_order.get("status") != "pending"
            ):
                self._push_notification("Связанный заказ уже закрыт", COLOR_ERROR)
                return False
            active_order["status"] = "completed"
            self.messenger_active_orders[customer] = None
            self.messenger_orders_processed += 1
            self._unlock_forum_if_needed()

        order_reference = context.get("order")
        if isinstance(order_reference, dict):
            order_reference["status"] = "completed"
            self._resolve_order_outcome(order_reference, "completed")
            if bool(order_reference.get("is_tutorial")):
                self.tutorial_active = False
                self.tutorial_completed = True
                self.tutorial_step = max(TUTORIAL_MESSAGES)
        if not self.story_finale_reached:
            self._issue_due_story_order(customer)
        reward = float(reward_value)
        self._change_balance(reward, f"Заказ #{order_id:03d}")
        message = (
            f"Информация передана. Награда ₿ {reward:.3f} и "
            f"+{SKILL_POINTS_PER_COMPLETED_ORDER} SP зачислены."
        )
        self._append_messenger_message(customer, "outgoing", message)
        self._finish_post_hack(message, COLOR_SUCCESS, delivered_order=True)
        return True

    def _apply_post_hack_action(self, action: str) -> None:
        context = self.active_hack_context
        if context is None:
            self._change_state(STATE_DESKTOP)
            return
        target_name = str(context.get("target", "неизвестная цель"))
        target_type = str(context.get("target_type", "Обычный ПК"))

        if action == "miner":
            miner_key = f"{target_type}:{target_name}"
            if any(str(miner["key"]) == miner_key for miner in self.miner_targets):
                message = f"Майнер {target_name} уже активен"
                color = COLOR_HOT_ACCENT
            else:
                self._play_sound("sfx_install")
                self.miner_targets.append(
                    {
                        "key": miner_key,
                        "name": target_name,
                        "target_type": target_type,
                        "rate": MINER_RATE_BTC_PER_MINUTE,
                        "added_at": self.total_elapsed,
                    }
                )
                used_payload = self._consume_inventory("malware_miner")
                if used_payload:
                    self.miner_pending_income += MALWARE_MINER_BOOTSTRAP_BTC
                    self.miner_earned_total += MALWARE_MINER_BOOTSTRAP_BTC
                payload_text = (
                    f"; payload +₿ {MALWARE_MINER_BOOTSTRAP_BTC:.3f}"
                    if used_payload
                    else ""
                )
                message = (
                    f"Майнер добавлен: {target_name} "
                    f"(+{MINER_RATE_BTC_PER_MINUTE:.3f} BTC/мин{payload_text})"
                )
                color = COLOR_SUCCESS
            self._finish_post_hack(message, color)
        elif action == "blackmail":
            self.post_hack_mode = "blackmail"
        elif action == "data_theft":
            used_spy = self._consume_inventory("malware_spy")
            if used_spy:
                self._play_sound("sfx_install")
            reward_minimum = (
                MALWARE_SPY_DATA_REWARD_MIN
                if used_spy
                else POST_HACK_DATA_REWARD_RANGE[0]
            )
            if self._has_skill("data_siphon"):
                reward_minimum = min(
                    POST_HACK_DATA_REWARD_RANGE[1],
                    reward_minimum + SKILL_DATA_REWARD_MIN_BONUS,
                )
            reward = round(
                self.order_random.uniform(
                    reward_minimum,
                    POST_HACK_DATA_REWARD_RANGE[1],
                ),
                3,
            )
            self._change_balance(reward, "Продажа данных")
            spy_text = " • использован Шпион" if used_spy else ""
            self._finish_post_hack(
                f"Данные проданы: +₿ {reward:.3f}{spy_text}",
                COLOR_SUCCESS,
            )
        elif action == "ransomware":
            used_ransomware = self._consume_inventory("malware_ransomware")
            self._play_sound("sfx_install")
            reward = self.order_random.uniform(*POST_HACK_RANSOM_REWARD_RANGE)
            if used_ransomware:
                reward *= MALWARE_RANSOM_REWARD_MULTIPLIER
            reward = round(reward, 3)
            self._change_balance(reward, "Выкуп шифровальщика")
            self._change_suspicion(
                POST_HACK_RANSOM_SUSPICION,
                "Сигнатура шифровальщика обнаружена следственной группой",
            )
            payload_text = " • усиленная малварь" if used_ransomware else ""
            self._finish_post_hack(
                (f"Выкуп получен: +₿ {reward:.3f}; подозрение +15%{payload_text}"),
                COLOR_ERROR,
            )
        elif action == "order_info":
            self._deliver_order_information()
        elif action == "proxy":
            added_charges = self._set_vpn_charges(self.vpn_charges + 1)
            self._resolve_threat_vpn_success()
            message = (
                f"Прокси настроен: заряды VPN {self.vpn_charges}"
                if added_charges > 0
                else f"VPN уже заряжен: {VPN_MAX_CHARGES}/{VPN_MAX_CHARGES}"
            )
            self._finish_post_hack(message, COLOR_SUCCESS)

    def _apply_blackmail_tone(self, tone_id: str) -> None:
        tone = POST_HACK_BLACKMAIL_TONES[tone_id]
        used_keylogger = self._consume_inventory("malware_keylogger")
        if used_keylogger:
            self._play_sound("sfx_install")
        chance = float(tone["chance"]) + (
            MALWARE_KEYLOGGER_CHANCE_BONUS if used_keylogger else 0.0
        )
        chance = min(1.0, chance)
        keylogger_text = " • использован Кейлоггер" if used_keylogger else ""
        self._change_suspicion(
            float(tone["suspicion"]),
            f"Шантаж уровня «{tone['name']}» оставил цифровой след",
        )
        if self.order_random.random() <= chance:
            reward_range = tone["reward"]
            reward = round(
                self.order_random.uniform(
                    float(reward_range[0]),
                    float(reward_range[1]),
                ),
                3,
            )
            self._change_balance(reward, f"Шантаж: {tone['name']}")
            self._finish_post_hack(
                (f"Шантаж успешен ({tone['name']}): +₿ {reward:.3f}{keylogger_text}"),
                COLOR_SUCCESS,
            )
        else:
            self._finish_post_hack(
                (f"Шантаж провален ({tone['name']}): выплаты нет{keylogger_text}"),
                COLOR_ERROR,
            )

    def _handle_post_hack_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        mouse = self._desktop_point(event.pos)
        if self.post_hack_mode == "blackmail":
            for index, tone_id in enumerate(POST_HACK_BLACKMAIL_TONES):
                if self._post_hack_blackmail_rect(index).collidepoint(mouse):
                    self._apply_blackmail_tone(tone_id)
                    return
            if pygame.Rect(POST_HACK_BLACKMAIL_BACK_RECT).collidepoint(mouse):
                self.post_hack_mode = "actions"
            return

        for index, (action, _label, _description) in enumerate(POST_HACK_ACTIONS):
            if self._post_hack_action_rect(index).collidepoint(mouse):
                self._apply_post_hack_action(action)
                return

    def _apply_resolution(self, resolution_key: str) -> None:
        previous_key = self.current_resolution_key
        try:
            new_screen = self._create_display(resolution_key)
        except pygame.error:
            self.pending_resolution_key = previous_key
            self._sync_resolution_selection()
            self._set_status("Не удалось применить режим экрана", COLOR_ERROR)
            return

        if previous_key != FULLSCREEN_KEY:
            self.last_windowed_key = previous_key
        if resolution_key != FULLSCREEN_KEY:
            self.last_windowed_key = resolution_key
        self.screen = new_screen
        self.current_resolution_key = resolution_key
        self.pending_resolution_key = resolution_key
        self._refresh_geometry()
        self._rebuild_ui()
        self._set_status("Режим экрана применён", COLOR_SUCCESS)

    def _toggle_fullscreen(self) -> None:
        target = (
            self.last_windowed_key
            if self.current_resolution_key == FULLSCREEN_KEY
            else FULLSCREEN_KEY
        )
        self.pending_resolution_key = target
        self._apply_resolution(target)

    # ------------------------------------------------------------------
    # Обновление логики (фиксированный предел — 60 FPS)
    # ------------------------------------------------------------------

    def _update(self, delta_seconds: float) -> None:
        self.total_elapsed += delta_seconds
        self.state_elapsed += delta_seconds
        self.transition_remaining = max(
            0.0,
            self.transition_remaining - delta_seconds,
        )
        if self.state == STATE_GUIDES:
            maximum = self._guide_max_scroll()
            self.guide_scroll_target = min(
                maximum,
                max(0.0, self.guide_scroll_target),
            )
            interpolation = min(1.0, delta_seconds * GUIDES_SCROLL_INTERPOLATION_RATE)
            self.guide_scroll += (
                self.guide_scroll_target - self.guide_scroll
            ) * interpolation
        if self.status_time_left > 0.0:
            self.status_time_left = max(0.0, self.status_time_left - delta_seconds)
        if (
            self.has_active_session
            and self.suspicion >= SUSPICION_MAX
            and not self.arrested
        ):
            self._change_suspicion(0.0, "Шкала подозрения достигла 100%")
        self._update_desktop_timers(delta_seconds)
        self._update_live_events(delta_seconds)

        if self.state == STATE_CRT and self.state_elapsed >= CRT_DURATION_SECONDS:
            self._change_state(STATE_BOOT)
        elif self.state == STATE_BOOT and self.state_elapsed >= BOOT_DURATION_SECONDS:
            self._change_state(STATE_LOGO)
        elif self.state == STATE_LOGO and self.state_elapsed >= LOGO_DURATION_SECONDS:
            self._change_state(STATE_MENU)
        elif self.state == STATE_DESKTOP:
            self.desktop_session_elapsed += delta_seconds
        elif self.state in MINIGAME_STATES and self.active_minigame is not None:
            self.active_minigame.update(delta_seconds)
            if isinstance(self.active_minigame, IntrusionDefense):
                self._apply_intrusion_outcome(self.active_minigame)

        self.manager.update(delta_seconds)
        self._update_audio(delta_seconds)

    # ------------------------------------------------------------------
    # Программная отрисовка
    # ------------------------------------------------------------------

    def _draw_minigame_frame(self, title: str, time_left: float) -> None:
        self.screen.fill(COLOR_BACKGROUND)
        line_width = self._s(GRID_LINE_THICKNESS)
        for x in range(0, DESIGN_WIDTH + GRID_CELL_SIZE, GRID_CELL_SIZE):
            px, py = self._point((x, MINIGAME_HEADER_HEIGHT))
            pygame.draw.rect(
                self.screen,
                COLOR_PANEL,
                pygame.Rect(
                    px,
                    py,
                    line_width,
                    self._s(DESIGN_HEIGHT - MINIGAME_HEADER_HEIGHT),
                ),
            )
        for y in range(MINIGAME_HEADER_HEIGHT, DESIGN_HEIGHT, GRID_CELL_SIZE):
            px, py = self._point((0, y))
            pygame.draw.rect(
                self.screen,
                COLOR_PANEL,
                pygame.Rect(px, py, self._s(DESIGN_WIDTH), line_width),
            )
        pygame.draw.rect(
            self.screen,
            COLOR_TASKBAR,
            self._rect((0, 0, DESIGN_WIDTH, MINIGAME_HEADER_HEIGHT)),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            self._rect(
                (
                    0,
                    MINIGAME_HEADER_HEIGHT - THIN_LINE_WIDTH,
                    DESIGN_WIDTH,
                    THIN_LINE_WIDTH,
                )
            ),
        )

        back_rect = pygame.Rect(MINIGAME_BACK_RECT)
        mouse = self._desktop_point(pygame.mouse.get_pos())
        pygame.draw.rect(
            self.screen,
            COLOR_HOT_ACCENT if back_rect.collidepoint(mouse) else COLOR_ACCENT,
            self._window_rect(back_rect),
            border_radius=self._s(BUTTON_CORNER_RADIUS),
        )
        self._draw_text(
            "Назад",
            back_rect.center,
            MINIGAME_BACK_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        self._draw_text(
            title,
            MINIGAME_TITLE_CENTER,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        seconds_total = max(0, math.ceil(time_left))
        minutes, seconds = divmod(seconds_total, 60)
        self._draw_text(
            f"ТАЙМЕР {minutes:02d}:{seconds:02d}",
            MINIGAME_TIMER_CENTER,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_ERROR if seconds_total <= 10 else COLOR_SUCCESS,
            center=True,
            bold=True,
        )
        self._draw_text(
            (
                f"СЛОЖНОСТЬ "
                f"{self.active_minigame.difficulty if self.active_minigame else self.difficulty}/5"
            ),
            MINIGAME_DIFFICULTY_RIGHT_POS,
            MINIGAME_INFO_FONT_SIZE,
            COLOR_HOT_ACCENT,
            right=True,
            bold=True,
        )

    def _draw_minigame_result(
        self,
        success: bool,
        detail: str | None = None,
    ) -> None:
        panel = self._rect(MINIGAME_RESULT_PANEL_RECT)
        result_color = COLOR_SUCCESS if success else COLOR_ERROR
        pygame.draw.rect(
            self.screen,
            COLOR_TASKBAR,
            panel,
            border_radius=self._s(MINIGAME_RESULT_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            result_color,
            panel,
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(MINIGAME_RESULT_CORNER_RADIUS),
        )
        self._draw_text(
            "Успех!" if success else "Провал",
            MINIGAME_RESULT_TITLE_CENTER,
            MINIGAME_RESULT_TITLE_FONT_SIZE,
            result_color,
            center=True,
            bold=True,
        )
        result_detail = detail
        if result_detail is None:
            result_detail = "Операция завершена" if success else "Операция прервана"
        self._draw_text(
            result_detail,
            MINIGAME_RESULT_TEXT_CENTER,
            MINIGAME_RESULT_TEXT_FONT_SIZE,
            COLOR_TEXT,
            center=True,
        )
        ok_rect = pygame.Rect(MINIGAME_RESULT_OK_RECT)
        mouse = self._desktop_point(pygame.mouse.get_pos())
        pygame.draw.rect(
            self.screen,
            result_color if ok_rect.collidepoint(mouse) else COLOR_ACCENT,
            self._window_rect(ok_rect),
            border_radius=self._s(BUTTON_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            result_color,
            self._window_rect(ok_rect),
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(BUTTON_CORNER_RADIUS),
        )
        self._draw_text(
            "ОК",
            ok_rect.center,
            MINIGAME_BACK_FONT_SIZE,
            COLOR_BACKGROUND if ok_rect.collidepoint(mouse) else COLOR_TEXT,
            center=True,
            bold=True,
        )

    def _draw_background(self, *, grid: bool = True) -> None:
        self.screen.fill(COLOR_BACKGROUND)
        if grid:
            grid_width = self._s(GRID_LINE_THICKNESS)
            for x in range(0, DESIGN_WIDTH + GRID_CELL_SIZE, GRID_CELL_SIZE):
                px, py = self._point((x, 0))
                pygame.draw.rect(
                    self.screen,
                    COLOR_PANEL,
                    pygame.Rect(px, py, grid_width, self._s(DESIGN_HEIGHT)),
                )
            for y in range(0, DESIGN_HEIGHT + GRID_CELL_SIZE, GRID_CELL_SIZE):
                px, py = self._point((0, y))
                pygame.draw.rect(
                    self.screen,
                    COLOR_PANEL,
                    pygame.Rect(px, py, self._s(DESIGN_WIDTH), grid_width),
                )

        top_bar = self._rect((0, 0, DESIGN_WIDTH, TOP_STATUS_BAR_HEIGHT))
        bottom_bar = self._rect(
            (
                0,
                DESIGN_HEIGHT - BOTTOM_STATUS_BAR_HEIGHT,
                DESIGN_WIDTH,
                BOTTOM_STATUS_BAR_HEIGHT,
            )
        )
        pygame.draw.rect(self.screen, COLOR_PANEL, top_bar)
        pygame.draw.rect(self.screen, COLOR_PANEL, bottom_bar)
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            pygame.Rect(
                top_bar.left,
                top_bar.bottom - self._s(THIN_LINE_WIDTH),
                top_bar.width,
                self._s(THIN_LINE_WIDTH),
            ),
        )

        for x, y in DECOR_BLOCK_POSITIONS:
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT,
                self._rect((x, y, DECOR_BLOCK_SIZE[0], DECOR_BLOCK_SIZE[1])),
                border_radius=self._s(DECOR_BLOCK_SIZE[1]),
            )
        for x, y in DECOR_CIRCLE_POSITIONS:
            pygame.draw.circle(
                self.screen,
                COLOR_SUCCESS,
                self._point((x, y)),
                self._s(DECOR_CIRCLE_RADIUS),
            )

        self._draw_text(
            "ZERO KERNEL // LOCAL MODE",
            TOP_STATUS_LEFT_POS,
            FONT_SIZE_SMALL,
            COLOR_SUCCESS,
        )
        self._draw_text(
            f"{self.window_width}×{self.window_height} // {FPS} FPS",
            TOP_STATUS_RIGHT_POS,
            FONT_SIZE_SMALL,
            COLOR_TEXT,
            right=True,
        )

    def _draw_crt_intro(self) -> None:
        self.screen.fill(COLOR_BACKGROUND)
        elapsed = min(self.state_elapsed, CRT_DURATION_SECONDS)
        line_end = CRT_DURATION_SECONDS * CRT_LINE_PHASE_RATIO
        center_x, center_y = self._point((DESIGN_WIDTH / 2, DESIGN_HEIGHT / 2))

        if elapsed <= line_end:
            progress = self._ease_out(elapsed / line_end)
            line_width = self._s(CRT_LINE_MAX_WIDTH * progress)
            line_rect = pygame.Rect(
                center_x - line_width // 2,
                center_y - self._s(CRT_LINE_HEIGHT) // 2,
                line_width,
                self._s(CRT_LINE_HEIGHT),
            )
            glow_width = max(self._s(CRT_LINE_HEIGHT), line_width // 3)
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT,
                pygame.Rect(
                    center_x - glow_width // 2,
                    center_y - self._s(CRT_GLOW_HEIGHT) // 2,
                    glow_width,
                    self._s(CRT_GLOW_HEIGHT),
                ),
                border_radius=self._s(CRT_GLOW_HEIGHT),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_TEXT,
                line_rect,
                border_radius=self._s(CRT_LINE_HEIGHT),
            )
            return

        expansion = self._ease_out(
            (elapsed - line_end) / max(0.001, CRT_DURATION_SECONDS - line_end)
        )
        reveal_height = max(
            self._s(CRT_LINE_HEIGHT), self._s(DESIGN_HEIGHT * expansion)
        )
        reveal_rect = pygame.Rect(
            self.canvas_offset_x + self._s(CRT_REVEAL_SIDE_MARGIN),
            center_y - reveal_height // 2,
            self._s(DESIGN_WIDTH - CRT_REVEAL_SIDE_MARGIN * 2),
            reveal_height,
        )
        pygame.draw.rect(self.screen, COLOR_PANEL, reveal_rect)
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            reveal_rect,
            width=self._s(BORDER_WIDTH),
        )
        for y in range(reveal_rect.top, reveal_rect.bottom, self._s(SCANLINE_GAP)):
            pygame.draw.rect(
                self.screen,
                COLOR_BACKGROUND,
                pygame.Rect(
                    reveal_rect.left,
                    y,
                    reveal_rect.width,
                    self._s(THIN_LINE_WIDTH),
                ),
            )
        pygame.draw.rect(
            self.screen,
            COLOR_TEXT,
            pygame.Rect(
                reveal_rect.left,
                center_y - self._s(CRT_LINE_HEIGHT) // 2,
                reveal_rect.width,
                self._s(CRT_LINE_HEIGHT),
            ),
        )

    def _draw_boot(self) -> None:
        self._draw_background(grid=False)
        panel = self._rect(BOOT_PANEL_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_PANEL,
            panel,
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            panel,
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(self.screen, COLOR_ACCENT, self._rect(BOOT_HEADER_RECT))
        self._draw_text(
            "ZERO KERNEL v0.0.1 // BOOT SEQUENCE",
            BOOT_TITLE_POS,
            FONT_SIZE_BODY,
            COLOR_TEXT,
            bold=True,
        )

        progress = min(1.0, self.state_elapsed / BOOT_DURATION_SECONDS)
        visible_lines = min(len(BOOT_LINES), math.ceil(progress * len(BOOT_LINES)))
        for index, line in enumerate(BOOT_LINES[:visible_lines]):
            y = BOOT_LINES_START_Y + index * BOOT_LINES_GAP
            prefix, ok = line.rsplit(" ", maxsplit=1)
            prefix_rect = self._draw_text(
                f"> {prefix} ",
                (BOOT_LINES_X, y),
                FONT_SIZE_BODY,
                COLOR_TEXT,
            )
            ok_image = self._font(FONT_SIZE_BODY, True).render(ok, True, COLOR_SUCCESS)
            self.screen.blit(ok_image, (prefix_rect.right, prefix_rect.top))

        progress_rect = self._rect(BOOT_PROGRESS_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_BACKGROUND,
            progress_rect,
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            progress_rect,
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        inset = self._s(BOOT_PROGRESS_INSET)
        inner_width = max(0, progress_rect.width - inset * 2)
        filled_width = round(inner_width * progress)
        if filled_width > 0:
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT if progress < 1.0 else COLOR_SUCCESS,
                pygame.Rect(
                    progress_rect.left + inset,
                    progress_rect.top + inset,
                    filled_width,
                    max(1, progress_rect.height - inset * 2),
                ),
                border_radius=self._s(PANEL_CORNER_RADIUS),
            )
        self._draw_text(
            f"SYSTEM LOAD {round(progress * 100):03d}%",
            (DESIGN_WIDTH / 2, BOOT_PERCENT_Y),
            FONT_SIZE_SMALL,
            COLOR_SUCCESS if progress >= 1.0 else COLOR_TEXT,
            center=True,
        )
        self._draw_text(
            "SPACE — пропустить загрузку",
            (DESIGN_WIDTH / 2, BOOT_HINT_Y),
            FONT_SIZE_TINY,
            COLOR_ACCENT,
            center=True,
        )

    def _draw_logo(self) -> None:
        self._draw_background(grid=True)
        title = "ZERO DAY"
        font = self._font(FONT_SIZE_LOGO, True)
        glyphs = [font.render(character, True, COLOR_TEXT) for character in title]
        total_width = sum(glyph.get_width() for glyph in glyphs)
        total_width += self._s(LOGO_TRACKING) * (len(glyphs) - 1)
        x = self._point((DESIGN_WIDTH / 2, 0))[0] - total_width // 2
        center_y = self._point((0, LOGO_CENTER_Y))[1]

        within_cycle = self.state_elapsed % GLITCH_CYCLE_SECONDS
        cycle_index = int(self.state_elapsed / GLITCH_CYCLE_SECONDS)
        glitch_active = within_cycle < GLITCH_HOLD_SECONDS
        if glitch_active and cycle_index != self.glitch_cycle_index:
            self.glitch_cycle_index = cycle_index
            self.glitch_offsets = []
            for _character in title:
                # Смещение намеренно не масштабируется: эффект всегда равен 2–3 px.
                magnitude = self.random.randint(GLITCH_OFFSET_MIN, GLITCH_OFFSET_MAX)
                self.glitch_offsets.append(
                    (
                        self.random.choice((-magnitude, magnitude)),
                        self.random.choice((-magnitude, magnitude)),
                    )
                )

        for index, (character, glyph) in enumerate(zip(title, glyphs)):
            base_y = center_y - glyph.get_height() // 2
            offset_x, offset_y = (0, 0)
            if glitch_active and index < len(self.glitch_offsets) and character != " ":
                offset_x, offset_y = self.glitch_offsets[index]
                hot_ghost = font.render(character, True, COLOR_HOT_ACCENT)
                cool_ghost = font.render(character, True, COLOR_ACCENT)
                self.screen.blit(hot_ghost, (x - offset_x, base_y))
                self.screen.blit(cool_ghost, (x + offset_x, base_y - offset_y))
            self.screen.blit(glyph, (x + offset_x, base_y + offset_y))
            x += glyph.get_width() + self._s(LOGO_TRACKING)

        self._draw_text(
            "NO PATCH. NO TRACE. NO SECOND CHANCE.",
            (DESIGN_WIDTH / 2, LOGO_SUBTITLE_Y),
            FONT_SIZE_BODY,
            COLOR_HOT_ACCENT,
            center=True,
            bold=True,
        )
        self._draw_text(
            "SPACE — продолжить",
            (DESIGN_WIDTH / 2, LOGO_SKIP_TEXT_Y),
            FONT_SIZE_SMALL,
            COLOR_TEXT,
            center=True,
        )

    def _draw_menu(self) -> None:
        self._draw_background(grid=True)
        self._draw_text(
            "ZERO DAY",
            (DESIGN_WIDTH / 2, MENU_TITLE_Y),
            FONT_SIZE_TITLE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        self._draw_text(
            "OFFLINE SECURITY SIMULATION // BUILD 00",
            (DESIGN_WIDTH / 2, MENU_SUBTITLE_Y),
            FONT_SIZE_SMALL,
            COLOR_HOT_ACCENT,
            center=True,
        )
        if self.status_time_left > 0.0:
            self._draw_text(
                self.status_message,
                (DESIGN_WIDTH / 2, MENU_STATUS_Y),
                FONT_SIZE_SMALL,
                self.status_color,
                center=True,
            )
        elif not self.has_active_session:
            menu_status = (
                f"Найдено сохранений: {len(self.save_slot_paths)} • нажмите «Продолжить»"
                if self.save_slot_paths
                else "Продолжение станет доступно после запуска новой игры"
            )
            self._draw_text(
                menu_status,
                (DESIGN_WIDTH / 2, MENU_STATUS_Y),
                FONT_SIZE_SMALL,
                COLOR_SUCCESS if self.save_slot_paths else COLOR_ACCENT,
                center=True,
            )
        self._draw_text(
            "F11 — полный экран  •  ESC — выход",
            (DESIGN_WIDTH / 2, MENU_FOOTER_Y),
            FONT_SIZE_TINY,
            COLOR_TEXT,
            center=True,
        )

    def _draw_settings_slider(
        self,
        slider_rect: tuple[int, int, int, int],
        value: float,
        *,
        enabled: bool,
    ) -> None:
        logical_rect = pygame.Rect(slider_rect)
        color = COLOR_SUCCESS if enabled else COLOR_ACCENT
        pygame.draw.rect(
            self.screen,
            COLOR_TASKBAR,
            self._rect(slider_rect),
            border_radius=self._s(SETTINGS_SLIDER_HEIGHT // 2),
        )
        filled_width = max(1, round(logical_rect.width * value))
        pygame.draw.rect(
            self.screen,
            color,
            self._rect(
                (
                    logical_rect.x,
                    logical_rect.y,
                    filled_width,
                    logical_rect.height,
                )
            ),
            border_radius=self._s(SETTINGS_SLIDER_HEIGHT // 2),
        )
        knob_center = (
            logical_rect.x + round(logical_rect.width * value),
            logical_rect.centery,
        )
        pygame.draw.circle(
            self.screen,
            COLOR_TEXT if enabled else COLOR_ACCENT,
            self._point(knob_center),
            self._s(SETTINGS_SLIDER_KNOB_RADIUS),
        )

    def _draw_settings(self) -> None:
        self._draw_background(grid=True)
        panel = self._rect(SETTINGS_PANEL_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_PANEL,
            panel,
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            panel,
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        self._draw_text(
            "НАСТРОЙКИ",
            (DESIGN_WIDTH / 2, SETTINGS_TITLE_Y),
            FONT_SIZE_HEADING,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        self._draw_text(
            "Выберите разрешение экрана",
            (DESIGN_WIDTH / 2, SETTINGS_SUBTITLE_Y),
            FONT_SIZE_SMALL,
            COLOR_HOT_ACCENT,
            center=True,
        )
        if self.audio_manager.available and self.audio_manager.mixer_config is not None:
            mixer_frequency, _mixer_format, mixer_channels = self.audio_manager.mixer_config
            channel_label = "STEREO" if mixer_channels == 2 else "MONO COMPAT"
            audio_heading = (
                f"АУДИО // {mixer_frequency} HZ // {channel_label} // READY"
            )
            audio_heading_color = (
                COLOR_HOT_ACCENT if self.audio_manager.compatibility_mode else COLOR_SUCCESS
            )
        else:
            audio_heading = "АУДИО // НЕДОСТУПНО // R — ПОВТОРИТЬ"
            audio_heading_color = COLOR_ERROR
        self._draw_text(
            audio_heading,
            (DESIGN_WIDTH / 2, SETTINGS_AUDIO_TITLE_Y),
            FONT_SIZE_SMALL,
            audio_heading_color,
            center=True,
            bold=True,
        )
        self._draw_text(
            "Громкость музыки",
            (SETTINGS_SLIDER_LABEL_X, SETTINGS_MUSIC_LABEL_Y),
            FONT_SIZE_TINY,
            COLOR_TEXT,
            bold=True,
        )
        self._draw_text(
            f"{round(self.audio_manager.music_volume * 100)}%",
            (SETTINGS_SLIDER_VALUE_X, SETTINGS_MUSIC_LABEL_Y),
            FONT_SIZE_TINY,
            COLOR_SUCCESS if self.audio_manager.music_enabled else COLOR_ACCENT,
            right=True,
            bold=True,
        )
        self._draw_settings_slider(
            SETTINGS_MUSIC_SLIDER_RECT,
            self.audio_manager.music_volume,
            enabled=self.audio_manager.music_enabled and self.audio_manager.available,
        )
        self._draw_text(
            "Громкость эффектов",
            (SETTINGS_SLIDER_LABEL_X, SETTINGS_SFX_LABEL_Y),
            FONT_SIZE_TINY,
            COLOR_TEXT,
            bold=True,
        )
        self._draw_text(
            f"{round(self.audio_manager.sfx_volume * 100)}%",
            (SETTINGS_SLIDER_VALUE_X, SETTINGS_SFX_LABEL_Y),
            FONT_SIZE_TINY,
            COLOR_SUCCESS if self.audio_manager.effects_enabled else COLOR_ACCENT,
            right=True,
            bold=True,
        )
        self._draw_settings_slider(
            SETTINGS_SFX_SLIDER_RECT,
            self.audio_manager.sfx_volume,
            enabled=self.audio_manager.effects_enabled and self.audio_manager.available,
        )
        if self.status_time_left > 0.0:
            help_text = self.status_message
            help_color = self.status_color
        elif self.audio_manager.available:
            help_text = (
                "Режим совместимости активен • ползунки работают нормально"
                if self.audio_manager.compatibility_mode
                else "Ползунки регулируются кликом или перетаскиванием • ESC — отмена"
            )
            help_color = COLOR_TEXT
        else:
            help_text = f"R — повторить запуск аудио • {self.audio_manager.error}"
            help_color = COLOR_ERROR
        help_text = self._fit_text(
            help_text,
            self._font(FONT_SIZE_TINY),
            self._s(SETTINGS_PANEL_RECT[2] - SCREEN_EDGE_MARGIN * 2),
        )
        self._draw_text(
            help_text,
            (DESIGN_WIDTH / 2, SETTINGS_HELP_Y),
            FONT_SIZE_TINY,
            help_color,
            center=True,
        )

    def _draw_guides(self) -> None:
        self._draw_background(grid=True)
        panel = self._rect(GUIDES_PANEL_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_PANEL,
            panel,
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            panel,
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        self._draw_text(
            "ГАЙДЫ // БАЗА ЗНАНИЙ",
            GUIDES_TITLE_POS,
            FONT_SIZE_HEADING,
            COLOR_TEXT,
            bold=True,
        )
        self._draw_text(
            "6 разделов • колесо / ↑↓ для прокрутки",
            (
                GUIDES_TITLE_POS[0] + GUIDES_HEADER_META_OFFSET[0],
                GUIDES_TITLE_POS[1] + GUIDES_HEADER_META_OFFSET[1],
            ),
            FONT_SIZE_TINY,
            COLOR_HOT_ACCENT,
        )

        mouse = self._desktop_point(pygame.mouse.get_pos())
        nav = pygame.Rect(GUIDES_NAV_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_BACKGROUND,
            self._rect(tuple(nav)),
            border_radius=self._s(BUTTON_CORNER_RADIUS),
        )
        for section_index, section in enumerate(GUIDE_SECTIONS):
            row = pygame.Rect(
                nav.x,
                nav.y
                + section_index * (GUIDES_SECTION_ROW_HEIGHT + GUIDES_SECTION_ROW_GAP),
                nav.width,
                GUIDES_SECTION_ROW_HEIGHT,
            )
            selected = section_index == self.guide_section_index
            hovered = row.collidepoint(mouse)
            fill = (
                COLOR_ACCENT
                if selected
                else COLOR_PANEL
                if hovered
                else COLOR_BACKGROUND
            )
            border = (
                COLOR_SUCCESS
                if selected
                else COLOR_HOT_ACCENT
                if hovered
                else COLOR_ACCENT
            )
            pygame.draw.rect(
                self.screen,
                fill,
                self._rect(tuple(row)),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                border,
                self._rect(tuple(row)),
                width=self._s(BORDER_WIDTH + (1 if hovered else 0)),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
            title = str(section["title"])
            self._draw_text(
                title,
                (row.x + GUIDES_SECTION_PADDING, row.y + 17),
                GUIDES_SECTION_FONT_SIZE,
                COLOR_TEXT,
                bold=selected,
            )

        content = pygame.Rect(GUIDES_CONTENT_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_BACKGROUND,
            self._rect(tuple(content)),
            border_radius=self._s(BUTTON_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            self._rect(tuple(content)),
            width=self._s(THIN_LINE_WIDTH),
            border_radius=self._s(BUTTON_CORNER_RADIUS),
        )
        previous_clip = self.screen.get_clip()
        self.screen.set_clip(self._rect(tuple(content)))
        section = GUIDE_SECTIONS[self.guide_section_index]
        x = content.x + GUIDES_CONTENT_PADDING
        y = content.y + GUIDES_CONTENT_PADDING - self.guide_scroll
        self._draw_text(
            str(section["title"]),
            (x, y),
            GUIDES_PAGE_TITLE_FONT_SIZE,
            COLOR_SUCCESS,
            bold=True,
        )
        y += GUIDES_PAGE_TITLE_HEIGHT
        body_font = self._font(GUIDES_BODY_FONT_SIZE)
        text_width = self._s(
            content.width - GUIDES_CONTENT_PADDING * 2 - GUIDES_SCROLLBAR_WIDTH - 8
        )
        paragraphs_value = section.get("paragraphs", ())
        paragraphs = paragraphs_value if isinstance(paragraphs_value, tuple) else ()
        for paragraph in paragraphs:
            marker_y = y + GUIDES_MARKER_Y_OFFSET
            pygame.draw.circle(
                self.screen,
                COLOR_HOT_ACCENT,
                self._point((x + 4, marker_y)),
                self._s(GUIDES_MARKER_RADIUS),
            )
            lines = self._wrap_text(str(paragraph), body_font, text_width - self._s(20))
            for line in lines:
                self._draw_text(
                    line,
                    (x + GUIDES_MARKER_TEXT_OFFSET, y),
                    GUIDES_BODY_FONT_SIZE,
                    COLOR_TEXT,
                )
                y += GUIDES_TEXT_LINE_GAP
            y += GUIDES_PARAGRAPH_GAP
        self.screen.set_clip(previous_clip)

        maximum = self._guide_max_scroll()
        if maximum > 0:
            viewport = content.height - GUIDES_CONTENT_PADDING * 2
            total = self._guide_total_height(self.guide_section_index)
            track_x = content.right - GUIDES_CONTENT_PADDING
            track_y = content.y + GUIDES_CONTENT_PADDING
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT,
                self._rect(
                    (
                        track_x,
                        track_y,
                        GUIDES_SCROLLBAR_WIDTH,
                        viewport,
                    )
                ),
                border_radius=self._s(GUIDES_SCROLLBAR_WIDTH),
            )
            thumb_height = max(
                GUIDES_SCROLLBAR_MIN_THUMB,
                round(viewport * viewport / max(1, total)),
            )
            thumb_y = track_y + round(
                (viewport - thumb_height) * self.guide_scroll / maximum
            )
            pygame.draw.rect(
                self.screen,
                COLOR_SUCCESS,
                self._rect(
                    (
                        track_x,
                        thumb_y,
                        GUIDES_SCROLLBAR_WIDTH,
                        thumb_height,
                    )
                ),
                border_radius=self._s(GUIDES_SCROLLBAR_WIDTH),
            )

    @staticmethod
    def _format_save_timestamp(raw_value: object) -> str:
        try:
            parsed = datetime.fromisoformat(str(raw_value).replace("Z", "+00:00"))
            return parsed.astimezone().strftime("%d.%m.%Y  %H:%M")
        except ValueError:
            return "дата неизвестна"

    def _draw_saves(self) -> None:
        self._draw_background(grid=True)
        panel = self._rect(SAVE_MANAGER_PANEL_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_PANEL,
            panel,
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            panel,
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        self._draw_text(
            "СОХРАНЕНИЯ // JSON SLOTS",
            SAVE_MANAGER_TITLE_POS,
            FONT_SIZE_HEADING,
            COLOR_TEXT,
            bold=True,
        )
        self._draw_text(
            "save.json + неограниченные save1.json, save2.json…",
            (
                SAVE_MANAGER_TITLE_POS[0],
                SAVE_MANAGER_TITLE_POS[1] + SAVE_MANAGER_SUBTITLE_Y_OFFSET,
            ),
            FONT_SIZE_TINY,
            COLOR_HOT_ACCENT,
        )
        list_rect = pygame.Rect(SAVE_MANAGER_LIST_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_BACKGROUND,
            self._rect(tuple(list_rect)),
            border_radius=self._s(BUTTON_CORNER_RADIUS),
        )
        mouse = self._desktop_point(pygame.mouse.get_pos())
        if not self.save_slot_paths:
            self._draw_text(
                "Слотов пока нет. Начните игру или нажмите «Новый слот».",
                list_rect.center,
                FONT_SIZE_BODY,
                COLOR_ACCENT,
                center=True,
            )
        for visible_index in range(SAVE_MANAGER_VISIBLE_ROWS):
            slot_index = self.save_scroll_index + visible_index
            if slot_index >= len(self.save_slot_paths):
                break
            path = self.save_slot_paths[slot_index]
            row = pygame.Rect(
                list_rect.x,
                list_rect.y
                + visible_index * (SAVE_MANAGER_ROW_HEIGHT + SAVE_MANAGER_ROW_GAP),
                list_rect.width,
                SAVE_MANAGER_ROW_HEIGHT,
            )
            selected = slot_index == self.selected_save_index
            hovered = row.collidepoint(mouse)
            row_color = COLOR_PANEL if selected or hovered else COLOR_TASKBAR
            border_color = (
                COLOR_SUCCESS
                if selected
                else COLOR_HOT_ACCENT
                if hovered
                else COLOR_ACCENT
            )
            pygame.draw.rect(
                self.screen,
                row_color,
                self._rect(tuple(row)),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                border_color,
                self._rect(tuple(row)),
                width=self._s(BORDER_WIDTH + (1 if hovered else 0)),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
            current_marker = "  • ТЕКУЩИЙ" if path == self.current_save_path else ""
            self._draw_text(
                f"{path.name}{current_marker}",
                (
                    row.x + SAVE_MANAGER_ROW_PADDING,
                    row.y + SAVE_MANAGER_ROW_TITLE_Y_OFFSET,
                ),
                SAVE_MANAGER_FONT_SIZE,
                COLOR_SUCCESS if selected else COLOR_TEXT,
                bold=True,
            )
            metadata = self.save_slot_metadata.get(path, {"valid": False})
            if bool(metadata.get("valid")):
                details = (
                    f"{self._format_save_timestamp(metadata.get('saved_at'))}  •  "
                    f"₿ {float(metadata.get('balance', 0.0)):.3f}  •  "
                    f"REP {int(metadata.get('reputation', 0)):+d}  •  "
                    f"ORDERS {int(metadata.get('completed_orders', 0))}"
                )
                detail_color = COLOR_TEXT
            else:
                details = "ОШИБКА: файл повреждён или имеет неизвестный формат"
                detail_color = COLOR_ERROR
            self._draw_text(
                details,
                (
                    row.x + SAVE_MANAGER_ROW_PADDING,
                    row.y + SAVE_MANAGER_ROW_DETAILS_Y_OFFSET,
                ),
                SAVE_MANAGER_SMALL_FONT_SIZE,
                detail_color,
            )

        if len(self.save_slot_paths) > SAVE_MANAGER_VISIBLE_ROWS:
            track_x = (
                list_rect.right
                - SAVE_MANAGER_SCROLLBAR_WIDTH
                - SAVE_MANAGER_SCROLLBAR_MARGIN
            )
            track_height = list_rect.height - SAVE_MANAGER_SCROLLBAR_MARGIN * 2
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT,
                self._rect(
                    (
                        track_x,
                        list_rect.y + SAVE_MANAGER_SCROLLBAR_MARGIN,
                        SAVE_MANAGER_SCROLLBAR_WIDTH,
                        track_height,
                    )
                ),
                border_radius=self._s(SAVE_MANAGER_SCROLLBAR_WIDTH),
            )
            max_scroll = len(self.save_slot_paths) - SAVE_MANAGER_VISIBLE_ROWS
            thumb_height = max(
                SAVE_MANAGER_SCROLLBAR_MIN_THUMB,
                round(
                    track_height * SAVE_MANAGER_VISIBLE_ROWS / len(self.save_slot_paths)
                ),
            )
            thumb_y = (
                list_rect.y
                + 5
                + round(
                    (track_height - thumb_height)
                    * self.save_scroll_index
                    / max(1, max_scroll)
                )
            )
            pygame.draw.rect(
                self.screen,
                COLOR_SUCCESS,
                self._rect(
                    (
                        track_x,
                        thumb_y,
                        SAVE_MANAGER_SCROLLBAR_WIDTH,
                        thumb_height,
                    )
                ),
                border_radius=self._s(SAVE_MANAGER_SCROLLBAR_WIDTH),
            )
        if self.status_time_left > 0:
            self._draw_text(
                self.status_message,
                (DESIGN_WIDTH / 2, SAVE_MANAGER_STATUS_Y),
                FONT_SIZE_TINY,
                self.status_color,
                center=True,
            )

    def _draw_arrest(self) -> None:
        self.screen.fill(COLOR_TASKBAR)
        phase = int(self.state_elapsed / ARREST_LIGHT_FLASH_SECONDS)
        stripe_count = math.ceil(DESIGN_WIDTH / ARREST_LIGHT_STRIPE_WIDTH) + 1
        for row_y in (0, DESIGN_HEIGHT - ARREST_LIGHT_BAR_HEIGHT):
            for index in range(stripe_count):
                color = COLOR_ERROR if (index + phase) % 2 == 0 else COLOR_ACCENT
                pygame.draw.rect(
                    self.screen,
                    color,
                    self._rect(
                        (
                            index * ARREST_LIGHT_STRIPE_WIDTH,
                            row_y,
                            ARREST_LIGHT_STRIPE_WIDTH,
                            ARREST_LIGHT_BAR_HEIGHT,
                        )
                    ),
                )
        scanlines = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        for y in range(0, DESIGN_HEIGHT, ARREST_SCANLINE_GAP):
            pygame.draw.line(
                scanlines,
                (*COLOR_ERROR[:3], ARREST_SCANLINE_ALPHA),
                self._point((0, y)),
                self._point((DESIGN_WIDTH, y)),
                self._s(THIN_LINE_WIDTH),
            )
        self.screen.blit(scanlines, (0, 0))

        panel = self._rect(ARREST_PANEL_RECT)
        pulse_color = COLOR_ERROR if phase % 2 == 0 else COLOR_ACCENT
        pygame.draw.rect(
            self.screen,
            COLOR_BACKGROUND,
            panel,
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            pulse_color,
            panel,
            width=self._s(MESSENGER_ATTACK_BORDER_WIDTH),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        self._draw_text(
            "АРЕСТ // GAME OVER",
            ARREST_TITLE_CENTER,
            ARREST_TITLE_FONT_SIZE,
            COLOR_ERROR,
            center=True,
            bold=True,
        )
        self._draw_text(
            "УРОВЕНЬ ПОДОЗРЕНИЯ ДОСТИГ 100%",
            ARREST_SUBTITLE_CENTER,
            ARREST_SUBTITLE_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        reason = self._fit_text(
            self.arrest_reason or "Следственная группа локализовала терминал",
            self._font(ARREST_BODY_FONT_SIZE),
            self._s(ARREST_PANEL_RECT[2] - SCREEN_EDGE_MARGIN * 2),
        )
        self._draw_text(
            reason,
            ARREST_REASON_CENTER,
            ARREST_BODY_FONT_SIZE,
            COLOR_HOT_ACCENT,
            center=True,
        )
        self._draw_text(
            (
                f"Заказы: {self.completed_orders}/{self.messenger_orders_processed}  •  "
                f"Репутация: {self.messenger_reputation:+d}  •  "
                f"BTC: {self.btc_balance:.3f}"
            ),
            ARREST_STATS_CENTER,
            ARREST_BODY_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        self._draw_text(
            f"ПОПЫТКА {self.attempt_number} ЗАВЕРШЕНА  //  АРЕСТОВ: {self.total_arrests}",
            ARREST_ATTEMPT_CENTER,
            ARREST_BODY_FONT_SIZE,
            COLOR_SUCCESS,
            center=True,
            bold=True,
        )

    def _draw_story_finale(self) -> None:
        self._draw_background(grid=True)
        panel = self._rect(FINALE_PANEL_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_TASKBAR,
            panel,
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_HOT_ACCENT,
            panel,
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        ending_key = self.story_ending_key or self._determine_story_ending()
        ending = STORY_ENDINGS[ending_key]
        self._draw_text(
            "ВОЙНА ГРУППИРОВОК // ФИНАЛ",
            FINALE_TITLE_CENTER,
            FINALE_TITLE_FONT_SIZE,
            COLOR_SUCCESS,
            center=True,
            bold=True,
        )
        self._draw_text(
            str(ending["title"]),
            FINALE_ENDING_CENTER,
            FINALE_ENDING_FONT_SIZE,
            COLOR_HOT_ACCENT,
            center=True,
            bold=True,
        )
        description_lines = self._wrap_text(
            str(ending["description"]),
            self._font(FINALE_BODY_FONT_SIZE),
            self._s(FINALE_DESCRIPTION_MAX_WIDTH),
        )
        for index, line in enumerate(description_lines):
            self._draw_text(
                line,
                (
                    DESIGN_WIDTH // 2,
                    FINALE_DESCRIPTION_CENTER_Y + index * FINALE_DESCRIPTION_LINE_GAP,
                ),
                FINALE_BODY_FONT_SIZE,
                COLOR_TEXT,
                center=True,
            )
        self._draw_text(
            (
                f"NULL {self.story_scores['null']:+d}  //  "
                f"RED {self.story_scores['red']:+d}  //  "
                f"МИР {self.story_scores['peace']:+d}  //  "
                f"ХАОС {self.story_scores['chaos']:+d}"
            ),
            FINALE_SCORES_CENTER,
            FINALE_BODY_FONT_SIZE,
            COLOR_SUCCESS,
            center=True,
            bold=True,
        )
        self._draw_text(
            (
                f"Репутация {self.messenger_reputation:+d}/100  •  "
                f"Подозрение {self.suspicion:.0f}%  •  "
                f"Навыков {len(self.unlocked_skills)}  •  "
                f"Попытка {self.attempt_number}"
            ),
            FINALE_STATS_CENTER,
            FINALE_BODY_FONT_SIZE,
            COLOR_TEXT,
            center=True,
        )

    def _draw_desktop_wallpaper(self) -> None:
        self.screen.fill(COLOR_BACKGROUND)
        line_width = self._s(DESKTOP_PATTERN_LINE_WIDTH)
        pattern_height = self._s(DESIGN_HEIGHT - DESKTOP_TASKBAR_HEIGHT)
        for x in range(
            0,
            DESIGN_WIDTH + DESKTOP_PATTERN_CELL_SIZE,
            DESKTOP_PATTERN_CELL_SIZE,
        ):
            screen_x, screen_y = self._point((x, DESKTOP_TASKBAR_HEIGHT))
            pygame.draw.rect(
                self.screen,
                COLOR_PANEL,
                pygame.Rect(screen_x, screen_y, line_width, pattern_height),
            )
        for y in range(
            DESKTOP_TASKBAR_HEIGHT,
            DESIGN_HEIGHT + DESKTOP_PATTERN_CELL_SIZE,
            DESKTOP_PATTERN_CELL_SIZE,
        ):
            screen_x, screen_y = self._point((0, y))
            pygame.draw.rect(
                self.screen,
                COLOR_PANEL,
                pygame.Rect(
                    screen_x,
                    screen_y,
                    self._s(DESIGN_WIDTH),
                    line_width,
                ),
            )

    def _draw_desktop_icons(self, mouse: tuple[float, float]) -> None:
        windows_by_app = {window.app_id: window for window in self.desktop_windows}
        for index, (app_id, title, symbol) in enumerate(DESKTOP_APPS):
            square = self._desktop_icon_square(index)
            hit_rect = self._desktop_icon_hit_rect(index)
            hovered = hit_rect.collidepoint(mouse)
            open_window = windows_by_app.get(app_id)
            fill_color = COLOR_ACCENT if hovered else COLOR_PANEL
            border_color = (
                COLOR_HOT_ACCENT
                if hovered
                else COLOR_SUCCESS
                if open_window is not None and not open_window.minimized
                else COLOR_ACCENT
            )
            pygame.draw.rect(
                self.screen,
                fill_color,
                self._window_rect(square),
                border_radius=self._s(DESKTOP_ICON_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                border_color,
                self._window_rect(square),
                width=self._s(BORDER_WIDTH),
                border_radius=self._s(DESKTOP_ICON_CORNER_RADIUS),
            )
            if hovered:
                hover_rect = square.inflate(
                    DESKTOP_ICON_HOVER_EXPANSION * 2,
                    DESKTOP_ICON_HOVER_EXPANSION * 2,
                )
                pygame.draw.rect(
                    self.screen,
                    COLOR_HOT_ACCENT,
                    self._window_rect(hover_rect),
                    width=self._s(DESKTOP_ICON_HOVER_BORDER_WIDTH),
                    border_radius=self._s(
                        DESKTOP_ICON_CORNER_RADIUS + DESKTOP_ICON_HOVER_EXPANSION
                    ),
                )
            self._draw_text(
                symbol,
                square.center,
                DESKTOP_ICON_SYMBOL_FONT_SIZE,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
            self._draw_text(
                title,
                (square.centerx, square.y + DESKTOP_ICON_LABEL_OFFSET_Y),
                DESKTOP_ICON_LABEL_FONT_SIZE,
                COLOR_TEXT,
                center=True,
            )
            if open_window is not None:
                marker_x = square.centerx - DESKTOP_ICON_OPEN_MARKER_WIDTH // 2
                marker_y = (
                    hit_rect.bottom
                    - DESKTOP_ICON_OPEN_MARKER_HEIGHT
                    - DESKTOP_ICON_OPEN_MARKER_BOTTOM_MARGIN
                )
                marker_color = (
                    COLOR_HOT_ACCENT if open_window.minimized else COLOR_SUCCESS
                )
                pygame.draw.rect(
                    self.screen,
                    marker_color,
                    self._rect(
                        (
                            marker_x,
                            marker_y,
                            DESKTOP_ICON_OPEN_MARKER_WIDTH,
                            DESKTOP_ICON_OPEN_MARKER_HEIGHT,
                        )
                    ),
                    border_radius=self._s(DESKTOP_ICON_OPEN_MARKER_HEIGHT),
                )

    def _draw_window_control_symbol(
        self,
        action: str,
        control_rect: pygame.Rect,
    ) -> None:
        if action == "minimize":
            glyph = pygame.Rect(
                control_rect.centerx - DESKTOP_WINDOW_CONTROL_MINUS_WIDTH // 2,
                control_rect.centery - DESKTOP_WINDOW_CONTROL_MINUS_HEIGHT // 2,
                DESKTOP_WINDOW_CONTROL_MINUS_WIDTH,
                DESKTOP_WINDOW_CONTROL_MINUS_HEIGHT,
            )
            pygame.draw.rect(self.screen, COLOR_TEXT, self._window_rect(glyph))
            return
        if action == "maximize":
            glyph = pygame.Rect(
                control_rect.centerx - DESKTOP_WINDOW_CONTROL_SQUARE_SIZE // 2,
                control_rect.centery - DESKTOP_WINDOW_CONTROL_SQUARE_SIZE // 2,
                DESKTOP_WINDOW_CONTROL_SQUARE_SIZE,
                DESKTOP_WINDOW_CONTROL_SQUARE_SIZE,
            )
            pygame.draw.rect(
                self.screen,
                COLOR_TEXT,
                self._window_rect(glyph),
                width=self._s(DESKTOP_WINDOW_CONTROL_GLYPH_STROKE),
            )
            return

        glyph_x = control_rect.centerx - DESKTOP_WINDOW_CONTROL_CLOSE_SIZE // 2
        glyph_y = control_rect.centery - DESKTOP_WINDOW_CONTROL_CLOSE_SIZE // 2
        pixel = DESKTOP_WINDOW_CONTROL_CLOSE_PIXEL
        for offset in range(0, DESKTOP_WINDOW_CONTROL_CLOSE_SIZE, pixel):
            pygame.draw.rect(
                self.screen,
                COLOR_TEXT,
                self._rect((glyph_x + offset, glyph_y + offset, pixel, pixel)),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_TEXT,
                self._rect(
                    (
                        glyph_x + DESKTOP_WINDOW_CONTROL_CLOSE_SIZE - pixel - offset,
                        glyph_y + offset,
                        pixel,
                        pixel,
                    )
                ),
            )

    def _draw_window_controls(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        control_rects = self._window_control_rects(window)
        for action, _symbol in DESKTOP_WINDOW_CONTROL_SYMBOLS:
            control_rect = control_rects[action]
            hovered = control_rect.collidepoint(mouse)
            if hovered and action == "close":
                fill_color = COLOR_ERROR
            elif hovered:
                fill_color = COLOR_HOT_ACCENT
            else:
                fill_color = COLOR_PANEL
            pygame.draw.rect(
                self.screen,
                fill_color,
                self._window_rect(control_rect),
                border_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_TEXT if hovered else COLOR_ACCENT,
                self._window_rect(control_rect),
                width=self._s(THIN_LINE_WIDTH),
                border_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
            )
            self._draw_window_control_symbol(action, control_rect)

    @staticmethod
    def _wrap_text(
        text: str,
        font: pygame.font.Font,
        max_width: int,
    ) -> list[str]:
        lines: list[str] = []
        for paragraph in text.splitlines() or [""]:
            words = paragraph.split()
            if not words:
                lines.append("")
                continue
            current = words[0]
            for word in words[1:]:
                candidate = f"{current} {word}"
                if font.size(candidate)[0] <= max_width:
                    current = candidate
                else:
                    lines.append(current)
                    current = word
            lines.append(current)
        return lines

    @staticmethod
    def _fit_text(
        text: str,
        font: pygame.font.Font,
        max_width: int,
    ) -> str:
        if font.size(text)[0] <= max_width:
            return text
        shortened = text
        while shortened and font.size(f"{shortened}...")[0] > max_width:
            shortened = shortened[:-1]
        return f"{shortened}..." if shortened else "..."

    def _draw_messenger_sidebar(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        sidebar = self._messenger_sidebar_rect(window)
        pygame.draw.rect(self.screen, COLOR_TASKBAR, self._window_rect(sidebar))
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            self._rect(
                (
                    sidebar.right - THIN_LINE_WIDTH,
                    sidebar.y,
                    THIN_LINE_WIDTH,
                    sidebar.height,
                )
            ),
        )
        self._draw_text(
            "ЧАТЫ",
            (
                sidebar.x + MESSENGER_CHAT_ROW_SIDE_MARGIN * 2,
                sidebar.y + MESSENGER_CHAT_NAME_Y_OFFSET,
            ),
            MESSENGER_HEADER_FONT_SIZE,
            COLOR_SUCCESS,
            bold=True,
        )

        for index, customer in enumerate(MESSENGER_CUSTOMERS):
            nick = customer["nick"]
            row = self._messenger_chat_row_rect(window, index)
            selected = self.messenger_selected_chat == nick
            hovered = row.collidepoint(mouse)
            if selected or hovered:
                pygame.draw.rect(
                    self.screen,
                    COLOR_ACCENT if selected else COLOR_PANEL,
                    self._window_rect(row),
                    border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
                )
            avatar_center = (
                row.x + MESSENGER_AVATAR_X_OFFSET,
                row.centery,
            )
            pygame.draw.circle(
                self.screen,
                COLOR_HOT_ACCENT if selected else COLOR_ACCENT,
                self._point(avatar_center),
                self._s(MESSENGER_AVATAR_RADIUS),
            )
            self._draw_text(
                customer["avatar"],
                avatar_center,
                MESSENGER_TEXT_FONT_SIZE,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
            self._draw_text(
                nick,
                (
                    row.x + MESSENGER_CHAT_NAME_X_OFFSET,
                    row.y + MESSENGER_CHAT_NAME_Y_OFFSET,
                ),
                MESSENGER_TEXT_FONT_SIZE,
                COLOR_TEXT,
                bold=selected,
            )
            hot_order = self._hot_deal_order_for_customer(nick)
            active_order = hot_order or self.messenger_active_orders[nick]
            if hot_order is not None:
                self._draw_flame_icon(
                    (
                        row.right - MESSENGER_STORY_DOT_RIGHT_MARGIN,
                        row.centery,
                    ),
                    size=6,
                )
            elif active_order is not None and bool(active_order["is_story"]):
                pygame.draw.circle(
                    self.screen,
                    COLOR_ERROR,
                    self._point(
                        (
                            row.right - MESSENGER_STORY_DOT_RIGHT_MARGIN,
                            row.centery,
                        )
                    ),
                    self._s(MESSENGER_STORY_DOT_RADIUS),
                )

        if self.messenger_forum_unlocked:
            forum_index = len(MESSENGER_CUSTOMERS)
            row = self._messenger_chat_row_rect(window, forum_index)
            selected = self.messenger_selected_chat == MESSENGER_FORUM_ID
            hovered = row.collidepoint(mouse)
            if selected or hovered:
                pygame.draw.rect(
                    self.screen,
                    COLOR_ACCENT if selected else COLOR_PANEL,
                    self._window_rect(row),
                    border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
                )
            pygame.draw.circle(
                self.screen,
                COLOR_ERROR if selected else COLOR_HOT_ACCENT,
                self._point(
                    (
                        row.x + MESSENGER_AVATAR_X_OFFSET,
                        row.centery,
                    )
                ),
                self._s(MESSENGER_AVATAR_RADIUS),
            )
            self._draw_text(
                "F",
                (row.x + MESSENGER_AVATAR_X_OFFSET, row.centery),
                MESSENGER_TEXT_FONT_SIZE,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
            self._draw_text(
                "Форум",
                (
                    row.x + MESSENGER_CHAT_NAME_X_OFFSET,
                    row.y + MESSENGER_CHAT_NAME_Y_OFFSET,
                ),
                MESSENGER_TEXT_FONT_SIZE,
                COLOR_TEXT,
                bold=selected,
            )
            pygame.draw.circle(
                self.screen,
                COLOR_ERROR,
                self._point(
                    (
                        row.right - MESSENGER_STORY_DOT_RIGHT_MARGIN,
                        row.centery,
                    )
                ),
                self._s(MESSENGER_STORY_DOT_RADIUS),
            )

        reputation_bar = pygame.Rect(
            sidebar.x + MESSENGER_REPUTATION_BAR_SIDE_MARGIN,
            sidebar.bottom - MESSENGER_REPUTATION_BAR_BOTTOM_OFFSET,
            sidebar.width - MESSENGER_REPUTATION_BAR_SIDE_MARGIN * 2,
            MESSENGER_REPUTATION_BAR_HEIGHT,
        )
        pygame.draw.rect(self.screen, COLOR_PANEL, self._window_rect(reputation_bar))
        reputation_width = round(
            reputation_bar.width
            * (self.messenger_reputation - REPUTATION_MIN)
            / (REPUTATION_MAX - REPUTATION_MIN)
        )
        if reputation_width > 0:
            pygame.draw.rect(
                self.screen,
                COLOR_SUCCESS if self.messenger_reputation >= 0 else COLOR_ERROR,
                self._rect(
                    (
                        reputation_bar.x,
                        reputation_bar.y,
                        reputation_width,
                        reputation_bar.height,
                    )
                ),
            )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            self._window_rect(reputation_bar),
            width=self._s(THIN_LINE_WIDTH),
        )
        self._draw_text(
            (
                f"REP {self.messenger_reputation:+d}/100  //  "
                f"OK {self.completed_orders}/{self.messenger_orders_processed}"
            ),
            (
                sidebar.x + MESSENGER_CHAT_ROW_SIDE_MARGIN * 2,
                sidebar.bottom - MESSENGER_REPUTATION_BOTTOM_OFFSET,
            ),
            MESSENGER_SMALL_FONT_SIZE,
            COLOR_SUCCESS if self.messenger_reputation >= 0 else COLOR_ERROR,
            bold=True,
        )

    def _draw_messenger_header(self, window: DesktopWindow) -> None:
        right = self._messenger_right_rect(window)
        pygame.draw.rect(self.screen, COLOR_PANEL, self._window_rect(right))
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            self._rect(
                (
                    right.x,
                    right.y + MESSENGER_RIGHT_HEADER_HEIGHT - THIN_LINE_WIDTH,
                    right.width,
                    THIN_LINE_WIDTH,
                )
            ),
        )
        selected = self.messenger_selected_chat
        title = "Форум заказов" if selected == MESSENGER_FORUM_ID else selected
        self._draw_text(
            title,
            (
                right.x + MESSENGER_RIGHT_HEADER_X_OFFSET,
                right.y + MESSENGER_RIGHT_HEADER_Y_OFFSET,
            ),
            MESSENGER_HEADER_FONT_SIZE,
            COLOR_TEXT,
            bold=True,
        )
        self._draw_text(
            (
                f"ВЫПОЛНЕНО: {self.completed_orders}  •  "
                f"СЮЖЕТ: {self.story_chapters_completed}/{len(STORY_CHAPTERS)}"
            ),
            (
                right.right - MESSENGER_RIGHT_HEADER_X_OFFSET,
                right.y + MESSENGER_RIGHT_HEADER_Y_OFFSET,
            ),
            MESSENGER_SMALL_FONT_SIZE,
            COLOR_HOT_ACCENT,
            right=True,
        )

    def _draw_messenger_actions(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        order = self._visible_messenger_order(self.messenger_selected_chat)
        labels = {"accepted": "Принять", "rejected": "Отклонить"}
        if order is not None and bool(order.get("is_hot_deal")):
            labels = {"accepted": "HOT // Взять", "rejected": "Пропустить"}
        elif order is not None and bool(order.get("is_story")):
            labels = {
                "accepted": str(order.get("accept_label", labels["accepted"])),
                "rejected": str(order.get("reject_label", labels["rejected"])),
            }
        colors = {"accepted": COLOR_SUCCESS, "rejected": COLOR_ERROR}
        if order is not None and bool(order.get("is_hot_deal")):
            colors["accepted"] = COLOR_GOLD
        for decision, button_rect in self._messenger_action_rects(window).items():
            hovered = button_rect.collidepoint(mouse)
            pygame.draw.rect(
                self.screen,
                colors[decision],
                self._window_rect(button_rect),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            if hovered:
                pygame.draw.rect(
                    self.screen,
                    COLOR_TEXT,
                    self._window_rect(button_rect),
                    width=self._s(BORDER_WIDTH),
                    border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
                )
            label = self._fit_text(
                labels[decision],
                self._font(MESSENGER_ACTION_FONT_SIZE, True),
                self._s(button_rect.width - MESSENGER_ACTION_SIDE_MARGIN),
            )
            self._draw_text(
                label,
                button_rect.center,
                MESSENGER_ACTION_FONT_SIZE,
                COLOR_BACKGROUND if decision == "accepted" else COLOR_TEXT,
                center=True,
                bold=True,
            )

    def _draw_messenger_messages(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        right = self._messenger_right_rect(window)
        selected = self.messenger_selected_chat
        active_order = self._visible_messenger_order(selected)
        has_pending_order = (
            active_order is not None and active_order.get("status") == "pending"
        )
        actions = self._messenger_action_rects(window)
        area_top = right.y + MESSENGER_RIGHT_HEADER_HEIGHT + MESSENGER_MESSAGE_MARGIN
        area_bottom = (
            actions["accepted"].top - MESSENGER_BUBBLE_GAP
            if has_pending_order
            else right.bottom - MESSENGER_NO_ORDER_BOTTOM_OFFSET * 2
        )
        area_height = max(1, area_bottom - area_top)
        bubble_width = min(
            MESSENGER_BUBBLE_MAX_WIDTH,
            right.width - MESSENGER_MESSAGE_MARGIN * 2,
        )
        text_width_pixels = self._s(bubble_width - MESSENGER_BUBBLE_PADDING * 2)
        font = self._font(MESSENGER_TEXT_FONT_SIZE)
        layouts: list[dict[str, object]] = []
        for message in self.messenger_messages[selected]:
            display_text = self._event_display_text(str(message["text"]))
            lines = self._wrap_text(display_text, font, text_width_pixels)
            timer_text = ""
            timer_is_hot = False
            if (
                active_order is not None
                and message.get("order_id") == active_order.get("id")
                and active_order.get("status") == "pending"
            ):
                timer_is_hot = bool(active_order.get("is_hot_deal"))
                timer_text = (
                    self._format_countdown(float(self.hot_deal.get("timer", 0.0)))
                    if timer_is_hot
                    else self._format_deadline(float(active_order["deadline_at"]))
                )
            height = max(
                MESSENGER_BUBBLE_MIN_HEIGHT,
                MESSENGER_BUBBLE_PADDING * 2
                + len(lines) * MESSENGER_BUBBLE_LINE_HEIGHT
                + (MESSENGER_TIMER_LINE_HEIGHT if timer_text else 0),
            )
            layouts.append(
                {
                    "message": message,
                    "lines": lines,
                    "timer": timer_text,
                    "timer_is_hot": timer_is_hot,
                    "height": height,
                }
            )

        selected_layouts: list[dict[str, object]] = []
        used_height = 0
        for layout in reversed(layouts):
            gap = MESSENGER_BUBBLE_GAP if selected_layouts else 0
            layout_height = int(layout["height"])
            if used_height + gap + layout_height > area_height:
                if selected_layouts:
                    break
                timer_height = MESSENGER_TIMER_LINE_HEIGHT if layout["timer"] else 0
                max_lines = max(
                    1,
                    (area_height - MESSENGER_BUBBLE_PADDING * 2 - timer_height)
                    // MESSENGER_BUBBLE_LINE_HEIGHT,
                )
                lines = list(layout["lines"])[-max_lines:]
                if lines:
                    lines[0] = f"... {lines[0]}"
                layout["lines"] = lines
                layout["height"] = min(area_height, layout_height)
                layout_height = int(layout["height"])
            selected_layouts.append(layout)
            used_height += gap + layout_height
        selected_layouts.reverse()

        y = area_bottom - used_height
        for index, layout in enumerate(selected_layouts):
            if index > 0:
                y += MESSENGER_BUBBLE_GAP
            message = dict(layout["message"])
            height = int(layout["height"])
            outgoing = message.get("direction") == "outgoing"
            x = (
                right.right - MESSENGER_MESSAGE_MARGIN - bubble_width
                if outgoing
                else right.x + MESSENGER_MESSAGE_MARGIN
            )
            bubble_rect = pygame.Rect(x, y, bubble_width, height)
            is_hot_message = bool(message.get("is_hot_deal"))
            bubble_color = (
                COLOR_GOLD_DARK
                if is_hot_message
                else COLOR_MESSAGE_OUTGOING
                if outgoing
                else COLOR_MESSAGE_INCOMING
            )
            pygame.draw.rect(
                self.screen,
                bubble_color,
                self._window_rect(bubble_rect),
                border_radius=self._s(MESSENGER_BUBBLE_CORNER_RADIUS),
            )
            if is_hot_message:
                pygame.draw.rect(
                    self.screen,
                    COLOR_GOLD,
                    self._window_rect(bubble_rect),
                    width=self._s(2),
                    border_radius=self._s(MESSENGER_BUBBLE_CORNER_RADIUS),
                )
            text_y = y + MESSENGER_BUBBLE_PADDING
            for line in list(layout["lines"]):
                self._draw_text(
                    str(line),
                    (x + MESSENGER_BUBBLE_PADDING, text_y),
                    MESSENGER_TEXT_FONT_SIZE,
                    COLOR_TEXT,
                )
                text_y += MESSENGER_BUBBLE_LINE_HEIGHT
            timer_text = str(layout["timer"])
            if timer_text:
                timer_is_hot = bool(layout.get("timer_is_hot"))
                deadline_at = float(active_order["deadline_at"])
                timer_color = (
                    COLOR_GOLD
                    if timer_is_hot
                    else COLOR_ERROR
                    if deadline_at - time.time() <= MESSENGER_TIMER_WARNING_SECONDS
                    else COLOR_SUCCESS
                )
                self._draw_text(
                    f"Дедлайн: {timer_text}",
                    (
                        x + MESSENGER_BUBBLE_PADDING,
                        bubble_rect.bottom
                        - MESSENGER_BUBBLE_PADDING
                        - MESSENGER_TIMER_LINE_HEIGHT,
                    ),
                    MESSENGER_SMALL_FONT_SIZE,
                    timer_color,
                    bold=True,
                )
            if bool(message.get("is_story")):
                pygame.draw.circle(
                    self.screen,
                    COLOR_ERROR,
                    self._point(
                        (
                            bubble_rect.right - MESSENGER_STORY_DOT_RIGHT_MARGIN,
                            bubble_rect.y + MESSENGER_STORY_DOT_RIGHT_MARGIN,
                        )
                    ),
                    self._s(MESSENGER_STORY_DOT_RADIUS),
                )
            y += height

        if has_pending_order:
            self._draw_messenger_actions(window, mouse)
        else:
            footer_text = (
                "[HOT] Горячий заказ принят — завершите операцию до конца таймера"
                if active_order is not None and bool(active_order.get("is_hot_deal"))
                else "Кликните по чату ещё раз, чтобы получить новый заказ"
            )
            self._draw_text(
                footer_text,
                (
                    right.centerx,
                    right.bottom - MESSENGER_NO_ORDER_BOTTOM_OFFSET,
                ),
                MESSENGER_SMALL_FONT_SIZE,
                COLOR_ACCENT,
                center=True,
            )

    def _draw_messenger_forum(self, window: DesktopWindow) -> None:
        right = self._messenger_right_rect(window)
        card_x = right.x + MESSENGER_FORUM_SIDE_MARGIN
        card_width = right.width - MESSENGER_FORUM_SIDE_MARGIN * 2
        start_y = right.y + MESSENGER_RIGHT_HEADER_HEIGHT + MESSENGER_FORUM_CARD_GAP
        font = self._font(MESSENGER_SMALL_FONT_SIZE)
        for index, order in enumerate(self.messenger_forum_orders):
            y = start_y + index * (
                MESSENGER_FORUM_CARD_HEIGHT + MESSENGER_FORUM_CARD_GAP
            )
            card = pygame.Rect(
                card_x,
                y,
                card_width,
                MESSENGER_FORUM_CARD_HEIGHT,
            )
            pygame.draw.rect(
                self.screen,
                COLOR_TASKBAR,
                self._window_rect(card),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT,
                self._window_rect(card),
                width=self._s(THIN_LINE_WIDTH),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            target = self._fit_text(
                f"#{int(order['id']):02d}  {order['target']}",
                font,
                self._s(card.width - MESSENGER_FORUM_TEXT_X_OFFSET * 2),
            )
            self._draw_text(
                target,
                (
                    card.x + MESSENGER_FORUM_TEXT_X_OFFSET,
                    card.y + MESSENGER_FORUM_TEXT_Y_OFFSET,
                ),
                MESSENGER_SMALL_FONT_SIZE,
                COLOR_TEXT,
                bold=True,
            )
            order_type = self._fit_text(
                str(order["type"]),
                font,
                self._s(card.width // 2),
            )
            self._draw_text(
                order_type,
                (
                    card.x + MESSENGER_FORUM_TEXT_X_OFFSET,
                    card.y
                    + MESSENGER_FORUM_TEXT_Y_OFFSET
                    + MESSENGER_BUBBLE_LINE_HEIGHT,
                ),
                MESSENGER_SMALL_FONT_SIZE,
                COLOR_ACCENT,
            )
            timer = self._format_deadline(float(order["deadline_at"]))
            self._draw_text(
                f"₿ {float(order['reward']):.3f}  •  {timer}",
                (
                    card.right - MESSENGER_FORUM_REWARD_RIGHT_MARGIN,
                    card.y
                    + MESSENGER_FORUM_TEXT_Y_OFFSET
                    + MESSENGER_BUBBLE_LINE_HEIGHT,
                ),
                MESSENGER_SMALL_FONT_SIZE,
                COLOR_SUCCESS,
                right=True,
                bold=True,
            )

    def _draw_messenger_content(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        self._draw_messenger_sidebar(window, mouse)
        self._draw_messenger_header(window)
        if self.messenger_selected_chat == MESSENGER_FORUM_ID:
            self._draw_messenger_forum(window)
        else:
            self._draw_messenger_messages(window, mouse)

    def _draw_browser_content(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        content = self._window_content_rect(window)
        pygame.draw.rect(self.screen, COLOR_PANEL, self._window_rect(content))
        address = self._browser_address_rect(window)
        address_border = (
            COLOR_HOT_ACCENT if self.browser_input_focused else COLOR_ACCENT
        )
        pygame.draw.rect(
            self.screen,
            COLOR_TASKBAR,
            self._window_rect(address),
            border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            address_border,
            self._window_rect(address),
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
        )
        query_text = self.browser_query or "Введите тип цели..."
        query_color = COLOR_TEXT if self.browser_query else COLOR_ACCENT
        shown_query = self._fit_text(
            f"target:// {query_text}",
            self._font(BROWSER_HEADER_FONT_SIZE),
            self._s(address.width - BROWSER_ADDRESS_TEXT_PADDING * 2),
        )
        query_rect = self._draw_text(
            shown_query,
            (
                address.x + BROWSER_ADDRESS_TEXT_PADDING,
                address.y
                + BROWSER_ADDRESS_TEXT_PADDING
                + BROWSER_ADDRESS_TEXT_Y_ADJUST,
            ),
            BROWSER_HEADER_FONT_SIZE,
            query_color,
            bold=bool(self.browser_query),
        )
        if (
            self.browser_input_focused
            and int(self.total_elapsed / BROWSER_CURSOR_BLINK_SECONDS) % 2 == 0
        ):
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT,
                pygame.Rect(
                    query_rect.right + self._s(BROWSER_CURSOR_GAP),
                    query_rect.top,
                    self._s(BROWSER_CURSOR_WIDTH),
                    query_rect.height,
                ),
            )

        if not self.browser_query:
            types_hint = " • ".join(TARGET_TYPES)
            self._draw_text(
                self._fit_text(
                    f"Доступные типы: {types_hint}",
                    self._font(BROWSER_FONT_SIZE),
                    self._s(content.width - BROWSER_CONTENT_MARGIN * 2),
                ),
                (
                    content.x + BROWSER_CONTENT_MARGIN,
                    content.y
                    + BROWSER_RESULTS_START_OFFSET
                    + BROWSER_EMPTY_TEXT_Y_OFFSET,
                ),
                BROWSER_FONT_SIZE,
                COLOR_ACCENT,
            )
        elif not self.browser_results:
            self._draw_text(
                "Цели не найдены. Введите название типа из списка.",
                (
                    content.x + BROWSER_CONTENT_MARGIN,
                    content.y
                    + BROWSER_RESULTS_START_OFFSET
                    + BROWSER_EMPTY_TEXT_Y_OFFSET,
                ),
                BROWSER_FONT_SIZE,
                COLOR_ERROR,
            )

        for index, target in enumerate(self.browser_results):
            row = self._browser_result_rect(window, index)
            selected = self.browser_selected_target is target
            hovered = row.collidepoint(mouse)
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT if selected else COLOR_TASKBAR,
                self._window_rect(row),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT if selected else COLOR_ACCENT,
                self._window_rect(row),
                width=self._s(BORDER_WIDTH if selected or hovered else THIN_LINE_WIDTH),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            base_difficulty = int(target["difficulty"])
            effective_difficulty = self._effective_target_difficulty(base_difficulty)
            difficulty_text = (
                f"L{base_difficulty}→L{effective_difficulty}"
                if effective_difficulty != base_difficulty
                else f"L{base_difficulty}"
            )
            protection = f"ЗАЩИТА: {target['protection']}  {difficulty_text}"
            protection_rect = self._draw_text(
                protection,
                (
                    row.right - BROWSER_RESULT_TEXT_X_OFFSET,
                    row.y + BROWSER_RESULT_TEXT_Y_OFFSET,
                ),
                BROWSER_FONT_SIZE,
                COLOR_SUCCESS if effective_difficulty <= 2 else COLOR_HOT_ACCENT,
                right=True,
                bold=True,
            )
            name_width = max(
                self._s(BROWSER_RESULT_NAME_MIN_WIDTH),
                protection_rect.left
                - self._point((row.x + BROWSER_RESULT_TEXT_X_OFFSET, 0))[0]
                - self._s(BROWSER_RESULT_NAME_GAP),
            )
            target_name = self._fit_text(
                f"{target['name']}  //  {target['target_type']}",
                self._font(BROWSER_FONT_SIZE, True),
                name_width,
            )
            self._draw_text(
                target_name,
                (
                    row.x + BROWSER_RESULT_TEXT_X_OFFSET,
                    row.y + BROWSER_RESULT_TEXT_Y_OFFSET,
                ),
                BROWSER_FONT_SIZE,
                COLOR_TEXT,
                bold=True,
            )
            detail = self._fit_text(
                f"{target['location']} — {target['description']}",
                self._font(BROWSER_FONT_SIZE),
                self._s(row.width - BROWSER_RESULT_TEXT_X_OFFSET * 2),
            )
            self._draw_text(
                detail,
                (
                    row.x + BROWSER_RESULT_TEXT_X_OFFSET,
                    row.y
                    + BROWSER_RESULT_TEXT_Y_OFFSET
                    + BROWSER_RESULT_DETAIL_Y_OFFSET,
                ),
                BROWSER_FONT_SIZE,
                COLOR_TEXT if selected else COLOR_ACCENT,
            )

        if self.browser_selected_target is not None:
            hack_rect = self._browser_hack_rect(window)
            hovered = hack_rect.collidepoint(mouse)
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT if hovered else COLOR_SUCCESS,
                self._window_rect(hack_rect),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_TEXT if hovered else COLOR_SUCCESS,
                self._window_rect(hack_rect),
                width=self._s(BORDER_WIDTH),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            self._draw_text(
                "Взломать",
                hack_rect.center,
                BROWSER_HEADER_FONT_SIZE,
                COLOR_BACKGROUND,
                center=True,
                bold=True,
            )

    def _darknet_stock_text(self, product: dict[str, object]) -> str:
        if product.get("vpn_charges") is not None:
            return f"Заряды VPN: {self.vpn_charges}"
        if product["id"] == "skill_course":
            return f"Навыки: {self.skill_points}"
        return f"В инвентаре: {self.inventory[str(product['id'])]}"

    def _draw_darknet_content(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        content = self._window_content_rect(window)
        sidebar = self._darknet_sidebar_rect(window)
        pygame.draw.rect(self.screen, COLOR_TASKBAR, self._window_rect(content))
        pygame.draw.rect(self.screen, COLOR_BACKGROUND, self._window_rect(sidebar))
        pygame.draw.rect(
            self.screen,
            COLOR_HOT_ACCENT,
            self._rect(
                (
                    sidebar.right - THIN_LINE_WIDTH,
                    sidebar.y,
                    THIN_LINE_WIDTH,
                    sidebar.height,
                )
            ),
        )
        self._draw_text(
            ".ONION STORE",
            (
                sidebar.x + DARKNET_CATEGORY_TEXT_X_OFFSET,
                sidebar.y + DARKNET_HEADER_TEXT_OFFSET[1],
            ),
            DARKNET_TITLE_FONT_SIZE,
            COLOR_HOT_ACCENT,
            bold=True,
        )
        for index, (category_id, label) in enumerate(DARKNET_CATEGORIES):
            category_rect = self._darknet_category_rect(window, index)
            selected = category_id == self.darknet_category
            hovered = category_rect.collidepoint(mouse)
            if selected or hovered:
                pygame.draw.rect(
                    self.screen,
                    COLOR_HOT_ACCENT if selected else COLOR_PANEL,
                    self._window_rect(category_rect),
                    border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
                )
            self._draw_text(
                label,
                (
                    category_rect.x + DARKNET_CATEGORY_TEXT_X_OFFSET,
                    category_rect.y + DARKNET_CATEGORY_TEXT_Y_OFFSET,
                ),
                DARKNET_TEXT_FONT_SIZE,
                COLOR_BACKGROUND if selected else COLOR_TEXT,
                bold=selected,
            )

        page_count = self._darknet_page_count()
        self._draw_text(
            f"СТРАНИЦА {self.darknet_page + 1}/{page_count}",
            (
                sidebar.centerx,
                sidebar.bottom - DARKNET_PAGE_TEXT_BOTTOM_OFFSET,
            ),
            DARKNET_SMALL_FONT_SIZE,
            COLOR_ACCENT,
            center=True,
        )
        for direction, button in self._darknet_page_rects(window).items():
            disabled = (direction == "previous" and self.darknet_page <= 0) or (
                direction == "next" and self.darknet_page >= page_count - 1
            )
            pygame.draw.rect(
                self.screen,
                COLOR_PANEL
                if disabled
                else COLOR_HOT_ACCENT
                if button.collidepoint(mouse)
                else COLOR_ACCENT,
                self._window_rect(button),
                border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
            )
            self._draw_text(
                "<" if direction == "previous" else ">",
                button.center,
                DARKNET_TEXT_FONT_SIZE,
                COLOR_ACCENT if disabled else COLOR_TEXT,
                center=True,
                bold=True,
            )

        category_label = next(
            label
            for category_id, label in DARKNET_CATEGORIES
            if category_id == self.darknet_category
        )
        area_left = content.x + DARKNET_SIDEBAR_WIDTH
        category_heading = category_label.upper()
        if self.darknet_discount_timer > 0.0:
            category_heading += (
                f"  •  СКИДКА -30% {self._format_countdown(self.darknet_discount_timer)}"
            )
        self._draw_text(
            category_heading,
            (
                area_left + DARKNET_HEADER_TEXT_OFFSET[0],
                content.y + DARKNET_HEADER_TEXT_OFFSET[1],
            ),
            DARKNET_TITLE_FONT_SIZE,
            COLOR_TEXT,
            bold=True,
        )
        self._draw_text(
            f"БАЛАНС BTC {self.btc_balance:.3f}",
            (
                content.right - DARKNET_BALANCE_RIGHT_MARGIN,
                content.y + DARKNET_HEADER_TEXT_OFFSET[1],
            ),
            DARKNET_TEXT_FONT_SIZE,
            COLOR_SUCCESS,
            right=True,
            bold=True,
        )

        for slot, product in enumerate(self._darknet_visible_products()):
            card = self._darknet_card_rect(window, slot)
            buy_rect = self._darknet_buy_rect(card)
            effective_price = self._darknet_effective_price(product)
            has_funds = self.btc_balance + 1e-12 >= effective_price
            vpn_at_capacity = (
                product.get("vpn_charges") is not None
                and self.vpn_charges >= VPN_MAX_CHARGES
                and not bool(self.call_state.get("threat_active"))
            )
            can_purchase = has_funds and not vpn_at_capacity
            hovered = card.collidepoint(mouse)
            pygame.draw.rect(
                self.screen,
                COLOR_PANEL if hovered else COLOR_BACKGROUND,
                self._window_rect(card),
                border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT if hovered else COLOR_ACCENT,
                self._window_rect(card),
                width=self._s(BORDER_WIDTH),
                border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
            )
            title = self._fit_text(
                str(product["name"]),
                self._font(DARKNET_TITLE_FONT_SIZE, True),
                self._s(card.width - DARKNET_CARD_TITLE_OFFSET[0] * 2),
            )
            self._draw_text(
                title,
                (
                    card.x + DARKNET_CARD_TITLE_OFFSET[0],
                    card.y + DARKNET_CARD_TITLE_OFFSET[1],
                ),
                DARKNET_TITLE_FONT_SIZE,
                COLOR_TEXT,
                bold=True,
            )
            description_lines = self._wrap_text(
                str(product["description"]),
                self._font(DARKNET_TEXT_FONT_SIZE),
                self._s(card.width - DARKNET_CARD_TITLE_OFFSET[0] * 2),
            )[:DARKNET_CARD_DESCRIPTION_MAX_LINES]
            for line_index, line in enumerate(description_lines):
                self._draw_text(
                    line,
                    (
                        card.x + DARKNET_CARD_TITLE_OFFSET[0],
                        card.y
                        + DARKNET_CARD_DESCRIPTION_Y_OFFSET
                        + line_index * DARKNET_CARD_DESCRIPTION_LINE_HEIGHT,
                    ),
                    DARKNET_TEXT_FONT_SIZE,
                    COLOR_TEXT,
                )
            price_label = f"BTC {effective_price:.3f}"
            if self.darknet_discount_timer > 0.0:
                price_label += "  -30%"
            self._draw_text(
                price_label,
                (
                    card.x + DARKNET_CARD_PRICE_OFFSET[0],
                    card.y + DARKNET_CARD_PRICE_OFFSET[1],
                ),
                DARKNET_TEXT_FONT_SIZE,
                COLOR_SUCCESS if has_funds else COLOR_ERROR,
                bold=True,
            )
            self._draw_text(
                self._darknet_stock_text(product),
                (
                    card.x + DARKNET_CARD_PRICE_OFFSET[0],
                    card.y + DARKNET_CARD_STOCK_Y_OFFSET,
                ),
                DARKNET_SMALL_FONT_SIZE,
                COLOR_ACCENT,
            )
            pygame.draw.rect(
                self.screen,
                COLOR_SUCCESS
                if can_purchase and buy_rect.collidepoint(mouse)
                else COLOR_ACCENT
                if can_purchase
                else COLOR_PANEL,
                self._window_rect(buy_rect),
                border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_SUCCESS if can_purchase else COLOR_ACCENT,
                self._window_rect(buy_rect),
                width=self._s(THIN_LINE_WIDTH),
                border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
            )
            self._draw_text(
                "MAX" if vpn_at_capacity else "Купить",
                buy_rect.center,
                DARKNET_TEXT_FONT_SIZE,
                COLOR_BACKGROUND if can_purchase else COLOR_ACCENT,
                center=True,
                bold=True,
            )

    def _draw_crypto_wallet_content(self, window: DesktopWindow) -> None:
        content = self._window_content_rect(window)
        pygame.draw.rect(self.screen, COLOR_PANEL, self._window_rect(content))
        balance_panel = pygame.Rect(
            content.x + WALLET_MARGIN,
            content.y + WALLET_MARGIN,
            content.width - WALLET_MARGIN * 2,
            WALLET_BALANCE_PANEL_HEIGHT,
        )
        pygame.draw.rect(
            self.screen,
            COLOR_TASKBAR,
            self._window_rect(balance_panel),
            border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_SUCCESS,
            self._window_rect(balance_panel),
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
        )
        self._draw_text(
            "ДОСТУПНЫЙ БАЛАНС",
            (
                balance_panel.centerx,
                balance_panel.y + WALLET_BALANCE_LABEL_Y_OFFSET,
            ),
            WALLET_HEADER_FONT_SIZE,
            COLOR_ACCENT,
            center=True,
            bold=True,
        )
        self._draw_text(
            f"BTC {self.btc_balance:.6f}",
            (
                balance_panel.centerx,
                balance_panel.y + WALLET_BALANCE_Y_OFFSET,
            ),
            WALLET_BALANCE_FONT_SIZE,
            COLOR_SUCCESS,
            center=True,
            bold=True,
        )
        self._draw_text(
            "ТРАНЗАКЦИИ",
            (
                content.x + WALLET_MARGIN,
                content.y + WALLET_TRANSACTION_HEADER_Y_OFFSET,
            ),
            WALLET_HEADER_FONT_SIZE,
            COLOR_TEXT,
            bold=True,
        )
        self._draw_text(
            f"В майнерах: BTC {self.miner_pending_income:.6f}",
            (
                content.right - WALLET_MARGIN,
                content.y + WALLET_TRANSACTION_HEADER_Y_OFFSET,
            ),
            WALLET_FONT_SIZE,
            COLOR_HOT_ACCENT,
            right=True,
        )
        if not self.transactions:
            self._draw_text(
                "Транзакций пока нет",
                (
                    content.centerx,
                    content.y
                    + WALLET_TRANSACTION_START_Y_OFFSET
                    + WALLET_EMPTY_TEXT_Y_OFFSET,
                ),
                WALLET_HEADER_FONT_SIZE,
                COLOR_ACCENT,
                center=True,
            )
            return

        visible_transactions = list(
            reversed(self.transactions[-WALLET_TRANSACTION_MAX_VISIBLE:])
        )
        type_width = self._s(
            content.width - WALLET_MARGIN * 2 - WALLET_TRANSACTION_AMOUNT_RESERVED
        )
        for index, transaction in enumerate(visible_transactions):
            row = pygame.Rect(
                content.x + WALLET_MARGIN,
                content.y
                + WALLET_TRANSACTION_START_Y_OFFSET
                + index * (WALLET_TRANSACTION_ROW_HEIGHT + WALLET_TRANSACTION_ROW_GAP),
                content.width - WALLET_MARGIN * 2,
                WALLET_TRANSACTION_ROW_HEIGHT,
            )
            amount = float(transaction["amount"])
            pygame.draw.rect(
                self.screen,
                COLOR_TASKBAR,
                self._window_rect(row),
                border_radius=self._s(DARKNET_CARD_CORNER_RADIUS),
            )
            self._draw_text(
                self._fit_text(
                    str(transaction["type"]),
                    self._font(WALLET_FONT_SIZE, True),
                    type_width,
                ),
                (
                    row.x + WALLET_TRANSACTION_TEXT_X_OFFSET,
                    row.y + WALLET_TRANSACTION_TEXT_Y_OFFSET,
                ),
                WALLET_FONT_SIZE,
                COLOR_TEXT,
                bold=True,
            )
            timestamp = datetime.fromtimestamp(
                float(transaction["timestamp"]),
                tz=timezone.utc,
            ).astimezone()
            self._draw_text(
                timestamp.strftime("%d.%m.%Y  %H:%M:%S"),
                (
                    row.x + WALLET_TRANSACTION_TEXT_X_OFFSET,
                    row.y + WALLET_TRANSACTION_DATE_Y_OFFSET,
                ),
                WALLET_SMALL_FONT_SIZE,
                COLOR_ACCENT,
            )
            self._draw_text(
                f"{amount:+.6f} BTC",
                (
                    row.right - WALLET_TRANSACTION_AMOUNT_RIGHT_OFFSET,
                    row.centery + WALLET_TRANSACTION_AMOUNT_Y_ADJUST,
                ),
                WALLET_FONT_SIZE,
                COLOR_SUCCESS if amount >= 0.0 else COLOR_ERROR,
                right=True,
                bold=True,
            )

    def _draw_miner_manager_content(self, window: DesktopWindow) -> None:
        content = self._window_content_rect(window)
        pygame.draw.rect(self.screen, COLOR_PANEL, self._window_rect(content))
        total_rate = sum(
            float(miner.get("rate", MINER_RATE_BTC_PER_MINUTE))
            for miner in self.miner_targets
        )
        self._draw_text(
            f"АКТИВНЫЕ МАЙНЕРЫ: {len(self.miner_targets)}",
            (
                content.x + MINER_MANAGER_MARGIN,
                content.y + MINER_MANAGER_MARGIN,
            ),
            BROWSER_HEADER_FONT_SIZE,
            COLOR_SUCCESS,
            bold=True,
        )
        self._draw_text(
            f"СКОРОСТЬ: {total_rate:.3f} BTC/мин",
            (
                content.right - MINER_MANAGER_MARGIN,
                content.y + MINER_MANAGER_MARGIN,
            ),
            MINER_MANAGER_FONT_SIZE,
            COLOR_HOT_ACCENT,
            right=True,
            bold=True,
        )
        self._draw_text(
            f"Всего добыто: BTC {self.miner_earned_total:.6f}",
            (
                content.x + MINER_MANAGER_MARGIN,
                content.y + MINER_MANAGER_MARGIN + MINER_MANAGER_SUBHEADER_Y_OFFSET,
            ),
            MINER_MANAGER_FONT_SIZE,
            COLOR_ACCENT,
        )
        self._draw_text(
            f"К снятию: BTC {self.miner_pending_income:.6f}",
            (
                content.right - MINER_MANAGER_MARGIN,
                content.y + MINER_MANAGER_MARGIN + MINER_MANAGER_SUBHEADER_Y_OFFSET,
            ),
            MINER_MANAGER_FONT_SIZE,
            COLOR_SUCCESS,
            right=True,
            bold=True,
        )
        withdraw_rect = self._miner_withdraw_rect(window)
        can_withdraw = self.miner_pending_income > 1e-12
        pygame.draw.rect(
            self.screen,
            COLOR_SUCCESS if can_withdraw else COLOR_TASKBAR,
            self._window_rect(withdraw_rect),
            border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_SUCCESS if can_withdraw else COLOR_ACCENT,
            self._window_rect(withdraw_rect),
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
        )
        self._draw_text(
            "Снять доход",
            withdraw_rect.center,
            MINER_MANAGER_WITHDRAW_FONT_SIZE,
            COLOR_BACKGROUND if can_withdraw else COLOR_ACCENT,
            center=True,
            bold=True,
        )
        if not self.miner_targets:
            self._draw_text(
                "Нет активных узлов",
                content.center,
                DESKTOP_WINDOW_PLACEHOLDER_FONT_SIZE,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
            self._draw_text(
                "Взломайте цель и выберите «Майнер»",
                (
                    content.centerx,
                    content.centery + MINER_MANAGER_EMPTY_DETAIL_Y_OFFSET,
                ),
                MINER_MANAGER_FONT_SIZE,
                COLOR_ACCENT,
                center=True,
            )
            return

        start_y = content.y + MINER_MANAGER_HEADER_HEIGHT + MINER_MANAGER_MARGIN
        visible_miners = self.miner_targets[-MINER_MANAGER_MAX_VISIBLE:]
        for index, miner in enumerate(visible_miners):
            row = pygame.Rect(
                content.x + MINER_MANAGER_MARGIN,
                start_y + index * (MINER_MANAGER_ROW_HEIGHT + MINER_MANAGER_ROW_GAP),
                content.width - MINER_MANAGER_MARGIN * 2,
                MINER_MANAGER_ROW_HEIGHT,
            )
            pygame.draw.rect(
                self.screen,
                COLOR_TASKBAR,
                self._window_rect(row),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_SUCCESS,
                self._window_rect(row),
                width=self._s(THIN_LINE_WIDTH),
                border_radius=self._s(MESSENGER_ACTION_CORNER_RADIUS),
            )
            label = self._fit_text(
                f"{miner['name']}  //  {miner['target_type']}",
                self._font(MINER_MANAGER_FONT_SIZE, True),
                self._s(row.width - MINER_MANAGER_ROW_RIGHT_RESERVED),
            )
            self._draw_text(
                label,
                (
                    row.x + MINER_MANAGER_ROW_TEXT_X_OFFSET,
                    row.y + MINER_MANAGER_ROW_TEXT_Y_OFFSET,
                ),
                MINER_MANAGER_FONT_SIZE,
                COLOR_TEXT,
                bold=True,
            )
            self._draw_text(
                (
                    f"+{float(miner.get('rate', MINER_RATE_BTC_PER_MINUTE)):.3f} "
                    "BTC/мин  ● ONLINE"
                ),
                (
                    row.right - MINER_MANAGER_ROW_TEXT_X_OFFSET,
                    row.y + MINER_MANAGER_ROW_TEXT_Y_OFFSET,
                ),
                MINER_MANAGER_FONT_SIZE,
                COLOR_SUCCESS,
                right=True,
                bold=True,
            )
        hidden_count = len(self.miner_targets) - len(visible_miners)
        if hidden_count > 0:
            self._draw_text(
                f"Ещё активных узлов: {hidden_count}",
                (
                    content.x + MINER_MANAGER_MARGIN,
                    content.bottom
                    - MINER_MANAGER_MARGIN
                    - MINER_MANAGER_HIDDEN_BOTTOM_OFFSET,
                ),
                MINER_MANAGER_FONT_SIZE,
                COLOR_ACCENT,
            )

    def _draw_skill_tree_content(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        content = self._window_content_rect(window)
        pygame.draw.rect(self.screen, COLOR_TASKBAR, self._window_rect(content))
        header = pygame.Rect(
            content.x + SKILL_TREE_CONTENT_MARGIN,
            content.y + SKILL_TREE_CONTENT_MARGIN,
            content.width - SKILL_TREE_CONTENT_MARGIN * 2,
            SKILL_TREE_HEADER_HEIGHT,
        )
        pygame.draw.rect(
            self.screen,
            COLOR_PANEL,
            self._window_rect(header),
            border_radius=self._s(SKILL_TREE_NODE_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            self._window_rect(header),
            width=self._s(BORDER_WIDTH),
            border_radius=self._s(SKILL_TREE_NODE_CORNER_RADIUS),
        )
        self._draw_text(
            "root@zero:~$ skilltree --status",
            (header.x + SKILL_TREE_NODE_PADDING, header.y + 8),
            SKILL_TREE_TITLE_FONT_SIZE,
            COLOR_SUCCESS,
            bold=True,
        )
        self._draw_text(
            (
                f"SP: {self.skill_points}  •  открыто: "
                f"{len(self.unlocked_skills)}/{len(self._skill_nodes())}"
            ),
            (header.right - SKILL_TREE_NODE_PADDING, header.y + 9),
            SKILL_TREE_STATUS_FONT_SIZE,
            COLOR_TEXT,
            right=True,
            bold=True,
        )
        self._draw_text(
            "Очки начисляются за доставленные заказы",
            (header.x + SKILL_TREE_NODE_PADDING, header.y + 27),
            SKILL_TREE_STATUS_FONT_SIZE,
            COLOR_ACCENT,
        )

        branch_colors = (COLOR_HOT_ACCENT, COLOR_SUCCESS, COLOR_TEXT)
        for branch_index, branch in enumerate(SKILL_TREE_BRANCHES):
            nodes = branch.get("nodes")
            if not isinstance(nodes, tuple):
                continue
            first_node = self._skill_tree_node_rect(window, branch_index, 0)
            branch_color = branch_colors[branch_index]
            branch_title_y = first_node.y - SKILL_TREE_BRANCH_TITLE_HEIGHT // 2
            self._draw_text(
                str(branch["name"]),
                (first_node.centerx, branch_title_y),
                SKILL_TREE_TITLE_FONT_SIZE,
                branch_color,
                center=True,
                bold=True,
            )
            for node_index in range(len(nodes) - 1):
                upper = self._skill_tree_node_rect(window, branch_index, node_index)
                lower = self._skill_tree_node_rect(
                    window,
                    branch_index,
                    node_index + 1,
                )
                pygame.draw.line(
                    self.screen,
                    branch_color,
                    self._point((upper.centerx, upper.bottom)),
                    self._point((lower.centerx, lower.top)),
                    self._s(SKILL_TREE_CONNECTOR_WIDTH),
                )

            for node_index, node in enumerate(nodes):
                if not isinstance(node, dict):
                    continue
                node_rect = self._skill_tree_node_rect(
                    window,
                    branch_index,
                    node_index,
                )
                skill_id = str(node["id"])
                unlocked = skill_id in self.unlocked_skills
                required = node.get("requires")
                prerequisite_met = (
                    required is None or str(required) in self.unlocked_skills
                )
                affordable = self.skill_points >= int(node["cost"])
                hovered = node_rect.collidepoint(mouse)
                fill_color = (
                    COLOR_ACCENT
                    if unlocked
                    else COLOR_PANEL
                    if prerequisite_met
                    else COLOR_BACKGROUND
                )
                border_color = (
                    COLOR_SUCCESS
                    if unlocked
                    else branch_color
                    if prerequisite_met
                    else COLOR_ACCENT
                )
                if hovered and not unlocked and prerequisite_met:
                    fill_color = COLOR_HOT_ACCENT if affordable else COLOR_ACCENT
                pygame.draw.rect(
                    self.screen,
                    fill_color,
                    self._window_rect(node_rect),
                    border_radius=self._s(SKILL_TREE_NODE_CORNER_RADIUS),
                )
                pygame.draw.rect(
                    self.screen,
                    border_color,
                    self._window_rect(node_rect),
                    width=self._s(BORDER_WIDTH),
                    border_radius=self._s(SKILL_TREE_NODE_CORNER_RADIUS),
                )
                text_width = self._s(node_rect.width - SKILL_TREE_NODE_PADDING * 2)
                name = self._fit_text(
                    str(node["name"]),
                    self._font(SKILL_TREE_NODE_FONT_SIZE, True),
                    text_width,
                )
                description = self._fit_text(
                    str(node["description"]),
                    self._font(SKILL_TREE_DESCRIPTION_FONT_SIZE),
                    text_width,
                )
                self._draw_text(
                    name,
                    (node_rect.centerx, node_rect.y + 15),
                    SKILL_TREE_NODE_FONT_SIZE,
                    COLOR_TEXT,
                    center=True,
                    bold=True,
                )
                self._draw_text(
                    description,
                    (node_rect.centerx, node_rect.y + 36),
                    SKILL_TREE_DESCRIPTION_FONT_SIZE,
                    COLOR_TEXT if prerequisite_met else COLOR_ACCENT,
                    center=True,
                )
                status = (
                    "ОТКРЫТО"
                    if unlocked
                    else "НУЖЕН ПРЕДЫДУЩИЙ"
                    if not prerequisite_met
                    else f"ОТКРЫТЬ • {int(node['cost'])} SP"
                )
                self._draw_text(
                    status,
                    (node_rect.centerx, node_rect.y + 56),
                    SKILL_TREE_STATUS_FONT_SIZE,
                    COLOR_SUCCESS
                    if unlocked
                    else COLOR_TEXT
                    if affordable and prerequisite_met
                    else COLOR_ERROR,
                    center=True,
                    bold=True,
                )

        self._draw_text(
            "Каждая ветка открывается сверху вниз • выбор необратим",
            (content.centerx, content.bottom - SKILL_TREE_CONTENT_MARGIN - 7),
            SKILL_TREE_STATUS_FONT_SIZE,
            COLOR_ACCENT,
            center=True,
        )

    @staticmethod
    def _music_player_content_rect(window: DesktopWindow) -> pygame.Rect:
        inset = MUSIC_PLAYER_PADDING
        return pygame.Rect(
            window.rect.x + inset,
            window.rect.y + DESKTOP_WINDOW_TITLE_HEIGHT + inset,
            window.rect.width - inset * 2,
            window.rect.height - DESKTOP_WINDOW_TITLE_HEIGHT - inset * 2,
        )

    def _music_player_track_rect(
        self,
        window: DesktopWindow,
        index: int,
    ) -> pygame.Rect:
        content = self._music_player_content_rect(window)
        return pygame.Rect(
            content.x,
            content.y
            + MUSIC_PLAYER_TRACK_START_Y_OFFSET
            + index * (MUSIC_PLAYER_TRACK_ROW_HEIGHT + MUSIC_PLAYER_TRACK_ROW_GAP),
            content.width,
            MUSIC_PLAYER_TRACK_ROW_HEIGHT,
        )

    def _music_player_control_rects(
        self,
        window: DesktopWindow,
    ) -> dict[str, pygame.Rect]:
        content = self._music_player_content_rect(window)
        controls_width = MUSIC_PLAYER_CONTROL_SIZE * 3 + MUSIC_PLAYER_CONTROL_GAP * 2
        controls_x = content.centerx - controls_width // 2
        controls_y = content.y + MUSIC_PLAYER_CONTROLS_Y_OFFSET
        return {
            "previous": pygame.Rect(
                controls_x,
                controls_y,
                MUSIC_PLAYER_CONTROL_SIZE,
                MUSIC_PLAYER_CONTROL_SIZE,
            ),
            "play_pause": pygame.Rect(
                controls_x + MUSIC_PLAYER_CONTROL_SIZE + MUSIC_PLAYER_CONTROL_GAP,
                controls_y,
                MUSIC_PLAYER_CONTROL_SIZE,
                MUSIC_PLAYER_CONTROL_SIZE,
            ),
            "next": pygame.Rect(
                controls_x + (MUSIC_PLAYER_CONTROL_SIZE + MUSIC_PLAYER_CONTROL_GAP) * 2,
                controls_y,
                MUSIC_PLAYER_CONTROL_SIZE,
                MUSIC_PLAYER_CONTROL_SIZE,
            ),
            "mode": pygame.Rect(
                content.x,
                controls_y,
                *MUSIC_PLAYER_MODE_BUTTON_SIZE,
            ),
        }

    @staticmethod
    def _music_player_volume_rect(window: DesktopWindow) -> pygame.Rect:
        content = ZeroDayApp._music_player_content_rect(window)
        return pygame.Rect(
            content.x + MUSIC_PLAYER_VOLUME_LABEL_WIDTH,
            content.bottom - MUSIC_PLAYER_VOLUME_BOTTOM_OFFSET,
            content.width - MUSIC_PLAYER_VOLUME_LABEL_WIDTH,
            MUSIC_PLAYER_VOLUME_TRACK_HEIGHT,
        )

    def _set_music_player_volume_at(
        self,
        window: DesktopWindow,
        mouse_x: float,
    ) -> None:
        volume_rect = self._music_player_volume_rect(window)
        value = (mouse_x - volume_rect.x) / max(1, volume_rect.width)
        self._set_music_volume(value)

    def _handle_music_player_click(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> bool:
        for index, track_id in enumerate(MUSIC_TRACK_IDS):
            if self._music_player_track_rect(window, index).collidepoint(mouse):
                self._select_manual_music_track(track_id)
                return True
        controls = self._music_player_control_rects(window)
        if controls["previous"].collidepoint(mouse):
            self._step_manual_music_track(-1)
            return True
        if controls["play_pause"].collidepoint(mouse):
            self._toggle_music_pause()
            return True
        if controls["next"].collidepoint(mouse):
            self._step_manual_music_track(1)
            return True
        if controls["mode"].collidepoint(mouse):
            self._toggle_music_auto_mode()
            return True
        volume_rect = self._music_player_volume_rect(window).inflate(
            0,
            MUSIC_PLAYER_VOLUME_HIT_PADDING * 2,
        )
        if volume_rect.collidepoint(mouse):
            self.music_player_dragging_volume = True
            self._set_music_player_volume_at(window, mouse[0])
            return True
        return False

    def _draw_music_control_icon(
        self,
        action: str,
        rect: pygame.Rect,
        color: pygame.Color,
    ) -> None:
        center_x, center_y = rect.center
        icon = MUSIC_PLAYER_CONTROL_ICON_SIZE
        if action == "play_pause":
            is_playing = (
                self.audio_manager.music_enabled
                and not self.audio_manager.music_paused
                and self.audio_manager.available
            )
            if is_playing:
                bar_width = max(2, icon // 3)
                for offset in (-icon // 2, icon // 2 - bar_width):
                    pygame.draw.rect(
                        self.screen,
                        color,
                        self._window_rect(
                            pygame.Rect(
                                center_x + offset,
                                center_y - icon,
                                bar_width,
                                icon * 2,
                            )
                        ),
                    )
            else:
                pygame.draw.polygon(
                    self.screen,
                    color,
                    [
                        self._point((center_x - icon // 2, center_y - icon)),
                        self._point((center_x - icon // 2, center_y + icon)),
                        self._point((center_x + icon, center_y)),
                    ],
                )
            return
        points = (
            [
                self._point((center_x + icon // 2, center_y - icon)),
                self._point((center_x + icon // 2, center_y + icon)),
                self._point((center_x - icon, center_y)),
            ]
            if action == "previous"
            else [
                self._point((center_x - icon // 2, center_y - icon)),
                self._point((center_x - icon // 2, center_y + icon)),
                self._point((center_x + icon, center_y)),
            ]
        )
        pygame.draw.polygon(self.screen, color, points)
        bar_x = center_x - icon if action == "previous" else center_x + icon - 2
        pygame.draw.rect(
            self.screen,
            color,
            self._window_rect(
                pygame.Rect(bar_x, center_y - icon, 3, icon * 2)
            ),
        )

    def _draw_music_player_content(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
    ) -> None:
        content = self._music_player_content_rect(window)
        track_id = self.audio_manager.current_music_track or self._selected_music_track()
        track_name = MUSIC_TRACK_NAMES.get(track_id, "Deep Cyber Ambient")
        status = (
            "NO AUDIO"
            if not self.audio_manager.available
            else "PAUSED"
            if self.audio_manager.music_paused or not self.audio_manager.music_enabled
            else "PLAYING"
        )
        self._draw_text(
            track_name,
            (content.x, content.y + MUSIC_PLAYER_TITLE_Y_OFFSET),
            MUSIC_PLAYER_FONT_SIZE,
            COLOR_TEXT,
            bold=True,
        )
        self._draw_text(
            status,
            (content.right, content.y + MUSIC_PLAYER_TITLE_Y_OFFSET),
            MUSIC_PLAYER_SMALL_FONT_SIZE,
            COLOR_SUCCESS if status == "PLAYING" else COLOR_HOT_ACCENT,
            right=True,
            bold=True,
        )

        visualizer = pygame.Rect(
            content.x,
            content.y + MUSIC_PLAYER_VISUALIZER_Y_OFFSET,
            content.width,
            MUSIC_PLAYER_VISUALIZER_HEIGHT,
        )
        pygame.draw.rect(self.screen, COLOR_TASKBAR, self._window_rect(visualizer))
        total_gap = MUSIC_PLAYER_VISUALIZER_GAP * (MUSIC_VISUALIZER_BAR_COUNT - 1)
        bar_width = max(2, (visualizer.width - total_gap) // MUSIC_VISUALIZER_BAR_COUNT)
        for index, level in enumerate(self.audio_manager.visualizer_values):
            bar_height = max(
                MUSIC_PLAYER_VISUALIZER_MIN_HEIGHT,
                round(visualizer.height * level),
            )
            bar = pygame.Rect(
                visualizer.x + index * (bar_width + MUSIC_PLAYER_VISUALIZER_GAP),
                visualizer.bottom - bar_height,
                bar_width,
                bar_height,
            )
            pygame.draw.rect(
                self.screen,
                COLOR_ERROR if track_id == "track_attack" else COLOR_SUCCESS,
                self._window_rect(bar),
            )

        duration = MUSIC_TRACK_DURATIONS.get(track_id, 1.0)
        progress = min(1.0, max(0.0, self.audio_manager.music_track_elapsed / duration))
        progress_rect = pygame.Rect(
            content.x,
            content.y + MUSIC_PLAYER_PROGRESS_Y_OFFSET,
            content.width,
            MUSIC_PLAYER_PROGRESS_HEIGHT,
        )
        pygame.draw.rect(self.screen, COLOR_TASKBAR, self._window_rect(progress_rect))
        if progress > 0.0:
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT,
                self._window_rect(
                    pygame.Rect(
                        progress_rect.x,
                        progress_rect.y,
                        max(1, round(progress_rect.width * progress)),
                        progress_rect.height,
                    )
                ),
            )

        for index, listed_track_id in enumerate(MUSIC_TRACK_IDS):
            row = self._music_player_track_rect(window, index)
            active = listed_track_id == track_id
            hovered = row.collidepoint(mouse)
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT if active else (COLOR_TASKBAR if hovered else COLOR_PANEL),
                self._window_rect(row),
                border_radius=self._s(4),
            )
            if active:
                pygame.draw.rect(
                    self.screen,
                    COLOR_HOT_ACCENT,
                    self._window_rect(pygame.Rect(row.x, row.y, 4, row.height)),
                )
            self._draw_text(
                f"{index + 1:02d}  {MUSIC_TRACK_NAMES[listed_track_id]}",
                (
                    row.x + MUSIC_PLAYER_TRACK_TEXT_X_OFFSET,
                    row.centery,
                ),
                MUSIC_PLAYER_FONT_SIZE,
                COLOR_TEXT,
                center_y=True,
                bold=active,
            )
            self._draw_text(
                f"{int(MUSIC_TRACK_DURATIONS[listed_track_id])}s",
                (row.right - MUSIC_PLAYER_TRACK_TEXT_X_OFFSET, row.centery),
                MUSIC_PLAYER_SMALL_FONT_SIZE,
                COLOR_SUCCESS if active else COLOR_ACCENT,
                right=True,
                center_y=True,
            )

        controls = self._music_player_control_rects(window)
        mode_rect = controls.pop("mode")
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT if self.audio_manager.music_auto_mode else COLOR_TASKBAR,
            self._window_rect(mode_rect),
            border_radius=self._s(4),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_HOT_ACCENT,
            self._window_rect(mode_rect),
            width=self._s(1),
            border_radius=self._s(4),
        )
        self._draw_text(
            "АВТО" if self.audio_manager.music_auto_mode else "РУЧНОЙ",
            mode_rect.center,
            MUSIC_PLAYER_SMALL_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        for action, control_rect in controls.items():
            hovered = control_rect.collidepoint(mouse)
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT if hovered or action == "play_pause" else COLOR_TASKBAR,
                self._window_rect(control_rect),
                border_radius=self._s(control_rect.width // 2),
            )
            self._draw_music_control_icon(action, control_rect, COLOR_TEXT)

        volume_rect = self._music_player_volume_rect(window)
        self._draw_text(
            f"VOLUME {round(self.audio_manager.music_volume * 100):02d}%",
            (content.x, volume_rect.centery),
            MUSIC_PLAYER_SMALL_FONT_SIZE,
            COLOR_ACCENT,
            center_y=True,
        )
        pygame.draw.rect(self.screen, COLOR_TASKBAR, self._window_rect(volume_rect))
        filled_width = max(1, round(volume_rect.width * self.audio_manager.music_volume))
        pygame.draw.rect(
            self.screen,
            COLOR_SUCCESS,
            self._window_rect(
                pygame.Rect(
                    volume_rect.x,
                    volume_rect.y,
                    filled_width,
                    volume_rect.height,
                )
            ),
        )
        knob_center = (
            volume_rect.x + round(volume_rect.width * self.audio_manager.music_volume),
            volume_rect.centery,
        )
        pygame.draw.circle(
            self.screen,
            COLOR_TEXT,
            self._point(knob_center),
            self._s(MUSIC_PLAYER_VOLUME_KNOB_RADIUS),
        )

    def _draw_desktop_window(
        self,
        window: DesktopWindow,
        mouse: tuple[float, float],
        *,
        active: bool,
    ) -> None:
        outer_rect = self._window_rect(window.rect)
        title_rect = self._window_title_rect(window)
        title_color = COLOR_ACCENT if active else COLOR_TASKBAR
        border_color = COLOR_HOT_ACCENT if active else COLOR_ACCENT
        pygame.draw.rect(
            self.screen,
            COLOR_PANEL,
            outer_rect,
            border_radius=self._s(DESKTOP_WINDOW_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            title_color,
            self._window_rect(title_rect),
            border_top_left_radius=self._s(DESKTOP_WINDOW_CORNER_RADIUS),
            border_top_right_radius=self._s(DESKTOP_WINDOW_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            border_color,
            outer_rect,
            width=self._s(DESKTOP_WINDOW_BORDER_WIDTH),
            border_radius=self._s(DESKTOP_WINDOW_CORNER_RADIUS),
        )
        self._draw_text(
            window.title,
            (
                window.rect.x + DESKTOP_WINDOW_TITLE_TEXT_OFFSET[0],
                window.rect.y + DESKTOP_WINDOW_TITLE_TEXT_OFFSET[1],
            ),
            DESKTOP_WINDOW_TITLE_FONT_SIZE,
            COLOR_TEXT,
            bold=active,
        )
        self._draw_window_controls(window, mouse)
        if window.app_id == MESSENGER_APP_ID:
            self._draw_messenger_content(window, mouse)
            return
        if window.app_id == BROWSER_APP_ID:
            self._draw_browser_content(window, mouse)
            return
        if window.app_id == DARKNET_APP_ID:
            self._draw_darknet_content(window, mouse)
            return
        if window.app_id == CRYPTO_WALLET_APP_ID:
            self._draw_crypto_wallet_content(window)
            return
        if window.app_id == MINER_MANAGER_APP_ID:
            self._draw_miner_manager_content(window)
            return
        if window.app_id == TERMINAL_APP_ID:
            self._draw_skill_tree_content(window, mouse)
            return
        if window.app_id == MUSIC_PLAYER_APP_ID:
            self._draw_music_player_content(window, mouse)
            return

        content_left = window.rect.x + DESKTOP_WINDOW_CONTENT_INSET
        content_right = window.rect.right - DESKTOP_WINDOW_CONTENT_INSET
        content_bar_y = (
            window.rect.y + DESKTOP_WINDOW_TITLE_HEIGHT + DESKTOP_WINDOW_CONTENT_INSET
        )
        pygame.draw.rect(
            self.screen,
            COLOR_HOT_ACCENT,
            self._rect(
                (
                    content_left,
                    content_bar_y,
                    max(1, content_right - content_left),
                    DESKTOP_WINDOW_CONTENT_BAR_HEIGHT,
                )
            ),
        )
        content_center_y = (
            window.rect.y
            + DESKTOP_WINDOW_TITLE_HEIGHT
            + (window.rect.height - DESKTOP_WINDOW_TITLE_HEIGHT) // 2
        )
        self._draw_text(
            "Coming soon",
            (
                window.rect.centerx,
                content_center_y + DESKTOP_WINDOW_PLACEHOLDER_OFFSET_Y,
            ),
            DESKTOP_WINDOW_PLACEHOLDER_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        self._draw_text(
            f"{window.title} // MODULE PLACEHOLDER",
            (
                window.rect.centerx,
                content_center_y + DESKTOP_WINDOW_APP_LABEL_OFFSET_Y,
            ),
            DESKTOP_WINDOW_APP_LABEL_FONT_SIZE,
            COLOR_ACCENT,
            center=True,
        )

    def _draw_vpn_shield(self, color: pygame.Color) -> None:
        origin_x, origin_y = DESKTOP_VPN_SHIELD_ORIGIN
        for x, y, width, height in DESKTOP_VPN_SHIELD_PARTS:
            pygame.draw.rect(
                self.screen,
                color,
                self._rect((origin_x + x, origin_y + y, width, height)),
            )

    def _draw_btc_balance(self) -> None:
        font = self._font(DESKTOP_TASKBAR_FONT_SIZE, True)
        formatted = DESKTOP_BTC_TEMPLATE.format(balance=self.btc_balance)
        number_text = formatted.removeprefix("₿ ")
        bitcoin_image = font.render("B", True, COLOR_TEXT)
        number_image = font.render(number_text, True, COLOR_TEXT)
        right_x, top_y = self._point(DESKTOP_BTC_RIGHT_POS)
        gap = self._s(DESKTOP_BTC_TEXT_GAP)
        total_width = bitcoin_image.get_width() + gap + number_image.get_width()
        bitcoin_x = right_x - total_width
        self.screen.blit(bitcoin_image, (bitcoin_x, top_y))
        for stroke_offset in DESKTOP_BTC_STROKE_OFFSETS:
            pygame.draw.rect(
                self.screen,
                COLOR_TEXT,
                pygame.Rect(
                    bitcoin_x + self._s(stroke_offset),
                    top_y,
                    self._s(DESKTOP_BTC_STROKE_WIDTH),
                    bitcoin_image.get_height(),
                ),
            )
        self.screen.blit(
            number_image,
            (bitcoin_x + bitcoin_image.get_width() + gap, top_y),
        )

    def _draw_game_clock(self) -> None:
        is_night = self._is_game_night()
        icon_color = COLOR_HOT_ACCENT if is_night else COLOR_SUCCESS
        icon_center = self._point(GAME_CLOCK_ICON_POS)
        icon_radius = self._s(GAME_CLOCK_ICON_RADIUS)
        pygame.draw.circle(self.screen, icon_color, icon_center, icon_radius)
        if is_night:
            pygame.draw.circle(
                self.screen,
                COLOR_TASKBAR,
                (
                    icon_center[0] + self._s(GAME_CLOCK_CRESCENT_OFFSET[0]),
                    icon_center[1] + self._s(GAME_CLOCK_CRESCENT_OFFSET[1]),
                ),
                icon_radius,
            )
        else:
            ray_inner = GAME_CLOCK_ICON_RADIUS + GAME_CLOCK_RAY_INSET
            ray_outer = ray_inner + GAME_CLOCK_RAY_LENGTH
            for angle in range(0, 360, GAME_CLOCK_RAY_STEP_DEGREES):
                radians = math.radians(angle)
                start = self._point(
                    (
                        GAME_CLOCK_ICON_POS[0] + math.cos(radians) * ray_inner,
                        GAME_CLOCK_ICON_POS[1] + math.sin(radians) * ray_inner,
                    )
                )
                end = self._point(
                    (
                        GAME_CLOCK_ICON_POS[0] + math.cos(radians) * ray_outer,
                        GAME_CLOCK_ICON_POS[1] + math.sin(radians) * ray_outer,
                    )
                )
                pygame.draw.line(
                    self.screen,
                    icon_color,
                    start,
                    end,
                    self._s(THIN_LINE_WIDTH),
                )
        mode = "NIGHT" if is_night else "DAY"
        self._draw_text(
            f"GAME {self._format_game_time()} // {mode}",
            GAME_CLOCK_CENTER_POS,
            DESKTOP_TASKBAR_FONT_SIZE,
            icon_color,
            center=True,
            bold=True,
        )

    def _draw_desktop_taskbar(self, mouse: tuple[float, float]) -> None:
        taskbar = self._rect((0, 0, DESIGN_WIDTH, DESKTOP_TASKBAR_HEIGHT))
        pygame.draw.rect(self.screen, COLOR_TASKBAR, taskbar)
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            self._rect(
                (
                    0,
                    DESKTOP_TASKBAR_HEIGHT - DESKTOP_TASKBAR_SEPARATOR_HEIGHT,
                    DESIGN_WIDTH,
                    DESKTOP_TASKBAR_SEPARATOR_HEIGHT,
                )
            ),
        )

        menu_rect = pygame.Rect(DESKTOP_MENU_BUTTON_RECT)
        menu_hovered = menu_rect.collidepoint(mouse)
        menu_color = (
            COLOR_HOT_ACCENT
            if self.desktop_launcher_open
            else COLOR_ACCENT
            if menu_hovered
            else COLOR_PANEL
        )
        pygame.draw.rect(
            self.screen,
            menu_color,
            self._window_rect(menu_rect),
            border_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
        )
        self._draw_text(
            "Меню",
            DESKTOP_MENU_TEXT_CENTER,
            DESKTOP_TASKBAR_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        self._draw_text(
            "ZERO DAY // KALI DESKTOP",
            DESKTOP_TASKBAR_CENTER_POS,
            DESKTOP_TASKBAR_FONT_SIZE,
            COLOR_ACCENT,
            center=True,
        )
        self._draw_game_clock()
        suspicion_color = (
            COLOR_ERROR
            if self.suspicion >= 60.0
            else COLOR_HOT_ACCENT
            if self.suspicion >= 25.0
            else COLOR_SUCCESS
        )
        self._draw_text(
            f"ПОДОЗРЕНИЕ {self.suspicion:.0f}%",
            DESKTOP_SUSPICION_RIGHT_POS,
            DESKTOP_TASKBAR_FONT_SIZE,
            suspicion_color,
            right=True,
            bold=True,
        )
        suspicion_bar = pygame.Rect(DESKTOP_SUSPICION_BAR_RECT)
        pygame.draw.rect(self.screen, COLOR_PANEL, self._window_rect(suspicion_bar))
        suspicion_width = round(
            (suspicion_bar.width - DESKTOP_SUSPICION_BAR_INSET * 2)
            * self.suspicion
            / SUSPICION_MAX
        )
        if suspicion_width > 0:
            pygame.draw.rect(
                self.screen,
                suspicion_color,
                self._rect(
                    (
                        suspicion_bar.x + DESKTOP_SUSPICION_BAR_INSET,
                        suspicion_bar.y + DESKTOP_SUSPICION_BAR_INSET,
                        suspicion_width,
                        max(
                            1,
                            suspicion_bar.height - DESKTOP_SUSPICION_BAR_INSET * 2,
                        ),
                    )
                ),
            )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            self._window_rect(suspicion_bar),
            width=self._s(THIN_LINE_WIDTH),
        )
        attack_seconds = max(0, math.ceil(self.hacker_attack_timer))
        attack_minutes, attack_remainder = divmod(attack_seconds, 60)
        warning_active = (
            self.hacker_attack_warning_sent
            and self.hacker_attack_timer <= HACKER_ATTACK_WARNING_SECONDS
        )
        self._draw_text(
            f"ATK {attack_minutes:02d}:{attack_remainder:02d}",
            DESKTOP_ATTACK_TIMER_RIGHT_POS,
            DESKTOP_TASKBAR_FONT_SIZE,
            COLOR_ERROR if warning_active else COLOR_ACCENT,
            right=True,
            bold=warning_active,
        )
        self._draw_btc_balance()

        vpn_rect = pygame.Rect(DESKTOP_VPN_RECT)
        if vpn_rect.collidepoint(mouse):
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT,
                self._window_rect(vpn_rect),
                border_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
            )
        shield_color = COLOR_SUCCESS if self.vpn_charges > 0 else COLOR_ERROR
        if warning_active:
            blink_on = (
                int(self.total_elapsed / HACKER_ATTACK_SHIELD_BLINK_SECONDS) % 2 == 0
            )
            shield_color = shield_color if blink_on else COLOR_TEXT
        self._draw_vpn_shield(shield_color)
        pygame.draw.circle(
            self.screen,
            shield_color,
            self._point(DESKTOP_VPN_STATUS_CENTER),
            self._s(DESKTOP_VPN_STATUS_RADIUS),
        )
        self._draw_text(
            f"VPN [{self.vpn_charges}/{VPN_MAX_CHARGES}]",
            DESKTOP_VPN_TEXT_POS,
            DESKTOP_TASKBAR_FONT_SIZE,
            shield_color,
            bold=True,
        )
        self._draw_text(
            datetime.now(timezone.utc).astimezone().strftime("%H:%M:%S"),
            DESKTOP_CLOCK_RIGHT_POS,
            DESKTOP_TASKBAR_FONT_SIZE,
            COLOR_TEXT,
            right=True,
            bold=True,
        )

    def _draw_desktop_launcher(self, mouse: tuple[float, float]) -> None:
        launcher = self._rect(DESKTOP_LAUNCHER_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_TASKBAR,
            launcher,
            border_bottom_left_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
            border_bottom_right_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT,
            launcher,
            width=self._s(BORDER_WIDTH),
            border_bottom_left_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
            border_bottom_right_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
        )
        self._draw_text(
            "ПРИЛОЖЕНИЯ",
            DESKTOP_LAUNCHER_HEADER_POS,
            DESKTOP_TASKBAR_FONT_SIZE,
            COLOR_SUCCESS,
            bold=True,
        )
        open_apps = {window.app_id for window in self.desktop_windows}
        for index, (app_id, title, symbol) in enumerate(DESKTOP_APPS):
            item_rect = self._launcher_item_rect(index)
            hovered = item_rect.collidepoint(mouse)
            if hovered:
                pygame.draw.rect(
                    self.screen,
                    COLOR_ACCENT,
                    self._window_rect(item_rect),
                    border_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
                )
            item_y = item_rect.y + DESKTOP_LAUNCHER_ITEM_TEXT_OFFSET_Y
            self._draw_text(
                symbol,
                (DESKTOP_LAUNCHER_SYMBOL_X, item_y),
                DESKTOP_LAUNCHER_FONT_SIZE,
                COLOR_SUCCESS if app_id in open_apps else COLOR_HOT_ACCENT,
                bold=True,
            )
            self._draw_text(
                title,
                (DESKTOP_LAUNCHER_TEXT_X, item_y),
                DESKTOP_LAUNCHER_FONT_SIZE,
                COLOR_TEXT,
            )

        self._draw_text(
            "МИНИ-ИГРЫ",
            DESKTOP_LAUNCHER_MINIGAME_HEADER_POS,
            DESKTOP_TASKBAR_FONT_SIZE,
            COLOR_SUCCESS,
            bold=True,
        )
        for index, (_game_id, title, symbol) in enumerate(MINIGAME_ENTRIES):
            item_rect = self._launcher_minigame_rect(index)
            if item_rect.collidepoint(mouse):
                pygame.draw.rect(
                    self.screen,
                    COLOR_ACCENT,
                    self._window_rect(item_rect),
                    border_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
                )
            item_y = item_rect.y + DESKTOP_LAUNCHER_ITEM_TEXT_OFFSET_Y
            self._draw_text(
                symbol,
                (DESKTOP_LAUNCHER_SYMBOL_X, item_y),
                DESKTOP_LAUNCHER_FONT_SIZE,
                COLOR_HOT_ACCENT,
                bold=True,
            )
            self._draw_text(
                title,
                (DESKTOP_LAUNCHER_TEXT_X, item_y),
                DESKTOP_LAUNCHER_FONT_SIZE,
                COLOR_TEXT,
            )

        difficulty_rect = pygame.Rect(DESKTOP_LAUNCHER_DIFFICULTY_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_ACCENT if difficulty_rect.collidepoint(mouse) else COLOR_PANEL,
            self._window_rect(difficulty_rect),
            border_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
        )
        self._draw_text(
            f"Сложность: {self.difficulty}/5  (клавиши 1–5)",
            difficulty_rect.center,
            DESKTOP_LAUNCHER_FONT_SIZE,
            COLOR_SUCCESS,
            center=True,
            bold=True,
        )

        home_rect = pygame.Rect(DESKTOP_LAUNCHER_HOME_RECT)
        if home_rect.collidepoint(mouse):
            pygame.draw.rect(
                self.screen,
                COLOR_HOT_ACCENT,
                self._window_rect(home_rect),
                border_radius=self._s(DESKTOP_LAUNCHER_BORDER_RADIUS),
            )
        self._draw_text(
            "Главное меню",
            home_rect.center,
            DESKTOP_LAUNCHER_FONT_SIZE,
            COLOR_TEXT,
            center=True,
            bold=True,
        )

    def _draw_desktop_notifications(self) -> None:
        base_x, base_y, width, height = DESKTOP_NOTIFICATION_RECT
        notifications = self.desktop_notifications[-DESKTOP_NOTIFICATION_MAX_VISIBLE:]
        for index, notification in enumerate(reversed(notifications)):
            y = base_y + index * (height + DESKTOP_NOTIFICATION_GAP)
            notification_rect = pygame.Rect(base_x, y, width, height)
            color = notification["color"]
            if not isinstance(color, pygame.Color):
                color = COLOR_SUCCESS
            pygame.draw.rect(
                self.screen,
                COLOR_TASKBAR,
                self._window_rect(notification_rect),
                border_radius=self._s(DESKTOP_NOTIFICATION_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                color,
                self._window_rect(notification_rect),
                width=self._s(BORDER_WIDTH),
                border_radius=self._s(DESKTOP_NOTIFICATION_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                color,
                self._rect(
                    (
                        notification_rect.x,
                        notification_rect.y,
                        DESKTOP_NOTIFICATION_STRIPE_WIDTH,
                        notification_rect.height,
                    )
                ),
                border_top_left_radius=self._s(DESKTOP_NOTIFICATION_CORNER_RADIUS),
                border_bottom_left_radius=self._s(DESKTOP_NOTIFICATION_CORNER_RADIUS),
            )
            self._draw_text(
                "СИСТЕМНОЕ УВЕДОМЛЕНИЕ",
                (
                    notification_rect.x + DESKTOP_NOTIFICATION_PADDING_X,
                    notification_rect.y + DESKTOP_NOTIFICATION_TITLE_Y_OFFSET,
                ),
                DESKTOP_NOTIFICATION_TITLE_FONT_SIZE,
                color,
                bold=True,
            )
            message = self._fit_text(
                self._event_display_text(str(notification["message"])),
                self._font(DESKTOP_NOTIFICATION_TEXT_FONT_SIZE),
                self._s(width - DESKTOP_NOTIFICATION_PADDING_X * 2),
            )
            self._draw_text(
                message,
                (
                    notification_rect.x + DESKTOP_NOTIFICATION_PADDING_X,
                    notification_rect.y + DESKTOP_NOTIFICATION_TEXT_Y_OFFSET,
                ),
                DESKTOP_NOTIFICATION_TEXT_FONT_SIZE,
                COLOR_TEXT,
            )

    def _draw_hack_prep(self) -> None:
        self._draw_background(grid=True)
        mouse = self._desktop_point(pygame.mouse.get_pos())
        launch = self.pending_hack_launch or {}
        context_value = launch.get("context")
        context = context_value if isinstance(context_value, dict) else {}
        game_id = str(launch.get("game_id", ""))
        game_title = next(
            (
                title
                for entry_id, title, _symbol in MINIGAME_ENTRIES
                if entry_id == game_id
            ),
            game_id,
        )
        target_name = str(context.get("target", "Тренировочный модуль"))
        difficulty_value = int(launch.get("difficulty", self.difficulty))
        if context:
            difficulty_value = self._effective_target_difficulty(difficulty_value)
        self._draw_text(
            "ПОДГОТОВКА ВЗЛОМА",
            HACK_PREP_TITLE_CENTER,
            HACK_PREP_TITLE_FONT_SIZE,
            COLOR_SUCCESS,
            center=True,
            bold=True,
        )
        self._draw_text(
            f"{target_name}  //  {game_title}  //  СЛОЖНОСТЬ {difficulty_value}/5",
            HACK_PREP_TARGET_CENTER,
            FONT_SIZE_BODY,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        self._draw_text(
            "Отметьте одноразовые инструменты или сохраните их на потом",
            HACK_PREP_HELP_CENTER,
            FONT_SIZE_SMALL,
            COLOR_ACCENT,
            center=True,
        )

        products = self._hack_prep_products()
        for index, product in enumerate(products):
            product_id = str(product["id"])
            tool_rect = self._hack_prep_tool_rect(index)
            selected = product_id in self.selected_hack_tools
            hovered = tool_rect.collidepoint(mouse)
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT if selected else COLOR_PANEL,
                self._window_rect(tool_rect),
                border_radius=self._s(POST_HACK_BUTTON_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_SUCCESS
                if selected
                else COLOR_HOT_ACCENT
                if hovered
                else COLOR_ACCENT,
                self._window_rect(tool_rect),
                width=self._s(BORDER_WIDTH),
                border_radius=self._s(POST_HACK_BUTTON_CORNER_RADIUS),
            )
            marker_center = (
                tool_rect.x + HACK_PREP_TOOL_TEXT_OFFSET[0],
                tool_rect.centery,
            )
            pygame.draw.circle(
                self.screen,
                COLOR_SUCCESS if selected else COLOR_TASKBAR,
                self._point(marker_center),
                self._s(POST_HACK_ACTION_SYMBOL_RADIUS),
            )
            self._draw_text(
                "ON" if selected else "OFF",
                marker_center,
                DARKNET_SMALL_FONT_SIZE,
                COLOR_BACKGROUND if selected else COLOR_ACCENT,
                center=True,
                bold=True,
            )
            text_x = tool_rect.x + HACK_PREP_TOOL_TEXT_OFFSET[0] * 2
            self._draw_text(
                str(product["name"]),
                (text_x, tool_rect.y + HACK_PREP_TOOL_TEXT_OFFSET[1]),
                HACK_PREP_FONT_SIZE,
                COLOR_TEXT,
                bold=True,
            )
            self._draw_text(
                str(product["description"]),
                (text_x, tool_rect.y + HACK_PREP_TOOL_DESCRIPTION_Y_OFFSET),
                DARKNET_TEXT_FONT_SIZE,
                COLOR_SUCCESS if selected else COLOR_TEXT,
            )
            self._draw_text(
                f"В наличии: {self.inventory[product_id]}",
                (
                    tool_rect.right - HACK_PREP_TOOL_STOCK_RIGHT_OFFSET,
                    tool_rect.centery - HACK_PREP_FONT_SIZE // 2,
                ),
                HACK_PREP_FONT_SIZE,
                COLOR_SUCCESS,
                right=True,
                bold=True,
            )

        for rect_value, label, accent in (
            (HACK_PREP_BACK_RECT, "Назад", COLOR_ACCENT),
            (
                HACK_PREP_START_RECT,
                "Авто-взлом"
                if "botnet_pc" in self.selected_hack_tools
                else "Начать взлом",
                COLOR_SUCCESS,
            ),
        ):
            button = pygame.Rect(rect_value)
            hovered = button.collidepoint(mouse)
            pygame.draw.rect(
                self.screen,
                accent if hovered else COLOR_TASKBAR,
                self._window_rect(button),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                accent,
                self._window_rect(button),
                width=self._s(BORDER_WIDTH),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
            self._draw_text(
                label,
                button.center,
                HACK_PREP_FONT_SIZE,
                COLOR_BACKGROUND if hovered else COLOR_TEXT,
                center=True,
                bold=True,
            )

    def _draw_post_hack_action_icon(
        self,
        action: str,
        center: tuple[int, int],
        icon_color: pygame.Color,
        cutout_color: pygame.Color,
    ) -> None:
        """Рисует векторный аналог emoji без зависимости от внешних шрифтов."""
        center_x, center_y = self._point(center)
        stroke = max(1, self._s(POST_HACK_ACTION_SYMBOL_STROKE))

        def point(offset_x: int, offset_y: int) -> tuple[int, int]:
            return (
                center_x + self._s(offset_x),
                center_y + self._s(offset_y),
            )

        if action == "miner":
            pygame.draw.line(
                self.screen,
                icon_color,
                point(-7, 8),
                point(5, -6),
                stroke + self._s(1),
            )
            pygame.draw.lines(
                self.screen,
                icon_color,
                False,
                (point(-3, -7), point(3, -8), point(9, -3)),
                stroke,
            )
        elif action == "blackmail":
            pygame.draw.circle(self.screen, icon_color, point(0, -2), self._s(8))
            pygame.draw.rect(
                self.screen,
                icon_color,
                pygame.Rect(*point(-5, 3), self._s(10), self._s(7)),
            )
            pygame.draw.circle(self.screen, cutout_color, point(-3, -3), self._s(2))
            pygame.draw.circle(self.screen, cutout_color, point(3, -3), self._s(2))
            pygame.draw.polygon(
                self.screen,
                cutout_color,
                (point(0, 0), point(-2, 3), point(2, 3)),
            )
            for tooth_x in (-3, 0, 3):
                pygame.draw.line(
                    self.screen,
                    cutout_color,
                    point(tooth_x, 5),
                    point(tooth_x, 9),
                    max(1, stroke // 2),
                )
        elif action == "data_theft":
            folder = pygame.Rect(*point(-9, -4), self._s(18), self._s(13))
            pygame.draw.rect(
                self.screen,
                icon_color,
                folder,
                width=stroke,
                border_radius=self._s(2),
            )
            pygame.draw.lines(
                self.screen,
                icon_color,
                False,
                (point(-8, -4), point(-5, -8), point(1, -8), point(3, -4)),
                stroke,
            )
        elif action == "ransomware":
            pygame.draw.arc(
                self.screen,
                icon_color,
                pygame.Rect(*point(-6, -10), self._s(12), self._s(15)),
                math.pi,
                math.tau,
                stroke,
            )
            pygame.draw.rect(
                self.screen,
                icon_color,
                pygame.Rect(*point(-8, -1), self._s(16), self._s(11)),
                border_radius=self._s(2),
            )
            pygame.draw.circle(self.screen, cutout_color, point(0, 3), self._s(2))
            pygame.draw.line(
                self.screen,
                cutout_color,
                point(0, 4),
                point(0, 7),
                max(1, stroke // 2),
            )
        elif action == "order_info":
            clipboard = pygame.Rect(*point(-7, -9), self._s(14), self._s(19))
            pygame.draw.rect(
                self.screen,
                icon_color,
                clipboard,
                width=stroke,
                border_radius=self._s(2),
            )
            pygame.draw.rect(
                self.screen,
                icon_color,
                pygame.Rect(*point(-3, -11), self._s(6), self._s(4)),
                border_radius=self._s(1),
            )
            for line_y in (-3, 1, 5):
                pygame.draw.line(
                    self.screen,
                    icon_color,
                    point(-4, line_y),
                    point(4, line_y),
                    max(1, stroke // 2),
                )
        elif action == "proxy":
            arc_rect = pygame.Rect(*point(-8, -8), self._s(16), self._s(16))
            pygame.draw.arc(
                self.screen,
                icon_color,
                arc_rect,
                math.radians(25),
                math.radians(175),
                stroke,
            )
            pygame.draw.arc(
                self.screen,
                icon_color,
                arc_rect,
                math.radians(205),
                math.radians(355),
                stroke,
            )
            pygame.draw.polygon(
                self.screen,
                icon_color,
                (point(-9, -3), point(-9, -9), point(-4, -6)),
            )
            pygame.draw.polygon(
                self.screen,
                icon_color,
                (point(9, 3), point(9, 9), point(4, 6)),
            )

    def _draw_post_hack(self) -> None:
        self._draw_background(grid=True)
        mouse = self._desktop_point(pygame.mouse.get_pos())
        context = self.active_hack_context or {}
        target_name = str(context.get("target", "НЕИЗВЕСТНАЯ ЦЕЛЬ"))
        target_type = str(context.get("target_type", "Обычный ПК"))
        difficulty_value = int(
            context.get(
                "effective_difficulty",
                context.get("difficulty", TARGET_TYPES[target_type]["difficulty"]),
            )
        )
        self._draw_text(
            "ДОСТУП К ЦЕЛИ ПОЛУЧЕН",
            POST_HACK_TITLE_CENTER,
            FONT_SIZE_TITLE,
            COLOR_SUCCESS,
            center=True,
            bold=True,
        )
        self._draw_text(
            f"{target_name}  //  {target_type}  //  ЗАЩИТА L{difficulty_value}",
            POST_HACK_TARGET_CENTER,
            FONT_SIZE_BODY,
            COLOR_TEXT,
            center=True,
            bold=True,
        )
        associated_text = (
            f"ЗАКАЗ #{int(context['order_id']):03d} • "
            f"НАГРАДА ₿ {float(context['reward']):.3f}"
            if context.get("order_id") is not None and context.get("reward") is not None
            else "АВТОНОМНЫЙ ВЗЛОМ • ЗАКАЗ НЕ СВЯЗАН"
        )
        self._draw_text(
            (
                f"{associated_text}    |    BTC {self.btc_balance:.3f}    |    "
                f"ПОДОЗРЕНИЕ {self.suspicion:.0f}%    |    VPN {self.vpn_charges}"
            ),
            POST_HACK_STATS_CENTER,
            FONT_SIZE_SMALL,
            COLOR_HOT_ACCENT,
            center=True,
            bold=True,
        )

        if self.post_hack_mode == "blackmail":
            self._draw_text(
                "ВЫБЕРИТЕ ТОН ШАНТАЖА",
                POST_HACK_BLACKMAIL_TITLE_CENTER,
                FONT_SIZE_HEADING,
                COLOR_ERROR,
                center=True,
                bold=True,
            )
            for index, (tone_id, tone) in enumerate(POST_HACK_BLACKMAIL_TONES.items()):
                tone_rect = self._post_hack_blackmail_rect(index)
                hovered = tone_rect.collidepoint(mouse)
                chance = float(tone["chance"])
                if self.inventory["malware_keylogger"] > 0:
                    chance += MALWARE_KEYLOGGER_CHANCE_BONUS
                chance_percent = round(min(1.0, chance) * 100)
                keylogger_label = (
                    " + KEYLOGGER" if self.inventory["malware_keylogger"] > 0 else ""
                )
                reward_range = tone["reward"]
                pygame.draw.rect(
                    self.screen,
                    COLOR_HOT_ACCENT if hovered else COLOR_TASKBAR,
                    self._window_rect(tone_rect),
                    border_radius=self._s(POST_HACK_BUTTON_CORNER_RADIUS),
                )
                pygame.draw.rect(
                    self.screen,
                    COLOR_ERROR if tone_id == "threat" else COLOR_HOT_ACCENT,
                    self._window_rect(tone_rect),
                    width=self._s(BORDER_WIDTH),
                    border_radius=self._s(POST_HACK_BUTTON_CORNER_RADIUS),
                )
                self._draw_text(
                    str(tone["name"]),
                    (
                        tone_rect.centerx,
                        tone_rect.y + POST_HACK_BLACKMAIL_NAME_Y_OFFSET,
                    ),
                    POST_HACK_ACTION_FONT_SIZE,
                    COLOR_TEXT,
                    center=True,
                    bold=True,
                )
                self._draw_text(
                    (
                        f"Шанс {chance_percent}%{keylogger_label}  •  "
                        f"₿ {float(reward_range[0]):.3f}–"
                        f"{float(reward_range[1]):.3f}"
                    ),
                    (
                        tone_rect.centerx,
                        tone_rect.y + POST_HACK_BLACKMAIL_REWARD_Y_OFFSET,
                    ),
                    POST_HACK_DESCRIPTION_FONT_SIZE,
                    COLOR_SUCCESS,
                    center=True,
                )
                self._draw_text(
                    f"Подозрение +{float(tone['suspicion']):.0f}%",
                    (
                        tone_rect.centerx,
                        tone_rect.y + POST_HACK_BLACKMAIL_SUSPICION_Y_OFFSET,
                    ),
                    POST_HACK_DESCRIPTION_FONT_SIZE,
                    COLOR_HOT_ACCENT,
                    center=True,
                )
            back_rect = pygame.Rect(POST_HACK_BLACKMAIL_BACK_RECT)
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT if back_rect.collidepoint(mouse) else COLOR_PANEL,
                self._window_rect(back_rect),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
            pygame.draw.rect(
                self.screen,
                COLOR_ACCENT,
                self._window_rect(back_rect),
                width=self._s(BORDER_WIDTH),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
            self._draw_text(
                "Назад к действиям",
                back_rect.center,
                FONT_SIZE_SMALL,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
        else:
            has_order = (
                context.get("customer") is not None
                and context.get("reward") is not None
                and context.get("order_id") is not None
            )
            for index, (action, label, description) in enumerate(POST_HACK_ACTIONS):
                action_rect = self._post_hack_action_rect(index)
                disabled = action == "order_info" and not has_order
                hovered = action_rect.collidepoint(mouse) and not disabled
                fill_color = (
                    COLOR_PANEL
                    if disabled
                    else COLOR_ACCENT
                    if hovered
                    else COLOR_TASKBAR
                )
                border_color = (
                    COLOR_PANEL
                    if disabled
                    else COLOR_HOT_ACCENT
                    if action in ("blackmail", "ransomware")
                    else COLOR_SUCCESS
                )
                pygame.draw.rect(
                    self.screen,
                    fill_color,
                    self._window_rect(action_rect),
                    border_radius=self._s(POST_HACK_BUTTON_CORNER_RADIUS),
                )
                pygame.draw.rect(
                    self.screen,
                    border_color,
                    self._window_rect(action_rect),
                    width=self._s(BORDER_WIDTH),
                    border_radius=self._s(POST_HACK_BUTTON_CORNER_RADIUS),
                )
                symbol_center = (
                    action_rect.x + POST_HACK_ACTION_SYMBOL_OFFSET[0],
                    action_rect.y + POST_HACK_ACTION_SYMBOL_OFFSET[1],
                )
                pygame.draw.circle(
                    self.screen,
                    COLOR_PANEL if disabled else border_color,
                    self._point(symbol_center),
                    self._s(POST_HACK_ACTION_SYMBOL_RADIUS),
                )
                self._draw_post_hack_action_icon(
                    action,
                    symbol_center,
                    COLOR_ACCENT if disabled else COLOR_BACKGROUND,
                    COLOR_PANEL if disabled else border_color,
                )
                display_label = label.partition(" ")[2]
                self._draw_text(
                    display_label,
                    (
                        action_rect.centerx,
                        action_rect.y + POST_HACK_ACTION_NAME_Y_OFFSET,
                    ),
                    POST_HACK_ACTION_FONT_SIZE,
                    COLOR_ACCENT if disabled else COLOR_TEXT,
                    center=True,
                    bold=True,
                )
                action_description = (
                    "нет связанного заказа" if disabled else description
                )
                malware_for_action = {
                    "miner": "malware_miner",
                    "data_theft": "malware_spy",
                    "ransomware": "malware_ransomware",
                }.get(action)
                if (
                    not disabled
                    and malware_for_action is not None
                    and self.inventory[malware_for_action] > 0
                ):
                    action_description = (
                        f"{description} • MALWARE x{self.inventory[malware_for_action]}"
                    )
                self._draw_text(
                    self._fit_text(
                        action_description,
                        self._font(POST_HACK_DESCRIPTION_FONT_SIZE),
                        self._s(action_rect.width - POST_HACK_ACTION_SYMBOL_RADIUS * 2),
                    ),
                    (
                        action_rect.centerx,
                        action_rect.y + POST_HACK_ACTION_DESCRIPTION_Y_OFFSET,
                    ),
                    POST_HACK_DESCRIPTION_FONT_SIZE,
                    COLOR_ACCENT if disabled else border_color,
                    center=True,
                )

        self._draw_text(
            "Выберите одно действие  •  ESC — закрыть доступ без награды",
            POST_HACK_HINT_CENTER,
            FONT_SIZE_SMALL,
            COLOR_ACCENT,
            center=True,
        )

    def _draw_desktop(self) -> None:
        mouse = self._desktop_point(pygame.mouse.get_pos())
        self._draw_desktop_wallpaper()
        self._draw_desktop_icons(mouse)
        active_window = next(
            (
                window
                for window in reversed(self.desktop_windows)
                if not window.minimized
            ),
            None,
        )
        for window in self.desktop_windows:
            if not window.minimized:
                self._draw_desktop_window(
                    window,
                    mouse,
                    active=window is active_window,
                )
        if self._is_game_night():
            night_overlay = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
            night_overlay.fill((0, 0, 0, 0))
            pygame.draw.rect(
                night_overlay,
                (*COLOR_TASKBAR[:3], GAME_NIGHT_OVERLAY_ALPHA),
                self._rect(
                    (
                        0,
                        DESKTOP_TASKBAR_HEIGHT,
                        DESIGN_WIDTH,
                        DESIGN_HEIGHT - DESKTOP_TASKBAR_HEIGHT,
                    )
                ),
            )
            self.screen.blit(night_overlay, (0, 0))
        self._draw_text(
            "ESC — главное меню  •  F11 — полный экран",
            DESKTOP_HINT_RIGHT_POS,
            FONT_SIZE_TINY,
            COLOR_ACCENT,
            right=True,
        )
        self._draw_desktop_taskbar(mouse)
        if self.desktop_launcher_open:
            self._draw_desktop_launcher(mouse)
        if self.hacker_attack_time > 0.0:
            pygame.draw.rect(
                self.screen,
                COLOR_ERROR,
                self._rect((0, 0, DESIGN_WIDTH, DESIGN_HEIGHT)),
                width=self._s(MESSENGER_ATTACK_BORDER_WIDTH),
            )
        self._draw_desktop_notifications()

    @staticmethod
    def _ease_out(value: float) -> float:
        clamped = min(1.0, max(0.0, value))
        return 1.0 - (1.0 - clamped) ** 3

    def _tutorial_target_rect(self) -> pygame.Rect | None:
        if not self.tutorial_active:
            return None
        if self.state == STATE_DESKTOP:
            messenger_index = next(
                (
                    index
                    for index, app in enumerate(DESKTOP_APPS)
                    if app[0] == MESSENGER_APP_ID
                ),
                0,
            )
            messenger_window = next(
                (
                    window
                    for window in reversed(self.desktop_windows)
                    if window.app_id == MESSENGER_APP_ID and not window.minimized
                ),
                None,
            )
            if self.tutorial_step == 0 or messenger_window is None:
                return self._desktop_icon_hit_rect(messenger_index)
            if self.tutorial_step in (1, 2):
                phantom_index = self._customer_nicks().index(TUTORIAL_CUSTOMER)
                if (
                    self.tutorial_step == 1
                    or self.messenger_selected_chat != TUTORIAL_CUSTOMER
                ):
                    return self._messenger_chat_row_rect(
                        messenger_window,
                        phantom_index,
                    )
                return self._messenger_action_rects(messenger_window)["accepted"]
        if self.state == STATE_HACK_PREP and self.tutorial_step == 3:
            return pygame.Rect(HACK_PREP_START_RECT)
        if (
            self.state in MINIGAME_STATES
            and self.tutorial_step == 3
            and self.active_minigame is not None
        ):
            if self.active_minigame.finished:
                return pygame.Rect(MINIGAME_RESULT_OK_RECT)
            return pygame.Rect(TUTORIAL_MINIGAME_FOCUS_RECT)
        if self.state == STATE_POST_HACK and self.tutorial_step == 4:
            order_info_index = next(
                index
                for index, action in enumerate(POST_HACK_ACTIONS)
                if action[0] == "order_info"
            )
            return self._post_hack_action_rect(order_info_index)
        return None

    def _draw_tutorial_arrow(
        self,
        start: tuple[float, float],
        end: tuple[float, float],
    ) -> None:
        vector = pygame.Vector2(end) - pygame.Vector2(start)
        if vector.length_squared() <= 1.0:
            return
        direction = vector.normalize()
        perpendicular = pygame.Vector2(-direction.y, direction.x)
        arrow_tip = pygame.Vector2(end)
        arrow_base = arrow_tip - direction * TUTORIAL_ARROW_SIZE
        points = [
            self._point(tuple(arrow_tip)),
            self._point(
                tuple(arrow_base + perpendicular * (TUTORIAL_ARROW_SIZE * 0.55))
            ),
            self._point(
                tuple(arrow_base - perpendicular * (TUTORIAL_ARROW_SIZE * 0.55))
            ),
        ]
        pygame.draw.line(
            self.screen,
            COLOR_HOT_ACCENT,
            self._point(start),
            self._point(tuple(arrow_base)),
            self._s(TUTORIAL_HIGHLIGHT_WIDTH),
        )
        pygame.draw.polygon(self.screen, COLOR_HOT_ACCENT, points)

    def _draw_tutorial_overlay(self) -> None:
        if not self.tutorial_active or self.state not in (
            STATE_DESKTOP,
            STATE_HACK_PREP,
            STATE_POST_HACK,
            *MINIGAME_STATES,
        ):
            return
        target = self._tutorial_target_rect()
        overlay = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, TUTORIAL_OVERLAY_ALPHA))
        if target is not None:
            expanded = target.inflate(
                TUTORIAL_HIGHLIGHT_PADDING * 2,
                TUTORIAL_HIGHLIGHT_PADDING * 2,
            )
            pygame.draw.rect(
                overlay,
                (0, 0, 0, 0),
                self._window_rect(expanded),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )
        self.screen.blit(overlay, (0, 0))

        if target is not None:
            pulse_phase = (
                math.sin(self.total_elapsed * math.tau / TUTORIAL_PULSE_SECONDS) + 1.0
            ) / 2.0
            pulse_padding = round(pulse_phase * TUTORIAL_PULSE_EXPANSION)
            pulse_rect = target.inflate(
                (TUTORIAL_HIGHLIGHT_PADDING + pulse_padding) * 2,
                (TUTORIAL_HIGHLIGHT_PADDING + pulse_padding) * 2,
            )
            pygame.draw.rect(
                self.screen,
                COLOR_SUCCESS if pulse_phase > 0.5 else COLOR_HOT_ACCENT,
                self._window_rect(pulse_rect),
                width=self._s(TUTORIAL_HIGHLIGHT_WIDTH),
                border_radius=self._s(BUTTON_CORNER_RADIUS),
            )

        tooltip = pygame.Rect(TUTORIAL_TOOLTIP_RECT)
        pygame.draw.rect(
            self.screen,
            COLOR_TASKBAR,
            self._window_rect(tooltip),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        pygame.draw.rect(
            self.screen,
            COLOR_HOT_ACCENT,
            self._window_rect(tooltip),
            width=self._s(TUTORIAL_HIGHLIGHT_WIDTH),
            border_radius=self._s(PANEL_CORNER_RADIUS),
        )
        message = TUTORIAL_MESSAGES.get(self.tutorial_step, "ОБУЧЕНИЕ")
        font = self._font(TUTORIAL_TOOLTIP_FONT_SIZE, bold=True)
        wrapped = self._wrap_text(
            message,
            font,
            self._s(tooltip.width - TUTORIAL_TOOLTIP_TEXT_PADDING),
        )
        text_y = tooltip.y + TUTORIAL_TOOLTIP_TEXT_Y_OFFSET
        for line in wrapped[:TUTORIAL_TOOLTIP_MAX_LINES]:
            self._draw_text(
                line,
                (tooltip.centerx, text_y),
                TUTORIAL_TOOLTIP_FONT_SIZE,
                COLOR_TEXT,
                center=True,
                bold=True,
            )
            text_y += TUTORIAL_TOOLTIP_LINE_GAP
        if target is not None:
            arrow_start = (
                tooltip.centerx,
                tooltip.y if target.centery < tooltip.centery else tooltip.bottom,
            )
            target_end = (
                target.centerx,
                target.bottom if target.centery < tooltip.centery else target.top,
            )
            self._draw_tutorial_arrow(arrow_start, target_end)

    def _draw(self) -> None:
        if self.state == STATE_CRT:
            self._draw_crt_intro()
        elif self.state == STATE_BOOT:
            self._draw_boot()
        elif self.state == STATE_LOGO:
            self._draw_logo()
        elif self.state == STATE_MENU:
            self._draw_menu()
        elif self.state == STATE_SETTINGS:
            self._draw_settings()
        elif self.state == STATE_GUIDES:
            self._draw_guides()
        elif self.state == STATE_SAVES:
            self._draw_saves()
        elif self.state == STATE_ARREST:
            self._draw_arrest()
        elif self.state == STATE_STORY_FINALE:
            self._draw_story_finale()
        elif self.state == STATE_DESKTOP:
            self._draw_desktop()
        elif self.state == STATE_HACK_PREP:
            self._draw_hack_prep()
        elif self.state == STATE_POST_HACK:
            self._draw_post_hack()
        elif self.state in MINIGAME_STATES and self.active_minigame is not None:
            self.active_minigame.draw(self)

        self.manager.draw_ui(self.screen)
        self._draw_tutorial_overlay()
        if self.transition_remaining > 0.0:
            ratio = min(
                1.0,
                self.transition_remaining / SCREEN_TRANSITION_SECONDS,
            )
            fade = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
            fade.fill((*COLOR_TASKBAR[:3], round(SCREEN_TRANSITION_MAX_ALPHA * ratio)))
            self.screen.blit(fade, (0, 0))
        self._draw_live_event_overlays()
        self._apply_call_screen_shake()
        pygame.display.flip()

    # ------------------------------------------------------------------
    # Главный цикл
    # ------------------------------------------------------------------

    def run(self) -> int:
        while self.running:
            delta_seconds = self.clock.tick(FPS) / 1000.0
            for event in pygame.event.get():
                self._handle_event(event)
            self._update(delta_seconds)
            self._draw()
        return 0


def main() -> int:
    os.environ.setdefault("SDL_VIDEO_CENTERED", "1")
    try:
        return ZeroDayApp().run()
    except pygame.error as exc:
        print(f"Ошибка Pygame: {exc}", file=sys.stderr)
        return 1
    finally:
        pygame.quit()


if __name__ == "__main__":
    raise SystemExit(main())
